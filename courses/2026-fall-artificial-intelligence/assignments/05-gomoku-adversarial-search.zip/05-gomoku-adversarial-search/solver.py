"""Submission template for Assignment 5; implement your own Gomoku algorithm.

A fresh process loads this module once for each game. Module-level state
persists between your turns and resets for the next game. Use only the Python
standard library.
"""

memory = {}


def act(observation):
    """Return exactly {"move": [x, y]} for an empty intersection.

    Observation fields:
      board: 15 rows of 15 integers (0 empty, 1 Black, 2 White).
      player: your color, 1 or 2.
      legal_moves: all empty [x, y] intersections.
      last_move: the previous placement, or None at the start.
      move_number: total number of stones already placed.

    Access intersections as board[y][x]; x increases right, y increases down.
    """
    raise NotImplementedError("Implement your Gomoku algorithm here.")
