# Assignment 5: Gomoku and Adversarial Search

Design and implement an algorithm that plays freestyle Gomoku on a 15 × 15
board. Choose your own strategy, develop it across at least three submissions,
and explain your design and results in a technical report.

## Resources

- [Assignment 5 Space](https://jungtaekkim-ai-fall-2026-assignment-5.hf.space):
  rules, an interactive practice board, algorithm submissions, submission history,
  and the official leaderboard.
- [Public repository](https://huggingface.co/spaces/jungtaekkim/ai-fall-2026-assignment-5):
  game code and evaluation instructions.
- [Local evaluator guide](https://huggingface.co/spaces/jungtaekkim/ai-fall-2026-assignment-5/blob/main/evaluator/README.md):
  run local games between your Python implementations using Docker with Linux
  containers, and save game records for analysis.
- [solver.py](solver.py).
- [Report template](report/report.tex) and [AI-use declaration](AI_USE.md).

You may use the public code and local evaluator to analyze your algorithm's
behavior and identify possible improvements. The Space's **Play Gomoku** tab lets
you play both sides to understand the rules. Local games do not affect official
rankings. Baseline source code and detailed official game records are maintained
privately by the instructor; published rankings provide aggregate results.

## Problem

Two players alternate placing stones on empty intersections of a 15 × 15 board.
Black (player 1) moves first; White (player 2) moves second. Every game starts
with an empty board, and the complete board is visible to both players.

The first player to form **five or more consecutive stones** of their own color
horizontally, vertically, or diagonally wins immediately. Six or more also wins.
There are no forbidden-pattern or swap-opening rules. A full board without a
winner is a draw. Passing, moving an existing stone, and placing on an occupied
intersection are illegal.

Coordinates are zero-based `(x, y)` pairs from 0 to 14. Moving right increases
`x`; moving down increases `y`. Access an intersection as `board[y][x]`.

Each official competition includes student algorithms and `random_player`,
`tactical_player`, and `heuristic_player`. Every entrant plays every other
entrant twice, once as Black and once as White. Choose your own strategy;
no particular search algorithm is required.

## Solver Interface

Implement the synchronous function `act(observation)` in `solver.py`. Each call
receives a Python dictionary and returns a placement such as `{"move": [7, 7]}`.
Return exactly one `move` key with a list of two integers identifying an empty
intersection; the interface also accepts a JSON string encoding that same object.

Observations contain these fields:

- `board`: 15 rows of 15 integers, with 0 for empty, 1 for Black, and 2 for White.
- `player`: your color, either 1 or 2; the opponent's color is `3 - player`.
- `legal_moves`: all currently empty intersections as `[x, y]` pairs.
- `last_move`: the previous placement as `[x, y]`, or `None` on the empty board.
- `move_number`: the number of stones already placed.

The Space's **Rules & interface** tab provides examples and the complete
specification. Opponent identities and source code are not agent inputs.

A fresh process loads each player's file once per game. Module-level state
persists between that player's turns and resets for the next game. Use only the
Python standard library. The submission must be one UTF-8 Python file of at most
512 KiB. Each player has 256 MiB memory, one CPU core, and no network access.
Agents are paused between their turns.

The evaluator allows 5 seconds for import readiness, 3 seconds per action
response, and 60 seconds of cumulative action-response time per player per game.
The cumulative allowance excludes import, opponent thinking time, and
pause/resume overhead. An illegal placement, invalid response, exception,
protocol violation, or exceeded time limit loses the game. Acceptance of an
upload does not establish that it runs correctly. The local evaluator guide
documents the complete resource limits and failure rules.

## Development and Hosted Submissions

Submit at least **three implemented versions** through the Assignment 5 Space
by **November 25, 2026, at 2:00 AM CST** (`America/Chicago`). A qualifying revision
changes the solver's behavior, such as its decision rule, parameter settings,
memory handling, or a bug fix. Identical reuploads and formatting-only edits do
not count as additional versions. Uploading the unchanged sample does not count
as an implementation. A revision need not improve performance to count.

1. Sign in with Hugging Face and enter your UARK ID without `@uark.edu`.
2. Upload the Python implementation with a descriptive algorithm label.
3. Save the submission receipt and submission ID. The Space assigns a persistent
   public name while keeping your identity and source code private.
4. Use **Check my submissions** to review your accepted submissions. Record the
   changes, reasons, and observations for each version in your report.

An accepted upload counts toward the submission requirement independently of
when it is evaluated. Acceptance checks syntax and the interface, not playing
strength. Three versions need not appear in three separate competitions.
One version participating in several competitions still counts as one submission.

Competitions normally have cutoffs at **2:00 AM and 2:00 PM America/Chicago**.
On **November 23 and 24, 2026**, cutoffs occur every two hours from midnight
through 10:00 PM Central Time, for twelve competitions each day. Results appear
after a competition finishes; delayed execution retains the original cutoff.

Each competition uses your **latest accepted submission at or before its cutoff**,
according to the platform's recorded submission timestamp. That version remains
active for subsequent competitions until a newer accepted version replaces it.
A rejected upload does not replace it. Uploads after a cutoff affect later
competitions and do not change an already frozen competition. Exact timestamp
ties select the lexicographically larger submission ID. An earlier version is
not restored because it played better or the newer version fails.

All entrants start each competition at 1500 Elo, with K = 32. A win scores 1,
a draw 0.5, and a loss 0. Both games in a color pair use the same pre-pair ratings;
updates follow the fixed pair schedule. Higher unrounded Elo ranks first.
Exact ties share a rank and display alphabetically by public name. Games played
and win/draw/loss counts provide context. Elo resets each competition, so results
across competitions also reflect changes in opponents.

Use the Leaderboard's **Competition** selector to inspect saved results.
A checkmark in **On leaderboard** identifies the submission used in the selected
competition; reload your submission history after changing the selection.

The scheduled competition with cutoff **November 25, 2026, at 2:00 AM CST**
(`20261125T080000Z`) determines both the **15-point baseline component** and the
**top-five ranking bonus**. It uses your latest accepted submission at or before
that cutoff, even if evaluation and publication finish later. Later uploads and
earlier competition results do not replace this grading result. There is no
separate final tournament.

## Report

Complete `report/report.tex` using the supplied NeurIPS 2026 style and compile
`report/report.pdf`. Keep the report to **at most seven pages**, including figures,
tables, and references, without changing fonts, margins, or spacing. Replace all
template prompts with your own explanations and evidence. Use these four sections:

1. **Algorithm Design.** Explain board representation, information stored across
   turns, candidate selection, tactical reasoning, position evaluation, search
   where applicable, and time allocation. Provide concise pseudocode and explain
   the important design choices.
2. **Development Across Submissions.** Identify at least three submission IDs,
   labels, and dates. Describe each version, why you changed it, and what you
   observed. Identify the implementation described by the report and the version
   selected for the final competition; explain any difference between them.
3. **Results and Analysis.** Present evidence about the algorithm's behavior and
   interpret it. Examine both colors and concrete cases of success, failure, or
   inefficiency. Explain the effects of design changes and distinguish
   observations from proposed explanations. Identify versions, opponents, and
   conditions behind comparisons, separating local evidence from official results.
4. **Official Baseline Comparison.** Compare the selected submission with
   `heuristic_player`, `tactical_player`, and `random_player` in the designated
   final competition. State the submission ID, competition ID and cutoff, Elo,
   games played, wins, draws, losses, and highest baseline tier exceeded.

The report is due **November 25, 2026, at 11:59 PM CST**.
Use the published final ranking from the designated final competition for the
final-results table and baseline comparisons, identifying your officially selected
submission. Earlier published competitions or local experiments may provide
supporting evidence in Results and Analysis, but do not substitute for the final
ranking. The instructor calculates performance credit from the same final competition.

Compile from `report/` so LaTeX finds the adjacent style:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Grading

| Component | Points |
| --- | ---: |
| Baseline performance | 15 |
| Three submissions and documented iteration | 20 |
| Algorithm design and understanding | 30 |
| Results and analysis | 30 |
| AI-use disclosure and verification | 5 |
| **Base total** | **100** |
| **Top-five ranking bonus** | **+10** |

### Baseline Performance: 15 Points

Compare the selected submission and the three named baselines in the designated
final competition. Exceeding a baseline means having **strictly higher unrounded
Elo** in that competition. Exact equality does not exceed a baseline. Use the
archived JSON or CSV measurements; the displayed table rounds Elo to two decimal
places. This comparison measures overall competition performance, not the outcome
of a direct matchup. Runtime, submission time, and alphabetical display order do
not affect this component.

| Highest baseline exceeded | Points |
| --- | ---: |
| `heuristic_player` | 15 |
| `tactical_player`, but not `heuristic_player` | 10 |
| `random_player`, but neither higher tier | 5 |
| None | 0 |

Award only the highest applicable tier. These named tiers remain fixed even if
the baselines' Elo ordering changes. These points measure the implementation's
official performance; explaining those results is assessed under Results and
Analysis.

### Top-Five Ranking Bonus: 10 Additional Points

The top five **student ranks** in the designated final competition receive ten
additional points each. Remove baseline entries and recompute student ranks
using unrounded Elo; the public leaderboard's rank includes baselines.
Exact ties share a rank, with subsequent ranks skipped accordingly. Everyone
sharing fifth rank receives the bonus, even if that produces more than five
recipients. Runtime, submission time, and alphabetical display order do not
break Elo ties.

## Submission Materials

Submit your implementations through the Assignment 5 Space by **November 25,
2026, at 2:00 AM CST**. Submit the following documents to Blackboard by
**November 25, 2026, at 11:59 PM CST**, preserving these paths:

```text
report/report.tex
report/report.pdf
AI_USE.md
```

Include `ai-records/` and related verification records when reasonably available,
as described in `AI_USE.md`, by the same document deadline. Submission IDs and
version descriptions belong in the report. Keep credentials and protected data
out of all submitted materials. All deadlines use `America/Chicago` time.
