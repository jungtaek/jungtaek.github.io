# AI Tool Use

Complete exactly one of the two declarations below and delete the declaration
that does not apply. Replace every bracketed prompt before submission.

This declaration covers AI assistance with algorithm ideas, implementation,
debugging, analysis of public code or maps, interpretation of results, and
report writing or editing. The five points for this component reward a complete
and accurate declaration, whether or not you used AI.

## Declaration A: No AI Tool Used

I did not use an AI tool for this assignment.

## Declaration B: AI Tool Used

### Tools and Models

Repeat these fields for each tool or model used.

- Tool: [tool name]
- Model: [model name as displayed by the tool, or explain why unavailable]
- Date or dates used: [date or date range]

### Purpose and Material Influence

- Purpose of each use: [what you asked the tool to help with, including
  unsuccessful or discarded assistance]
- Materially influenced work: [algorithm choices, solver versions, report
  sections, analysis, or other files; give paths where applicable, or state
  `None` with a brief explanation]
- Related submissions and versions: [Hugging Face submission IDs and the solver
  or report versions associated with the assistance, or `Not applicable`]
- Accepted, revised, or rejected suggestions: [summarize your decisions and
  distinguish the tool's contribution from your own work]

### Available Records

List the paths to all reasonably available, user-visible records related to
this assignment. Include exportable unsuccessful or discarded sessions.

- Chats, prompts, follow-ups, and responses: [paths, or `None available`]
- Supplied context, attachments, and accepted suggestions: [paths, or `None`]
- Approvals, errors, retries, and discarded sessions: [paths, or `None`]

If an otherwise expected record is unavailable, identify it and explain why.
Do not reconstruct hidden events or keystroke-level activity.

- Unavailable record and reason: [record and reason, or `None`]

### Coding Harness or Agent Evidence, If Applicable

- Available action or command logs: [paths, or `Not applicable`]
- Relevant configuration and permissions: [details or paths, or `Not applicable`]
- Verification results: [paths, or `Not applicable`]

### Student Review and Verification

- Available tool change summary or patch review: [paths or description, or
  `None available`]
- Review of AI-assisted work: [how you checked the algorithm, code, analysis,
  or report claims affected by AI assistance]
- Checks run and results: [commands, platform submissions, or other checks
  actually performed and their outcomes]
- Submission review: [how you checked that the report describes the intended
  solver versions and submission IDs, and that the files are ready to submit]
- Unresolved issues: [any AI-assisted suggestion or claim you could not verify,
  or `None`]

## Submission Reminder

Upload solver code to the Assignment 4 Hugging Face Space. Submit this completed
file with your report on Blackboard, together with reasonably available AI-use
records. Tool summaries do not replace your own review of the solver, results,
report, and submission files.

Do not submit credentials or protected data. If a required record contains a
sensitive value, replace only that value with `[REDACTED: category]` and leave
the rest of the record unchanged.
