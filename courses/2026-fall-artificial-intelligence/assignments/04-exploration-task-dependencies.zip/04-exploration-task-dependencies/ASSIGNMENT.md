# Assignment 4: Exploration and Task Dependencies

Design and implement an algorithm that explores a partially observed grid and
activates a goal through task dependencies using (EXPLO)²-Bench. Choose your own
strategy, develop it across at least three submissions, and explain your design
and results in a technical report.

## Resources

- [Assignment 4 Space](https://jungtaekkim-ai-fall-2026-assignment-4.hf.space):
  rules, interactive maps, algorithm submissions, submission history, and the
  official leaderboard.
- [Public repository](https://huggingface.co/spaces/jungtaekkim/ai-fall-2026-assignment-4):
  public maps, code, and evaluation instructions.
- [solver.py](solver.py).
- [Report template](report/report.tex) and [AI-use declaration](AI_USE.md).

You may use the public maps and code in the Assignment 4 Space repository to analyze your algorithm’s behavior and identify possible improvements.

## Problem

The agent must explore an initially unknown grid and activate the named goal
task. Visiting a task's cell discovers it. Activation occurs automatically on a
visit when its prerequisites are satisfied. A task discovered before it is ready
may therefore require a later visit. Reaching the goal's location is insufficient
unless the goal activates.

Prerequisites are alternatives of conjunctions. For example,
`[["A", "B"], ["C"]]` means **(A AND B) OR C**; `[[]]` means no prerequisites.
Knowing a task's token or its dependency relationships does not reveal its
location.

Coordinates are zero-based `(x, y)` pairs. Moving up increases `y`; moving right
increases `x`. Each action attempts one cardinal move, and invalid actions consume
a turn. The action budget is twice the number of open cells. The agent receives
neither that count nor the budget or remaining allowance. Activating the goal on
the final allowed action counts as success.

The Space provides 36 public example maps. Official evaluation uses 72 separate
private maps. Public-map results do not enter the
official leaderboard.

## Solver Interface

Implement the synchronous function `act(observation)` in `solver.py`. Each call
receives a Python dictionary and returns a move such as `{"move": "up"}`. The
allowed directions are `up`, `down`, `left`, and `right`. Return exactly one
`move` key; the interface also accepts a JSON string encoding that same object.

Observations provide the current position, elapsed action count, legal moves,
goal token, discovered and activated task tokens, and newly revealed dependency
information. Save task locations and dependency updates as they arrive: those
updates are incremental. The Space's **Rules & interface** tab documents every
field and provides examples.

A fresh process loads the file once per map. Module-level state persists between
calls within that episode and is reset for the next map. Use only the Python
standard library. The submission must be one UTF-8 Python file of at most
512 KiB. The evaluator allows 5 seconds for import readiness, 3 seconds per
action response, and 60 seconds of episode wall time.

Base decisions on the observations and information remembered within the current
episode. Full maps, seeds, hidden budgets, and feasibility-witness routes are not
agent inputs; do not embed map-specific layouts or solution routes in the solver.

## Development and Hosted Submissions

Submit at least **three implemented versions** through the Assignment 4 Space
before the announced deadline. A qualifying revision changes the solver's
behavior, such as its decision rule, parameter settings, memory handling, or a
bug fix. Identical reuploads and formatting-only edits do not count as additional
versions. Uploading the unchanged sample does not count as an implementation.
A revision need not improve performance to count.

1. Sign in with Hugging Face and enter your UARK ID without `@uark.edu`.
2. Upload the Python implementation with a descriptive algorithm label.
3. Save the submission receipt and submission ID. The Space assigns a persistent
   public name while keeping your identity and source code private.
4. Use **Check my submissions** to review your accepted submissions. Record the
   changes, reasons, and observations for each version in your report.

An accepted upload counts toward the submission requirement independently of
when the instructor evaluates it. Acceptance checks the file's syntax and
interface; it does not establish that the solver runs correctly or solves a map.
Official scores appear when results are published. A checkmark in **On
leaderboard** identifies the submission selected for the displayed publication.

The instructor uses the best completed evaluation among your submissions
received before the deadline for baseline credit and the ranking bonus. Selection
follows the leaderboard's ordering: more successful maps, lower mean actions,
lower median episode response time, and earlier submission time. An unsuccessful
revision does not replace a better earlier result.

## Report

Complete `report/report.tex` using the supplied NeurIPS 2026 style and compile
`report/report.pdf`. Keep the report to **at most seven pages**, including figures,
tables, and references, without changing fonts, margins, or spacing. Replace all
template prompts with your own explanations and evidence. Use these four sections:

1. **Algorithm Design.** Explain the information stored across calls, exploration
   and route choices, AND/OR dependency reasoning, and decisions to revisit tasks.
   Provide concise pseudocode and explain the important design choices.
2. **Development Across Submissions.** Identify at least three submission IDs,
   labels, and dates. Describe each version, why you changed it, and what you
   observed. Identify the implementation described by the report and the best
   officially selected submission; explain any difference between them.
3. **Results and Analysis.** Present evidence about the algorithm's behavior and
   interpret it. Explain the effects of design changes, examine concrete cases of
   success, failure, or inefficiency, and distinguish observations from proposed
   explanations. Identify the versions and conditions behind any comparisons.
4. **Official Baseline Comparison.** Compare the selected submission with
   `dfs_explorer`, `random_explorer`, and `bfs_explorer`, using results from the
   same official publication. State the submission ID, publication, successful
   maps, mean actions, median episode response time, and highest baseline tier
   exceeded.

Compile from `report/` so LaTeX finds the adjacent style:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Grading

| Component | Points |
| --- | ---: |
| Baseline performance | 15 |
| Three submissions and documented iteration | 20 |
| Algorithm design and understanding | 30 |
| Results and analysis | 30 |
| AI-use disclosure and verification | 5 |
| **Base total** | **100** |
| **Top-five ranking bonus** | **+10** |

### Baseline Performance: 15 Points

Compare the selected submission and the three named baselines on the same final
official evaluation suite. Exceeding a baseline means either solving more maps,
or solving the same number with a strictly lower mean action count. Comparisons
use unrounded measurements. Exact equality does not exceed a baseline. Runtime,
submission time, and display order do not affect this component.

| Highest baseline exceeded | Points |
| --- | ---: |
| `dfs_explorer` | 15 |
| `random_explorer`, but not `dfs_explorer` | 10 |
| `bfs_explorer`, but neither higher tier | 5 |
| None | 0 |

Award only the highest applicable tier. These points measure the implementation's
official performance; explaining those results is assessed under Results and
Analysis.

### Top-Five Ranking Bonus: 10 Additional Points

The top five **student ranks** in the final official evaluation receive ten
additional points each. 
Use the leaderboard's full ordering, including response time and submission
time, and the best eligible submission for each student.
Exact ties share a rank, with subsequent ranks skipped accordingly. Everyone
sharing fifth rank receives the bonus, even if that produces more than five
recipients.

## Submission Materials

Submit your implementations through the Assignment 4 Space. Submit the following
documents to Blackboard, preserving these paths:

```text
report/report.tex
report/report.pdf
AI_USE.md
```

Include `ai-records/` and related verification records when reasonably available,
as described in `AI_USE.md`. Submission IDs and version descriptions belong in
the report. Keep credentials and protected data out of all submitted materials.
Use the assignment deadlines announced on Blackboard.
