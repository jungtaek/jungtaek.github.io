"""Submission template for Assignment 4; implement your own exploration algorithm.

Each map is evaluated once. A new process loads this module once for each map.
Module-level state persists between calls within that episode. Only observation
fields are available.
"""

memory = {}


def act(observation):
    """Return a dictionary with "move" set to "up", "down", "left", or "right".

    Coordinates are (x, y), with up increasing y. Dependency updates are
    incremental; retain discoveries in memory. Do not rely on full map data.
    """
    raise NotImplementedError("Implement your exploration algorithm using observations here.")
