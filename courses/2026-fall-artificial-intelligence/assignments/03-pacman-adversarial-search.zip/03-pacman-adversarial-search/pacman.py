"""Supplied, deterministic two-player Pac-Man adaptation; no student TODOs.

Coordinates are (row, column), starting at the top left. Pac-Man is MAX and
moves first; one ghost is MIN. Every action, including WAIT, consumes one ply.
The maze and all game rules are original course materials, not GameWorld code.
"""

from __future__ import annotations

import json
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

Cell = tuple[int, int]
Board = tuple[str, ...]
ACTION_ORDER = ("UP", "RIGHT", "DOWN", "LEFT", "WAIT")
_DELTAS: Mapping[str, Cell] = MappingProxyType({
    "UP": (-1, 0),
    "RIGHT": (0, 1),
    "DOWN": (1, 0),
    "LEFT": (0, -1),
    "WAIT": (0, 0),
})


def _is_cell(value: object) -> bool:
    return (isinstance(value, tuple) and len(value) == 2
            and all(type(coordinate) is int and coordinate >= 0 for coordinate in value))


@dataclass(frozen=True)
class GameState:
    """An immutable state; pellets are the remaining pellet coordinates.

    remaining_plies counts individual moves, not pairs of player moves.
    Board-dependent validation is performed by PacmanProblem.
    """

    pacman: Cell
    ghost: Cell
    pellets: frozenset[Cell]
    to_move: str
    remaining_plies: int

    def __post_init__(self) -> None:
        if not _is_cell(self.pacman) or not _is_cell(self.ghost):
            raise ValueError("player coordinates must be (row, column) tuples of nonnegative integers")
        if not isinstance(self.pellets, frozenset) or any(not _is_cell(cell) for cell in self.pellets):
            raise ValueError("pellets must be a frozenset of (row, column) integer tuples")
        if self.to_move not in ("MAX", "MIN"):
            raise ValueError("to_move must be 'MAX' or 'MIN'")
        if type(self.remaining_plies) is not int or self.remaining_plies < 0:
            raise ValueError("remaining_plies must be a nonnegative integer, not a bool")


@dataclass(frozen=True)
class PacmanProblem:
    """A finite, fully observable, alternating-turn, zero-sum game.

    Construct with board rows containing '#', space, 'P', 'G', and '.'. Exactly
    one P, one G, and at least one pellet are required. All floor cells must be
    connected. The stored board contains only walls and spaces; positions and
    pellets belong to initial_state. There are no power pellets or wraparound.
    """

    name: str
    board: Board
    max_plies: int
    description: str = ""
    initial_state: GameState = field(init=False)
    _floor: frozenset[Cell] = field(init=False, repr=False)
    _initial_pellets: frozenset[Cell] = field(init=False, repr=False)
    _distances: Mapping[tuple[Cell, Cell], int] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("name must be a nonempty string")
        if not isinstance(self.description, str):
            raise ValueError("description must be a string")
        if type(self.max_plies) is not int or self.max_plies <= 0:
            raise ValueError("max_plies must be a positive integer, not a bool")
        if not isinstance(self.board, (list, tuple)) or not self.board:
            raise ValueError("board must be a nonempty sequence of rows")
        if not isinstance(self.board[0], str) or not self.board[0]:
            raise ValueError("board rows must be nonempty strings")
        width = len(self.board[0])
        if any(not isinstance(row, str) or len(row) != width
               or set(row) - {"#", " ", "P", "G", "."} for row in self.board):
            raise ValueError("board must be rectangular and contain only '#', space, 'P', 'G', and '.'")
        pacmen = [(row, column) for row, cells in enumerate(self.board)
                  for column, cell in enumerate(cells) if cell == "P"]
        ghosts = [(row, column) for row, cells in enumerate(self.board)
                  for column, cell in enumerate(cells) if cell == "G"]
        pellets = frozenset((row, column) for row, cells in enumerate(self.board)
                            for column, cell in enumerate(cells) if cell == ".")
        floor = frozenset((row, column) for row, cells in enumerate(self.board)
                          for column, cell in enumerate(cells) if cell != "#")
        if len(pacmen) != 1 or len(ghosts) != 1:
            raise ValueError("board must contain exactly one P and exactly one G")
        if not pellets:
            raise ValueError("board must contain at least one pellet")
        distances: dict[tuple[Cell, Cell], int] = {}
        for start in sorted(floor):
            pending = deque([start])
            found = {start: 0}
            while pending:
                current = pending.popleft()
                for delta_row, delta_column in tuple(_DELTAS.values())[:4]:
                    neighbor = (current[0] + delta_row, current[1] + delta_column)
                    if neighbor in floor and neighbor not in found:
                        found[neighbor] = found[current] + 1
                        pending.append(neighbor)
            if len(found) != len(floor):
                raise ValueError("all non-wall cells must be connected")
            distances.update(((start, end), distance) for end, distance in found.items())
        object.__setattr__(self, "board", tuple(
            "".join("#" if cell == "#" else " " for cell in row) for row in self.board
        ))
        object.__setattr__(self, "_floor", floor)
        object.__setattr__(self, "_initial_pellets", pellets)
        object.__setattr__(self, "_distances", MappingProxyType(distances))
        object.__setattr__(self, "initial_state", GameState(
            pacmen[0], ghosts[0], pellets, "MAX", self.max_plies
        ))

    @classmethod
    def from_dict(cls, data: object) -> PacmanProblem:
        """Load the documented JSON schema, rejecting unknown fields."""
        if not isinstance(data, dict):
            raise ValueError("level must be a JSON object")
        required = {"name", "board", "max_plies"}
        allowed = required | {"description"}
        if not required <= data.keys():
            raise ValueError(f"level is missing required fields: {sorted(required - data.keys())}")
        if data.keys() - allowed:
            raise ValueError(f"unknown level fields: {sorted(map(str, data.keys() - allowed))}")
        return cls(**data)

    @classmethod
    def from_file(cls, path: str | Path) -> PacmanProblem:
        with Path(path).open(encoding="utf-8") as handle:
            return cls.from_dict(json.load(handle))

    @property
    def width(self) -> int:
        return len(self.board[0])

    @property
    def height(self) -> int:
        return len(self.board)

    @property
    def initial_pellets(self) -> frozenset[Cell]:
        return self._initial_pellets

    def validate_state(self, state: GameState) -> GameState:
        """Reject states that cannot be represented on this problem's maze.

        This checks local consistency, not reachability from initial_state, so
        tests may construct intermediate positions directly.
        """
        if not isinstance(state, GameState):
            raise ValueError("state must be a GameState")
        if state.pacman not in self._floor or state.ghost not in self._floor:
            raise ValueError("both player positions must be floor cells")
        if not state.pellets <= self._initial_pellets:
            raise ValueError("remaining pellets must be a subset of the initial pellets")
        if state.pacman in state.pellets:
            raise ValueError("Pac-Man's current cell cannot contain an uncollected pellet")
        if state.remaining_plies > self.max_plies:
            raise ValueError("remaining_plies cannot exceed max_plies")
        return state

    def to_move(self, state: GameState) -> str:
        return self.validate_state(state).to_move

    @staticmethod
    def _outcome(state: GameState) -> str | None:
        if state.pacman == state.ghost:
            return "capture"
        if not state.pellets:
            return "win"
        if state.remaining_plies == 0:
            return "timeout"
        return None

    def outcome(self, state: GameState) -> str | None:
        """Capture has priority over completion; completion precedes timeout."""
        return self._outcome(self.validate_state(state))

    def terminal(self, state: GameState) -> bool:
        return self.outcome(state) is not None

    def actions(self, state: GameState) -> tuple[str, ...]:
        """Legal actions in UP, RIGHT, DOWN, LEFT, WAIT order; () at terminals.

        Moving onto the opponent is legal and immediately ends in capture.
        """
        self.validate_state(state)
        if self._outcome(state) is not None:
            return ()
        row, column = state.pacman if state.to_move == "MAX" else state.ghost
        return tuple(action for action, (delta_row, delta_column) in _DELTAS.items()
                     if (row + delta_row, column + delta_column) in self._floor)

    def result(self, state: GameState, action: str) -> GameState:
        """Apply one legal move, collect a pellet on MAX's move, and alternate."""
        if action not in self.actions(state):
            raise ValueError(f"illegal action: {action!r}")
        delta_row, delta_column = _DELTAS[action]
        if state.to_move == "MAX":
            pacman = (state.pacman[0] + delta_row, state.pacman[1] + delta_column)
            return GameState(pacman, state.ghost, state.pellets - {pacman},
                             "MIN", state.remaining_plies - 1)
        ghost = (state.ghost[0] + delta_row, state.ghost[1] + delta_column)
        return GameState(state.pacman, ghost, state.pellets,
                         "MAX", state.remaining_plies - 1)

    def utility(self, state: GameState) -> float:
        """Return fixed MAX-perspective terminal utility; reject nonterminals."""
        outcome = self.outcome(state)
        if outcome is None:
            raise ValueError("utility is defined only for terminal states")
        return 1.0 if outcome == "win" else -1.0

    def distance(self, start: Cell, end: Cell) -> int:
        """Shortest floor-path length, ignoring players and remaining pellets."""
        if not _is_cell(start) or not _is_cell(end) or start not in self._floor or end not in self._floor:
            raise ValueError("distance endpoints must be floor-cell (row, column) tuples")
        return self._distances[start, end]

    def evaluate(self, state: GameState) -> float:
        """Return utility at terminals; otherwise a fixed MAX-perspective score.

        Let p be the fraction of initial pellets collected, f the distance to
        the nearest remaining pellet, and g the distance to the ghost. Return
        0.6*p + 0.2/(1+f) + 0.2*g/(1+g) - 0.5. The heuristic lies strictly
        between -1 and +1, and does not change sign with the player to move.
        Distances follow maze paths, not straight lines or Manhattan distance.
        """
        outcome = self.outcome(state)
        if outcome is not None:
            return 1.0 if outcome == "win" else -1.0
        progress = 1.0 - len(state.pellets) / len(self._initial_pellets)
        food_distance = min(self._distances[state.pacman, pellet] for pellet in state.pellets)
        ghost_distance = self._distances[state.pacman, state.ghost]
        return (0.6 * progress + 0.2 / (1 + food_distance)
                + 0.2 * ghost_distance / (1 + ghost_distance) - 0.5)

    def chasing_action(self, state: GameState) -> str:
        """Choose MIN's shortest-path chase action; break ties canonically.

        This supplied gameplay opponent is a policy, not the model used by
        minimax or MCTS. Search must consider every legal MIN action.
        """
        self.validate_state(state)
        if self._outcome(state) is not None or state.to_move != "MIN":
            raise ValueError("chasing_action requires a nonterminal MIN state")
        return min(self.actions(state), key=lambda action: self._distances[
            (state.ghost[0] + _DELTAS[action][0], state.ghost[1] + _DELTAS[action][1]),
            state.pacman,
        ])
