# Third-Party Notices

## Game selection and course adaptation

This assignment selects **Pac-Man**, listed as game 23 in the
[GameWorld game suite](https://gameworld-project.github.io/) and as
`23_pacman` in the
[GameWorld Games collection](https://github.com/gameworld-project/GameWorld-Games).

The supplied Python engine, level instances, search scaffolding, and offline
viewer are original course materials. They model a deterministic, alternating-turn
game between one Pac-Man and one ghost on a small fixed maze with pellets and
a finite move limit. This two-player model is a course adaptation of the
single-player game; it omits real-time movement, power pellets, additional
ghosts, and chance events. The assignment does not use GameWorld's browser
API or reproduce its benchmark tasks.

No source code, renderer, artwork, sound, dependency, or other asset from a
Pac-Man implementation or the GameWorld collection is included. The game name
identifies the selected game; it does not imply endorsement or affiliation.
