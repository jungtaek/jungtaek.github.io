"""Play a complete Pac-Man game and write a self-contained offline replay."""

from __future__ import annotations

import argparse
from dataclasses import fields, is_dataclass
import json
import math
from pathlib import Path
from typing import Any, Sequence

from pacman import PacmanProblem
from adversarial_search import (
    SearchResult, alpha_beta_search, minimax_search,
    monte_carlo_tree_search, random_search,
)


ASSIGNMENT_DIR = Path(__file__).resolve().parent
DEFAULT_LEVEL = ASSIGNMENT_DIR / "levels" / "routes.json"
DEFAULT_TEMPLATE = ASSIGNMENT_DIR / "viewer" / "template.html"
TRACE_PLACEHOLDER = "__TRACE_JSON__"
ALGORITHMS = ("random", "minimax", "alphabeta", "mcts")
COUNT_FIELDS = (
    "successor_count", "evaluation_count", "rollout_steps", "stored_nodes",
    "iterations", "cutoff_count", "pruned_actions", "frame_count",
)
PER_DECISION_FIELDS = ("successors_per_decision", "evaluations_per_decision")


class RootedProblem:
    """Expose the supplied game at a new root without changing engine state."""

    def __init__(self, problem: PacmanProblem, state: Any):
        self.initial_state = state
        self._problem = problem

    def __getattr__(self, name: str) -> Any:
        return getattr(self._problem, name)


def json_value(value: Any) -> Any:
    """Convert frozen records and pellet sets to deterministic JSON values."""

    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: json_value(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, dict):
        return {key: json_value(item) for key, item in value.items()}
    if isinstance(value, (set, frozenset)):
        return [json_value(item) for item in sorted(value)]
    if isinstance(value, (tuple, list)):
        return [json_value(item) for item in value]
    return value


def validate_options(*, depth: int, order: str, iterations: int,
                     seed: int, exploration: float) -> None:
    for name, value, minimum in (("depth", depth, 1), ("iterations", iterations, 1), ("seed", seed, 0)):
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            raise ValueError(f"{name} must be an integer at least {minimum}")
    if order not in ("canonical", "reverse"):
        raise ValueError("order must be canonical or reverse")
    if isinstance(exploration, bool) or not isinstance(exploration, (int, float)) or not math.isfinite(exploration) or exploration <= 0:
        raise ValueError("exploration must be a finite positive number")


def run_algorithm(problem: Any, *, algorithm: str = "random", depth: int = 4,
                  order: str = "canonical", iterations: int = 200, seed: int = 7,
                  exploration: float = math.sqrt(2)) -> SearchResult:
    """Dispatch CLI labels; the random baseline works in the starter package."""

    validate_options(depth=depth, order=order, iterations=iterations,
                     seed=seed, exploration=exploration)
    if algorithm == "random":
        return random_search(problem, seed=seed)
    if algorithm == "minimax":
        return minimax_search(problem, depth=depth, order=order)
    if algorithm == "alphabeta":
        return alpha_beta_search(problem, depth=depth, order=order)
    if algorithm == "mcts":
        return monte_carlo_tree_search(problem, iterations=iterations,
                                      seed=seed, exploration=exploration)
    raise ValueError(f"unknown algorithm: {algorithm!r}")


def trace_payload(problem: PacmanProblem, *, algorithm: str = "random",
                  seed: int = 7, level: str = "",
                  depth: int = 4, order: str = "canonical", iterations: int = 200,
                  exploration: float = math.sqrt(2)) -> dict[str, Any]:
    """Record Python's decisions and actual moves; the browser never plays AI.

    Each MAX decision starts a fresh search, with seed + its zero-based decision
    index. MIN follows the supplied deterministic chasing policy.
    Search counts exclude the separately recorded actual gameplay transitions.
    """

    if algorithm not in ALGORITHMS:
        raise ValueError(f"unknown algorithm: {algorithm!r}")
    configuration = dict(depth=depth, order=order, iterations=iterations,
                         exploration=exploration)
    validate_options(seed=seed, **configuration)
    state = problem.initial_state
    snapshots = [dict(state=state, actor=None, action=None, decision_index=None,
                      outcome=problem.outcome(state))]
    decisions = []
    totals = dict.fromkeys(COUNT_FIELDS, 0)

    def decide(current: Any) -> SearchResult:
        index = len(decisions)
        result = run_algorithm(RootedProblem(problem, current), algorithm=algorithm,
                               seed=seed + index, **configuration)
        if not problem.terminal(current) and result.action not in problem.actions(current):
            raise ValueError(f"search returned an illegal action: {result.action!r}")
        decisions.append(dict(move_index=len(snapshots) - 1, seed=seed + index,
                              result=result))
        for name in COUNT_FIELDS:
            totals[name] += getattr(result, name)
        return result

    while not problem.terminal(state):
        actor = state.to_move
        decision_index = None
        if actor == "MAX":
            decision_index = len(decisions)
            action = decide(state).action
        else:
            action = problem.chasing_action(state)
        if action not in problem.actions(state):
            raise ValueError(f"gameplay received an illegal action: {action!r}")
        state = problem.result(state, action)
        snapshots.append(dict(state=state, actor=actor, action=action,
                              decision_index=decision_index,
                              outcome=problem.outcome(state)))
    outcome = problem.outcome(state)
    summary = dict(
        **totals, utility=problem.utility(state),
        outcome=outcome, plies=len(snapshots) - 1, decisions=len(decisions),
        pellets_collected=len(problem.initial_state.pellets) - len(state.pellets),
        successors_per_decision=totals["successor_count"] / len(decisions) if decisions else None,
        evaluations_per_decision=totals["evaluation_count"] / len(decisions) if decisions else None,
    )
    return json_value(dict(
        schema_version=2, algorithm=algorithm, seed=seed, level=level,
        name=problem.name, description=problem.description, board=problem.board,
        max_plies=problem.max_plies, configuration=configuration, summary=summary,
        snapshots=snapshots, decisions=decisions,
    ))


def build_demo_html(payload: dict[str, Any], template: str) -> str:
    if template.count(TRACE_PLACEHOLDER) != 1:
        raise ValueError("viewer template must contain exactly one payload placeholder")
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    encoded = encoded.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return template.replace(TRACE_PLACEHOLDER, encoded)


def validate_output(output_path: Path, *protected_paths: Path) -> None:
    """Permit repeat generated runs while protecting supplied source material."""

    if output_path.is_symlink():
        raise ValueError("replay output must not be a symbolic link")
    resolved = output_path.resolve()
    protected_dirs = tuple(ASSIGNMENT_DIR / name for name in ("viewer", "levels", "tests", "report"))
    if any(resolved.is_relative_to(path.resolve()) for path in protected_dirs) or resolved in {path.resolve() for path in protected_paths}:
        raise ValueError("output must not overwrite supplied files or input data")
    if output_path.suffix.lower() != ".html":
        raise ValueError("replay output must have the .html suffix")


def write_demo(level_path: Path, output_path: Path, *, algorithm: str = "random",
               depth: int = 4, order: str = "canonical",
               iterations: int = 200, seed: int = 7,
               exploration: float = math.sqrt(2),
               template_path: Path = DEFAULT_TEMPLATE) -> dict[str, Any]:
    """Return the same payload embedded in the written replay."""

    validate_output(output_path, level_path, template_path)
    problem = PacmanProblem.from_file(level_path)
    payload = trace_payload(problem, algorithm=algorithm, seed=seed,
                            level=level_path.name, depth=depth, order=order,
                            iterations=iterations, exploration=exploration)
    rendered = build_demo_html(payload, template_path.read_text(encoding="utf-8"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered, encoding="utf-8")
    return payload


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithm", choices=ALGORITHMS, default="random")
    parser.add_argument("--level", type=Path, default=DEFAULT_LEVEL)
    parser.add_argument("--depth", type=int, default=4)
    parser.add_argument("--order", choices=("canonical", "reverse"), default="canonical")
    parser.add_argument("--iterations", type=int, default=200)
    parser.add_argument("--exploration", type=float, default=math.sqrt(2))
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", type=Path, default=Path("results.html"))
    args = parser.parse_args(argv)
    try:
        payload = write_demo(args.level, args.output, **{
            name: getattr(args, name) for name in (
                "algorithm", "depth", "order", "iterations", "exploration", "seed",
            )
        })
    except (NotImplementedError, OSError, TypeError, ValueError) as error:
        parser.exit(1, f"error: {error}\n")
    summary = payload["summary"]
    print(f"outcome: {summary['outcome']}; utility for MAX: {summary['utility']:g}")
    print(f"successor calls: {summary['successor_count']}; evaluations: {summary['evaluation_count']}")
    print(f"wrote: {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
