"""Supplied adversarial-search infrastructure and three student TODO functions.

All utilities and statistics use MAX's perspective. Algorithms use the public
game interface through SearchContext; instructor tests can supply abstract
game trees. The random one-move baseline works in the untouched starter.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from numbers import Real
import random
from typing import Hashable, Iterable, Protocol


State = Hashable
Action = str
MAX_TRACE_FRAMES = 2000


class Problem(Protocol):
    initial_state: State

    def to_move(self, state: State) -> str:
        """Return 'MAX' or 'MIN', including at terminal states."""

    def actions(self, state: State) -> tuple[Action, ...]:
        """Return distinct actions in canonical order; empty only at terminals."""

    def result(self, state: State, action: Action) -> State:
        """Return the immutable successor after one deterministic move."""

    def terminal(self, state: State) -> bool:
        """Return whether play has ended."""

    def utility(self, state: State) -> float:
        """Return terminal utility in [-1, 1], from MAX's perspective."""

    def evaluate(self, state: State) -> float:
        """Return nonterminal cutoff evaluation strictly between -1 and 1."""


def require_int(value: int, name: str, minimum: int = 0) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")


def require_finite(value: float, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except (OverflowError, ValueError) as error:
        raise ValueError(f"{name} must be a finite real number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite real number")
    return result


def validate_depth(depth: int) -> None:
    require_int(depth, "depth", 1)


def validate_mcts(iterations: int, exploration: float) -> None:
    require_int(iterations, "iterations", 1)
    if require_finite(exploration, "exploration") <= 0:
        raise ValueError("exploration must be positive")


def _check_state(state: State) -> None:
    try:
        hash(state)
    except TypeError as error:
        raise ValueError("states must be hashable") from error


class RandomSource:
    """Private seeded index draws, optionally replaced by a literal test script.

    A scripted value is an index, not a seed or a value reduced modulo size.
    An exhausted script raises StopIteration, detecting unexpected extra draws.
    Even an index draw from a singleton action list consumes one script item.
    """

    def __init__(self, seed: int = 0, *, integers: Iterable[int] | None = None) -> None:
        require_int(seed, "seed")
        self._random = random.Random(seed)
        self._integers = None if integers is None else iter(integers)

    def index(self, size: int) -> int:
        require_int(size, "choice size", 1)
        value = self._random.randrange(size) if self._integers is None else next(self._integers)
        require_int(value, "scripted index")
        if value >= size:
            raise ValueError("scripted index is outside the choice range")
        return value


@dataclass(frozen=True)
class RootStat:
    action: Action
    visits: int
    value: float | None


@dataclass(frozen=True)
class SearchFrame:
    event: str
    state: State
    depth: int | None = None
    action: Action | None = None
    value: float | None = None
    alpha: float | None = None
    beta: float | None = None
    skipped: tuple[Action, ...] = ()
    iteration: int | None = None
    root_stats: tuple[RootStat, ...] = ()


@dataclass(frozen=True)
class SearchResult:
    action: Action | None
    value: float
    successor_count: int
    evaluation_count: int
    rollout_steps: int
    stored_nodes: int
    iterations: int
    cutoff_count: int
    pruned_actions: int
    frames: tuple[SearchFrame, ...]
    frame_count: int
    root_stats: tuple[RootStat, ...] = ()


@dataclass(eq=False)
class Node:
    """One stored MCTS node; rollout-only states never become these nodes.

    new_node initializes untried; students remove an action when expanding,
    append the new child to children, and update visits/total_return themselves.
    Parent links are not serialized into replay data.
    """

    state: State
    parent: Node | None = None
    action: Action | None = None
    children: list[Node] = field(default_factory=list)
    untried: list[Action] = field(default_factory=list)
    visits: int = 0
    total_return: float = 0.0
    action_order: tuple[Action, ...] = ()


def root_statistics(root: Node) -> tuple[RootStat, ...]:
    """Include unexpanded actions with zero visits and an undefined mean."""
    children = {child.action: child for child in root.children}
    result = []
    for action in root.action_order:
        child = children.get(action)
        visits = 0 if child is None else child.visits
        result.append(RootStat(
            action, visits,
            None if visits == 0 else child.total_return / visits,
        ))
    return tuple(result)


class SearchContext:
    """Supplied validation, accounting, node allocation, and trace recording.

    Use one context per search. Every successor call counts, including repeated
    states and rollout transitions. Pure comparisons, action enumeration, and
    statistics updates consume no successor calls. Each evaluate call counts
    one leaf evaluation, even if that terminal was evaluated before.
    """

    def __init__(self, problem: Problem, *, seed: int = 0, order: str = "canonical") -> None:
        require_int(seed, "seed")
        if order not in ("canonical", "reverse"):
            raise ValueError("order must be 'canonical' or 'reverse'")
        self.problem = problem
        self.initial = problem.initial_state
        _check_state(self.initial)
        self.order = order
        self.rng = RandomSource(seed)
        self.successor_count = 0
        self.evaluation_count = 0
        self.rollout_steps = 0
        self.stored_nodes = 0
        self.iterations = 0
        self.cutoff_count = 0
        self.pruned_actions = 0
        self.frames: list[SearchFrame] = []
        self.frame_count = 0
        self.player(self.initial)
        self.actions(self.initial)

    def player(self, state: State) -> str:
        player = self.problem.to_move(state)
        if player not in ("MAX", "MIN"):
            raise ValueError("to_move must return 'MAX' or 'MIN'")
        return player

    def terminal(self, state: State) -> bool:
        result = self.problem.terminal(state)
        if not isinstance(result, bool):
            raise ValueError("terminal must return a Boolean")
        return result

    def actions(self, state: State) -> tuple[Action, ...]:
        actions = self.problem.actions(state)
        if not isinstance(actions, tuple) or any(
            not isinstance(action, str) or not action for action in actions
        ):
            raise ValueError("actions must be a tuple of nonempty strings")
        if len(set(actions)) != len(actions):
            raise ValueError("actions must be distinct")
        if bool(actions) == self.terminal(state):
            raise ValueError("exactly terminal states must have no actions")
        return actions if self.order == "canonical" else tuple(reversed(actions))

    def successor(self, state: State, action: Action, *, rollout: bool = False) -> State:
        if not isinstance(rollout, bool):
            raise ValueError("rollout must be a Boolean")
        if action not in self.actions(state):
            raise ValueError(f"illegal action: {action!r}")
        successor = self.problem.result(state, action)
        _check_state(successor)
        if self.player(successor) == self.player(state):
            raise ValueError("successors must alternate the player to move")
        self.successor_count += 1
        if rollout:
            self.rollout_steps += 1
        return successor

    def _record(self, frame: SearchFrame) -> None:
        self.frame_count += 1
        if len(self.frames) <= MAX_TRACE_FRAMES:
            self.frames.append(frame)
        else:
            self.frames[-1] = frame

    def evaluate(self, state: State, *, depth: int | None = None, record: bool = True) -> float:
        if depth is not None:
            require_int(depth, "remaining depth")
        if not isinstance(record, bool):
            raise ValueError("record must be a Boolean")
        terminal = self.terminal(state)
        value = require_finite(
            self.problem.utility(state) if terminal else self.problem.evaluate(state),
            "utility" if terminal else "evaluation",
        )
        if not (-1 <= value <= 1) or (not terminal and abs(value) >= 1):
            raise ValueError("terminal values must be in [-1, 1]; cutoff values in (-1, 1)")
        self.evaluation_count += 1
        if record:
            self._record(SearchFrame("terminal" if terminal else "cutoff", state, depth=depth, value=value))
        return value

    def record_backup(self, state: State, depth: int, action: Action, value: float) -> None:
        require_int(depth, "remaining depth", 1)
        if action not in self.actions(state):
            raise ValueError("backup action must be legal")
        value = require_finite(value, "backed-up value")
        if not -1 <= value <= 1:
            raise ValueError("backed-up value must be in [-1, 1]")
        self._record(SearchFrame("backup", state, depth=depth, action=action, value=value))

    def record_prune(
        self, state: State, depth: int, alpha: float, beta: float,
        skipped: tuple[Action, ...],
    ) -> None:
        require_int(depth, "remaining depth", 1)
        if not isinstance(skipped, tuple) or not skipped:
            raise ValueError("a prune frame needs at least one skipped action")
        actions = self.actions(state)
        if len(set(skipped)) != len(skipped) or any(action not in actions for action in skipped):
            raise ValueError("skipped actions must be distinct legal actions")
        for value in (alpha, beta):
            if isinstance(value, bool) or not isinstance(value, Real) or math.isnan(value):
                raise ValueError("bounds must be real and not NaN")
        if alpha < beta:
            raise ValueError("a cutoff requires alpha >= beta")
        self.cutoff_count += 1
        self.pruned_actions += len(skipped)
        self._record(SearchFrame(
            "prune", state, depth=depth,
            alpha=float(alpha) if math.isfinite(alpha) else None,
            beta=float(beta) if math.isfinite(beta) else None, skipped=skipped,
        ))

    def new_node(self, state: State, parent: Node | None = None, action: Action | None = None) -> Node:
        """Allocate one node without linking it into parent.children."""
        actions = self.actions(state)
        self.stored_nodes += 1
        return Node(state, parent, action, untried=list(actions), action_order=actions)

    def record_iteration(self, root: Node) -> None:
        """Call once after students have backpropagated a completed iteration."""
        self.iterations += 1
        self._record(SearchFrame(
            "iteration", root.state, iteration=self.iterations,
            root_stats=root_statistics(root),
        ))

    def finish(self, action: Action | None, value: float, *, root: Node | None = None) -> SearchResult:
        legal = self.actions(self.initial)
        if (action is None and legal) or (action is not None and action not in legal):
            raise ValueError("result action must be legal, or None at a terminal root")
        value = require_finite(value, "result value")
        if not -1 <= value <= 1:
            raise ValueError("result value must be in [-1, 1]")
        return SearchResult(
            action=action, value=value, successor_count=self.successor_count,
            evaluation_count=self.evaluation_count, rollout_steps=self.rollout_steps,
            stored_nodes=self.stored_nodes, iterations=self.iterations,
            cutoff_count=self.cutoff_count, pruned_actions=self.pruned_actions,
            frames=tuple(self.frames), frame_count=self.frame_count,
            root_stats=() if root is None else root_statistics(root),
        )


def random_search(problem: Problem, *, seed: int = 0) -> SearchResult:
    """Choose one uniformly random legal root move, then evaluate its child.

    This is a one-move baseline, not a random tree search or a rollout. A
    terminal root consumes no random draw and returns its exact utility.
    """
    context = SearchContext(problem, seed=seed)
    state = context.initial
    if context.terminal(state):
        return context.finish(None, context.evaluate(state))
    actions = context.actions(state)
    action = actions[context.rng.index(len(actions))]
    child = context.successor(state, action)
    value = context.evaluate(child, depth=0)
    context.record_backup(state, 1, action, value)
    return context.finish(action, value)


def minimax_search(problem: Problem, *, depth: int = 4, order: str = "canonical") -> SearchResult:
    """TODO: implement depth-limited minimax using one SearchContext.

    Validate depth with validate_depth; the context validates order. Test
    terminal before depth zero, evaluating each reached leaf exactly once.
    Otherwise visit every action in context order, maximizing for MAX and
    minimizing for MIN. Keep the first equal-valued action. Generate children
    lazily through context.successor. After every nonleaf backup, call
    record_backup(state, remaining_depth, chosen_action, value). Return
    context.finish(root_action, root_value), or (None, utility) at a terminal
    root. Depth is measured in individual actions, not pairs of turns.
    """
    raise NotImplementedError("Implement minimax_search in adversarial_search.py")


def alpha_beta_search(problem: Problem, *, depth: int = 4, order: str = "canonical") -> SearchResult:
    """TODO: implement fail-soft alpha-beta with the same minimax contract.

    Start the root window at (-infinity, +infinity). Update alpha at MAX and
    beta at MIN; stop the child loop when alpha >= beta. Generate only children
    that are actually searched. Before the usual backup frame, record_prune
    with the remaining action suffix if it is nonempty. Return the best value
    actually seen, not the window endpoint. Internal pruned values can be
    bounds; the returned root value is the depth-limited minimax value.
    Strict improvement and context order determine all ties. Do not call the
    TODO minimax function or precompute all child states before pruning.
    """
    raise NotImplementedError("Implement alpha_beta_search in adversarial_search.py")


def monte_carlo_tree_search(
    problem: Problem, *, iterations: int = 200, seed: int = 0,
    exploration: float = math.sqrt(2),
) -> SearchResult:
    """TODO: implement Deck 12 MCTS with exactly iterations completed samples.

    Validate iterations/exploration with validate_mcts; use one seeded context.
    A terminal root is evaluated once, with no node allocation or iterations.
    Otherwise allocate the root with new_node. Select until terminal or untried
    actions remain; at a fully expanded node choose the child maximizing
    sigma(parent_player)*child.total_return/child.visits
      + exploration*sqrt(log(parent.visits)/child.visits).
    sigma is +1 for MAX, -1 for MIN; the exploration term stays positive.
    Break ties by canonical action order. Expand the first untried action,
    removing it and linking exactly one new child. Simulate uniformly to a
    terminal, consuming one rng.index draw for every rollout action, including
    forced moves. Use successor(..., rollout=True) only in that simulation.
    Evaluate the terminal exactly once with record=False; no cutoff heuristic
    or rollout states belong to the stored tree. Increment visits and add the
    SAME terminal return on the entire ancestor path, including the root.
    record_iteration(root) then records statistics. A selected terminal node
    skips expansion/simulation but still receives a new evaluation and backup.
    Finish with the most-visited root child (canonical ties), its mean return,
    and root=root. No random draws occur in selection, expansion, or ties.
    """
    raise NotImplementedError("Implement monte_carlo_tree_search in adversarial_search.py")
