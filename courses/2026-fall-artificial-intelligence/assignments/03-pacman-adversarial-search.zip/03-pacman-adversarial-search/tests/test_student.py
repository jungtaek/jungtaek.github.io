"""Add your independent tests here; do not edit tests/test_public.py.

Before implementing a TODO, add a numerical test that calls one required search
function and record its initial NotImplementedError. Derive expected values by
hand, not by running the implementation under test. The empty suite initially
runs no tests and provides no evidence that an algorithm is correct.
"""

import unittest


if __name__ == "__main__":
    unittest.main()
