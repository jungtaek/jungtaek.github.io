"""Public infrastructure tests and the student's independent test module."""
