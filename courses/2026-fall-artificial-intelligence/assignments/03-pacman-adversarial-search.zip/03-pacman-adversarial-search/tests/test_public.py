"""Transparent checks of supplied rules, helpers, baseline, and replay plumbing.

All tests pass in the untouched starter. These checks do not establish the
correctness of the three student algorithms or replace independent tests.
"""

from __future__ import annotations

from contextlib import redirect_stdout
from dataclasses import FrozenInstanceError, replace
import io
import json
import math
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch

import adversarial_search as search
from pacman import ACTION_ORDER, GameState, PacmanProblem


ASSIGNMENT_DIR = Path(__file__).resolve().parents[1]


class TinyGame:
    """A visible two-ply game for testing supplied infrastructure only."""

    initial_state = "S"
    edges = {"S": (("left", "A"), ("right", "B")),
             "A": (("finish", "W"),), "B": (("finish", "L"),),
             "W": (), "L": ()}
    players = {"S": "MAX", "A": "MIN", "B": "MIN", "W": "MAX", "L": "MAX"}

    def to_move(self, state):
        return self.players[state]

    def actions(self, state):
        return tuple(action for action, _ in self.edges[state])

    def result(self, state, action):
        return dict(self.edges[state])[action]

    def terminal(self, state):
        return not self.edges[state]

    def utility(self, state):
        return {"W": 1.0, "L": -1.0}[state]

    def evaluate(self, state):
        return {"S": 0.0, "A": 0.25, "B": -0.5}[state]


def corridor(**changes):
    data = {"name": "corridor", "board": ["#######", "#P . G#", "#######"], "max_plies": 12}
    data.update(changes)
    return PacmanProblem.from_dict(data)


class TestGameModel(unittest.TestCase):
    def test_initial_state_and_canonical_actions(self):
        problem = corridor()
        state = problem.initial_state
        self.assertEqual(state, GameState((1, 1), (1, 5), frozenset({(1, 3)}), "MAX", 12))
        self.assertEqual(problem.board, ("#######", "#     #", "#######"))
        self.assertEqual(problem.actions(state), ("RIGHT", "WAIT"))
        self.assertEqual(ACTION_ORDER, ("UP", "RIGHT", "DOWN", "LEFT", "WAIT"))

    def test_movement_collects_only_on_max_turn(self):
        problem = corridor()
        initial = problem.initial_state
        after_max = problem.result(initial, "RIGHT")
        after_min = problem.result(after_max, "LEFT")
        ghost_on_food = problem.result(replace(after_min, to_move="MIN"), "LEFT")
        self.assertEqual(after_max.pacman, (1, 2))
        self.assertEqual(after_max.to_move, "MIN")
        self.assertEqual(after_min.ghost, (1, 4))
        self.assertEqual(after_min.to_move, "MAX")
        self.assertEqual(after_min.remaining_plies, 10)
        self.assertEqual(ghost_on_food.pellets, initial.pellets)
        self.assertEqual(initial.remaining_plies, 12)
        self.assertEqual(initial.pacman, (1, 1))

    def test_wait_alternates_and_consumes_a_ply(self):
        problem = corridor(max_plies=2)
        first = problem.result(problem.initial_state, "WAIT")
        second = problem.result(first, "WAIT")
        self.assertEqual(first.pacman, problem.initial_state.pacman)
        self.assertEqual(first.remaining_plies, 1)
        self.assertEqual(second.to_move, "MAX")
        self.assertEqual(problem.outcome(second), "timeout")
        self.assertEqual(problem.utility(second), -1)

    def test_completion_on_last_ply_precedes_timeout(self):
        problem = corridor(max_plies=1)
        near_food = replace(problem.initial_state, pacman=(1, 2))
        final = problem.result(near_food, "RIGHT")
        self.assertEqual(final.remaining_plies, 0)
        self.assertEqual(problem.outcome(final), "win")
        self.assertEqual(problem.utility(final), 1)
        self.assertEqual(problem.actions(final), ())

    def test_capture_precedes_completion_on_last_ply(self):
        problem = corridor(max_plies=1)
        state = replace(problem.initial_state, pacman=(1, 2), ghost=(1, 3))
        final = problem.result(state, "RIGHT")
        self.assertFalse(final.pellets)
        self.assertEqual(problem.outcome(final), "capture")
        self.assertEqual(problem.utility(final), -1)

    def test_ghost_capture_and_terminal_move_rejection(self):
        problem = corridor()
        state = replace(problem.initial_state, pacman=(1, 1), ghost=(1, 2), to_move="MIN")
        final = problem.result(state, "LEFT")
        self.assertEqual(problem.outcome(final), "capture")
        with self.assertRaises(ValueError):
            problem.result(final, "WAIT")
        with self.assertRaises(ValueError):
            problem.utility(problem.initial_state)

    def test_walls_and_boundaries(self):
        problem = corridor()
        for illegal in ("UP", "DOWN", "LEFT", "JUMP", None):
            with self.subTest(action=illegal), self.assertRaises(ValueError):
                problem.result(problem.initial_state, illegal)
        open_edge = corridor(board=["P.G"])
        self.assertEqual(open_edge.actions(open_edge.initial_state), ("RIGHT", "WAIT"))

    def test_distance_follows_maze(self):
        problem = corridor(board=["#######", "#P# .G#", "# # # #", "#     #", "#######"])
        self.assertEqual(problem.distance((1, 1), (1, 3)), 6)
        self.assertEqual(problem.distance((1, 1), (1, 1)), 0)
        with self.assertRaises(ValueError):
            problem.distance((1, 1), (0, 0))

    def test_numerical_evaluation_and_fixed_perspective(self):
        problem = corridor()
        state = problem.initial_state
        expected = 0.2 / 3 + 0.2 * 4 / 5 - 0.5
        self.assertAlmostEqual(problem.evaluate(state), expected)
        self.assertEqual(problem.evaluate(state), problem.evaluate(replace(state, to_move="MIN")))
        two_food = corridor(board=["########", "#P. . G#", "########"])
        partial = two_food.result(two_food.initial_state, "RIGHT")
        self.assertAlmostEqual(two_food.evaluate(partial), 0.3 + 0.2 / 3 + 0.2 * 4 / 5 - 0.5)

    def test_chasing_uses_canonical_shortest_path_ties(self):
        problem = corridor(board=["#####", "#P .#", "# G #", "#####"])
        state = replace(problem.initial_state, to_move="MIN")
        self.assertEqual(problem.chasing_action(state), "UP")
        with self.assertRaises(ValueError):
            problem.chasing_action(problem.initial_state)

    def test_levels_and_states_are_immutable(self):
        data = {"name": "copied", "board": ["P.G"], "max_plies": 6}
        problem = PacmanProblem.from_dict(data)
        data["board"][0] = "G.P"
        self.assertEqual(problem.initial_state.pacman, (0, 0))
        hash(problem.initial_state)
        with self.assertRaises(FrozenInstanceError):
            problem.initial_state.remaining_plies = 4
        with self.assertRaises(FrozenInstanceError):
            problem.name = "changed"

    def test_invalid_levels(self):
        for changes in (
            {"name": ""}, {"max_plies": True}, {"max_plies": 0},
            {"board": ["P.G", "##"]}, {"board": ["PP.G"]},
            {"board": ["P G"]}, {"board": ["P.#G"]},
            {"board": ["P?G."]}, {"extra": 1}, {"description": None},
        ):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                corridor(**changes)

    def test_invalid_states(self):
        problem = corridor()
        for changes in (
            {"pacman": (0, 0)}, {"ghost": (99, 99)},
            {"pellets": frozenset({(1, 1)})}, {"remaining_plies": 13},
        ):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                problem.actions(replace(problem.initial_state, **changes))
        for changes in ({"remaining_plies": True}, {"to_move": "ghost"}, {"pacman": [1, 1]}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                replace(problem.initial_state, **changes)

    def test_five_supplied_levels_load_and_terminate_under_waiting(self):
        paths = sorted((ASSIGNMENT_DIR / "levels").glob("*.json"))
        self.assertEqual({path.stem for path in paths}, {"danger", "trap", "routes", "cycle", "larger"})
        for path in paths:
            with self.subTest(level=path.stem):
                problem = PacmanProblem.from_file(path)
                state = problem.initial_state
                for _ in range(problem.max_plies):
                    self.assertIn("WAIT", problem.actions(state))
                    self.assertTrue(-1 < problem.evaluate(state) < 1)
                    state = problem.result(state, "WAIT")
                self.assertEqual(problem.outcome(state), "timeout")


class TestSuppliedSearchHelpers(unittest.TestCase):
    def test_random_baseline_script_and_counts(self):
        rng = search.RandomSource(integers=[1])
        with patch.object(search, "RandomSource", return_value=rng):
            result = search.random_search(TinyGame())
        self.assertEqual((result.action, result.value), ("right", -0.5))
        self.assertEqual((result.successor_count, result.evaluation_count), (1, 1))
        self.assertEqual([frame.event for frame in result.frames], ["cutoff", "backup"])
        self.assertEqual(result.iterations, 0)
        self.assertEqual(result.root_stats, ())

    def test_random_terminal_root_does_not_draw(self):
        game = TinyGame()
        game.initial_state = "W"
        rng = search.RandomSource(integers=[])
        with patch.object(search, "RandomSource", return_value=rng):
            result = search.random_search(game)
        self.assertEqual((result.action, result.value), (None, 1.0))
        self.assertEqual((result.successor_count, result.evaluation_count), (0, 1))
        self.assertEqual([frame.event for frame in result.frames], ["terminal"])

    def test_random_reproducibility_and_global_state(self):
        before = random.getstate()
        first = search.random_search(TinyGame(), seed=4)
        self.assertEqual(first, search.random_search(TinyGame(), seed=4))
        self.assertEqual(before, random.getstate())

    def test_scripted_rng_forced_draw_exhaustion_and_validation(self):
        rng = search.RandomSource(integers=[0])
        self.assertEqual(rng.index(1), 0)
        with self.assertRaises(StopIteration):
            rng.index(1)
        for value in (True, -1, 2):
            with self.subTest(index=value), self.assertRaises(ValueError):
                search.RandomSource(integers=[value]).index(2)
        with self.assertRaises(ValueError):
            search.RandomSource().index(0)

    def test_context_order_and_repeated_successor_accounting(self):
        context = search.SearchContext(TinyGame(), order="reverse")
        self.assertEqual(context.actions("S"), ("right", "left"))
        self.assertEqual(context.successor("S", "left"), "A")
        self.assertEqual(context.successor("S", "left", rollout=True), "A")
        self.assertEqual((context.successor_count, context.rollout_steps), (2, 1))
        self.assertEqual(context.evaluate("W", depth=0), 1)
        self.assertEqual(context.evaluate("W", record=False), 1)
        self.assertEqual(context.evaluation_count, 2)
        self.assertEqual(context.frame_count, 1)

    def test_prune_count_and_bounds(self):
        context = search.SearchContext(TinyGame())
        context.record_prune("S", 2, 0.5, 0.5, ("right",))
        context.record_backup("S", 2, "left", 0.5)
        result = context.finish("left", 0.5)
        self.assertEqual((result.cutoff_count, result.pruned_actions), (1, 1))
        self.assertEqual(result.successor_count, 0)
        self.assertEqual(result.frames[0].skipped, ("right",))
        with self.assertRaises(ValueError):
            context.record_prune("S", 2, 0.2, 0.5, ("right",))
        with self.assertRaises(ValueError):
            context.record_prune("S", 2, 0.5, 0.5, ())

    def test_node_statistics_do_not_do_student_backpropagation(self):
        context = search.SearchContext(TinyGame())
        root = context.new_node("S")
        child = context.new_node("A", root, "left")
        self.assertEqual(root.children, [])
        root.untried.remove("left")
        root.children.append(child)
        self.assertEqual((child.visits, child.total_return), (0, 0))
        root.visits, root.total_return = 2, -2.0
        child.visits, child.total_return = 2, -2.0
        context.record_iteration(root)
        result = context.finish("left", -1, root=root)
        self.assertEqual(result.root_stats, (search.RootStat("left", 2, -1.0), search.RootStat("right", 0, None)))
        self.assertEqual((result.iterations, result.stored_nodes), (1, 2))
        self.assertEqual((root.visits, child.visits), (2, 2))

    def test_trace_retains_first_frames_and_latest_without_losing_counts(self):
        context = search.SearchContext(TinyGame())
        with patch.object(search, "MAX_TRACE_FRAMES", 2):
            for state in ("A", "B", "W", "L"):
                context.evaluate(state)
        result = context.finish("left", 0.25)
        self.assertEqual(result.frame_count, 4)
        self.assertEqual([frame.state for frame in result.frames], ["A", "B", "L"])
        self.assertEqual(result.evaluation_count, 4)

    def test_configuration_validation(self):
        for bad in (True, 0, -1, 1.5):
            with self.subTest(depth=bad), self.assertRaises(ValueError):
                search.validate_depth(bad)
            with self.subTest(iterations=bad), self.assertRaises(ValueError):
                search.validate_mcts(bad, 1)
        for bad in (True, 0, -1, float("inf"), float("nan")):
            with self.subTest(exploration=bad), self.assertRaises(ValueError):
                search.validate_mcts(1, bad)
        for kwargs in ({"seed": True}, {"seed": -1}, {"order": "random"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                search.SearchContext(TinyGame(), **kwargs)

    def test_malformed_game_contracts(self):
        for method, output in (("to_move", "ghost"), ("terminal", 0),
                               ("actions", []), ("actions", ("x", "x")),
                               ("actions", ())):
            game = TinyGame()
            setattr(game, method, lambda state, value=output: value)
            with self.subTest(method=method, output=output), self.assertRaises(ValueError):
                search.SearchContext(game)
        game = TinyGame()
        game.result = lambda state, action: "S"
        with self.assertRaises(ValueError):
            search.SearchContext(game).successor("S", "left")
        for bad in (True, "0", math.inf, math.nan, -1, 1):
            game = TinyGame()
            game.evaluate = lambda state, value=bad: value
            with self.subTest(evaluation=bad), self.assertRaises(ValueError):
                search.SearchContext(game).evaluate("S")


class TestReplayPlumbing(unittest.TestCase):
    def test_json_embedding_is_safe_and_self_contained(self):
        from demo import build_demo_html
        payload = {"label": "</script><script>unsafe</script>\u2028"}
        template = '<script type="application/json">__TRACE_JSON__</script>'
        rendered = build_demo_html(payload, template)
        self.assertNotIn("<script>unsafe", rendered)
        encoded = rendered.split(">", 1)[1].rsplit("<", 1)[0]
        self.assertEqual(json.loads(encoded), payload)
        for invalid in ("", "__TRACE_JSON____TRACE_JSON__"):
            with self.assertRaises(ValueError):
                build_demo_html(payload, invalid)

    def test_seeded_game_replays_match_rules(self):
        from demo import COUNT_FIELDS, trace_payload
        problem = corridor()
        before = random.getstate()
        first = trace_payload(problem, algorithm="random", seed=3)
        self.assertEqual(first, trace_payload(problem, algorithm="random", seed=3))
        self.assertEqual(random.getstate(), before)
        self.assertEqual(first["schema_version"], 2)
        state = problem.initial_state
        for move_index, snapshot in enumerate(first["snapshots"][1:]):
            if state.to_move == "MIN":
                self.assertEqual(snapshot["action"], problem.chasing_action(state))
                self.assertIsNone(snapshot["decision_index"])
            else:
                decision = first["decisions"][snapshot["decision_index"]]
                self.assertEqual(decision["move_index"], move_index)
                self.assertEqual(decision["result"]["action"], snapshot["action"])
            state = problem.result(state, snapshot["action"])
            self.assertEqual(snapshot["state"]["pacman"], list(state.pacman))
            self.assertEqual(snapshot["state"]["ghost"], list(state.ghost))
            self.assertEqual(snapshot["state"]["pellets"], [list(cell) for cell in sorted(state.pellets)])
            self.assertEqual(snapshot["state"]["remaining_plies"], state.remaining_plies)
            self.assertEqual(snapshot["outcome"], problem.outcome(state))
        self.assertTrue(problem.terminal(state))
        self.assertEqual(first["summary"]["outcome"], problem.outcome(state))
        self.assertEqual(first["summary"]["utility"], problem.utility(state))
        self.assertEqual(first["summary"]["plies"], len(first["snapshots"]) - 1)
        self.assertEqual(first["summary"]["pellets_collected"],
                         len(problem.initial_state.pellets) - len(state.pellets))
        for name in COUNT_FIELDS:
            self.assertEqual(first["summary"][name],
                             sum(decision["result"][name] for decision in first["decisions"]))
        self.assertEqual(first["summary"]["successor_count"], len(first["decisions"]))
        self.assertEqual(first["summary"]["successors_per_decision"], 1.0)
        self.assertEqual(first["summary"]["evaluations_per_decision"], 1.0)
        self.assertEqual([decision["seed"] for decision in first["decisions"]],
                         list(range(3, 3 + len(first["decisions"]))))

    def test_terminal_initial_game_needs_no_search_or_average(self):
        from demo import COUNT_FIELDS, RootedProblem, trace_payload
        problem = corridor()
        terminal = replace(problem.initial_state, pellets=frozenset())
        with patch("demo.run_algorithm", side_effect=AssertionError("terminal games need no search")):
            payload = trace_payload(RootedProblem(problem, terminal), seed=0)
        self.assertEqual(len(payload["snapshots"]), 1)
        self.assertEqual(payload["decisions"], [])
        self.assertEqual(payload["summary"]["plies"], 0)
        self.assertEqual(payload["summary"]["decisions"], 0)
        self.assertEqual(payload["summary"]["outcome"], "win")
        self.assertEqual(payload["summary"]["utility"], 1.0)
        self.assertIsNone(payload["summary"]["successors_per_decision"])
        self.assertIsNone(payload["summary"]["evaluations_per_decision"])
        self.assertTrue(all(payload["summary"][name] == 0 for name in COUNT_FIELDS))

    def test_writes_demo_and_protects_supplied_template(self):
        from demo import DEFAULT_TEMPLATE, write_demo
        level = ASSIGNMENT_DIR / "levels" / "routes.json"
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "replay.html"
            payload = write_demo(level, output)
            html = output.read_text(encoding="utf-8")
            self.assertIn("Pac-Man", html)
            self.assertNotIn("__TRACE_JSON__", html)
            self.assertGreater(payload["summary"]["decisions"], 0)
            self.assertGreater(len(payload["snapshots"]), 1)
            self.assertIn(payload["summary"]["outcome"], ("win", "capture", "timeout"))
            self.assertEqual(payload["snapshots"][-1]["outcome"], payload["summary"]["outcome"])
        with self.assertRaises(ValueError):
            write_demo(level, DEFAULT_TEMPLATE)

    def test_generated_outputs_do_not_follow_file_symlinks(self):
        from demo import validate_output
        from run_experiments import write_index_html, write_summary_csv
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "source.txt"
            target.write_text("keep this source", encoding="utf-8")
            output = Path(directory) / "output.html"
            try:
                output.symlink_to(target)
            except OSError as error:
                self.skipTest(f"symbolic links unavailable: {error}")
            for write in (lambda: validate_output(output),
                          lambda: write_summary_csv((), output),
                          lambda: write_index_html((), output)):
                with self.assertRaises(ValueError):
                    write()
            self.assertEqual(target.read_text(encoding="utf-8"), "keep this source")


class TestExperimentPlumbing(unittest.TestCase):
    @staticmethod
    def fake_demo(level, output, *, algorithm, depth, order, iterations, seed, exploration):
        """Exercise TODO reporting without depending on students' implementations."""
        from demo import COUNT_FIELDS
        if algorithm != "random":
            raise NotImplementedError("fixture TODO")
        summary = dict.fromkeys(COUNT_FIELDS, 0)
        summary.update(utility=1.0, outcome="win", plies=3, decisions=2,
                       pellets_collected=1, successor_count=2,
                       evaluation_count=2, frame_count=4,
                       successors_per_decision=1.0, evaluations_per_decision=1.0)
        return {"summary": summary}

    def test_default_matrix_todo_rows_and_csv_round_trip(self):
        import run_experiments as experiments
        levels = tuple(sorted((ASSIGNMENT_DIR / "levels").glob("*.json")))
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            with patch.object(experiments, "write_demo", side_effect=self.fake_demo) as writer, redirect_stdout(io.StringIO()):
                rows = experiments.run_experiments(levels, output_dir=output)
            self.assertEqual(len(rows), 120)
            self.assertEqual(writer.call_count, 120)
            self.assertEqual(sum(row.status == "ok" for row in rows), 15)
            self.assertEqual(sum(row.status == "todo" for row in rows), 105)
            expected = {
                (algorithm, depth, order, None, 0)
                for algorithm in ("minimax", "alphabeta")
                for depth in (2, 4, 6) for order in ("canonical", "reverse")
            } | {("mcts", None, None, budget, seed)
                 for budget in (50, 200, 800) for seed in (0, 1, 2)} | {
                ("random", None, None, None, seed) for seed in (0, 1, 2)
            }
            for level in levels:
                actual = [row for row in rows if row.level == level.stem]
                self.assertEqual(len(actual), 24)
                self.assertEqual({(row.algorithm, row.depth, row.order, row.iteration_limit, row.seed)
                                  for row in actual}, expected)
            for call, row in zip(writer.call_args_list, rows):
                self.assertEqual(call.kwargs["depth"], row.depth if row.depth is not None else 4)
                self.assertEqual(call.kwargs["order"], row.order or "canonical")
                self.assertEqual(call.kwargs["iterations"], row.iteration_limit or 200)
                self.assertEqual(call.kwargs["seed"], row.seed)
            self.assertTrue(all(row.utility is None and row.successor_count is None and row.replay is None
                                and row.successors_per_decision is None and row.evaluations_per_decision is None
                                for row in rows if row.status == "todo"))
            self.assertTrue(all(row.replay.startswith(f"replays/{row.level}/")
                                for row in rows if row.status == "ok"))
            experiments.write_summary_csv(rows, output / "summary.csv")
            self.assertEqual(experiments.read_summary_csv(output / "summary.csv"), rows)
            experiments.write_index_html(rows, output / "index.html")
            self.assertNotIn("__COMPARISON_JSON__", (output / "index.html").read_text(encoding="utf-8"))
            with patch.object(experiments, "write_demo", side_effect=AssertionError("refresh must not run search")), redirect_stdout(io.StringIO()):
                self.assertEqual(experiments.main(["--refresh", "--output-dir", str(output)]), 0)

    def test_comparison_keeps_budgets_separate_and_exposes_missing_coverage(self):
        import run_experiments as experiments
        from demo import COUNT_FIELDS
        levels = tuple(sorted((ASSIGNMENT_DIR / "levels").glob("*.json")))[:2]

        def completed_demo(level, output, *, algorithm, depth, order, iterations, seed, exploration):
            # Each seed has a different game length and per-decision search cost.
            decisions = seed + 2
            evaluations = iterations * decisions
            successors = evaluations * 10 * (seed + 1)
            summary = dict.fromkeys(COUNT_FIELDS, 0)
            summary.update(utility=1.0 if seed == 0 else -1.0,
                           outcome="win" if seed == 0 else "capture",
                           plies=2 * decisions - 1, decisions=decisions,
                           pellets_collected=1, successor_count=successors,
                           evaluation_count=evaluations,
                           rollout_steps=successors - evaluations,
                           stored_nodes=(iterations + 1) * decisions,
                           iterations=evaluations, frame_count=evaluations,
                           successors_per_decision=successors / decisions,
                           evaluations_per_decision=evaluations / decisions)
            return {"summary": summary}

        with tempfile.TemporaryDirectory() as directory:
            with patch.object(experiments, "write_demo", side_effect=completed_demo), redirect_stdout(io.StringIO()):
                rows = experiments.run_experiments(levels, algorithms=("mcts",), seeds=(0, 1),
                                                   iterations=(50, 200), output_dir=Path(directory))
        # Omit one budget/seed combination while retaining the other level's evidence.
        missing = tuple(row for row in rows if not (
            row.iteration_limit == 50 and row.level == levels[0].stem and row.seed == 1
        ))
        data = experiments.build_comparison_data(missing)
        self.assertEqual(len(data["groups"]), 4)
        group = next(group for group in data["groups"]
                     if group["iteration_limit"] == 50 and group["level"] == levels[0].stem)
        self.assertEqual((group["completed"], group["expected"]), (1, 2))
        self.assertIsNone(group["metrics"]["utility"]["sd"])
        self.assertEqual(group["metrics"]["win_rate"]["mean"], 1.0)
        complete = next(group for group in data["groups"]
                        if group["iteration_limit"] == 50 and group["level"] == levels[1].stem)
        self.assertEqual(complete["metrics"]["utility"]["mean"], 0.0)
        self.assertAlmostEqual(complete["metrics"]["utility"]["sd"], math.sqrt(2))
        self.assertEqual(complete["metrics"]["win_rate"]["mean"], 0.5)
        self.assertEqual(complete["metrics"]["successor_count"]["mean"], 2000.0)
        self.assertEqual(complete["metrics"]["decisions"]["mean"], 2.5)
        self.assertEqual(complete["metrics"]["successors_per_decision"]["mean"], 750.0)
        self.assertAlmostEqual(complete["metrics"]["successors_per_decision"]["sd"], math.sqrt(125000))
        self.assertEqual(complete["metrics"]["evaluations_per_decision"]["mean"], 50.0)
        larger_budget = next(group for group in data["groups"]
                             if group["iteration_limit"] == 200 and group["level"] == levels[1].stem)
        self.assertEqual(larger_budget["metrics"]["successors_per_decision"]["mean"], 3000.0)
        with self.assertRaises(ValueError):
            experiments.build_comparison_data((rows[0], rows[0]))
        with self.assertRaises(ValueError):
            experiments.build_comparison_data((replace(rows[0], replay="../outside.html"),))
        for changes in ({"utility": 0.25}, {"utility": -1.0},
                        {"successors_per_decision": 700.0}, {"evaluations_per_decision": None}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                experiments.build_comparison_data((replace(rows[0], **changes),))

    def test_replay_agreement_checks_moves_and_values_beyond_the_outcome(self):
        import run_experiments as experiments
        from demo import build_demo_html
        template = '<script id="trace-data" type="application/json">__TRACE_JSON__</script>'
        rows = tuple(experiments.ExperimentRow(
            level="corridor", algorithm=algorithm, seed=0, depth=2, order="canonical",
            iteration_limit=None, exploration=None, status="ok", utility=1.0, outcome="win",
            replay=f"replays/corridor/{algorithm}.html",
        ) for algorithm in ("minimax", "alphabeta"))

        def payload(algorithm, *, action="RIGHT", value=0.4, move_index=0, initial_column=1):
            return dict(
                schema_version=2, algorithm=algorithm, seed=0,
                configuration=dict(depth=2, order="canonical"),
                summary=dict(outcome="win", utility=1.0),
                snapshots=[dict(state=dict(pacman=[1, initial_column]), outcome=None),
                           dict(state=dict(pacman=[1, 3]), outcome="win")],
                decisions=[dict(move_index=move_index, result=dict(
                    action=action, value=value,
                    successor_count=9 if algorithm == "minimax" else 7,
                    frames=[dict(event="backup" if algorithm == "minimax" else "prune")],
                ))],
            )

        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            paths = [output / row.replay for row in rows]
            paths[0].parent.mkdir(parents=True)
            for row, path in zip(rows, paths):
                path.write_text(build_demo_html(payload(row.algorithm), template), encoding="utf-8")
            match = experiments.replay_agreements(rows, output)
            self.assertEqual(match, [dict(level="corridor", depth=2, order="canonical",
                                         status="match", decisions=1)])
            for changes in ({"action": "WAIT"}, {"value": 0.5},
                            {"move_index": 1}, {"initial_column": 2}):
                with self.subTest(changes=changes):
                    paths[1].write_text(build_demo_html(payload("alphabeta", **changes), template),
                                        encoding="utf-8")
                    self.assertEqual(experiments.replay_agreements(rows, output)[0]["status"], "mismatch")
            paths[1].unlink()
            missing = experiments.replay_agreements(rows, output)[0]
            self.assertEqual(missing["status"], "missing")
            self.assertIsNone(missing["decisions"])


if __name__ == "__main__":
    unittest.main()
