# Assignment 3: Pac-Man Adversarial Search

Implement and compare minimax, alpha-beta pruning, and Monte Carlo tree search
(MCTS) for a Pac-Man-inspired game, adapted from the
[GameWorld game suite](https://gameworld-project.github.io/). Pac-Man and one
ghost alternate turns on a fixed maze. This course adaptation is a deterministic,
two-player, zero-sum game with complete information. Implement three search
algorithms using the supplied scaffolding; the browser replays Python's decisions.

This individual assignment is graded out of 100 points. See the course website
and Blackboard for its deadline and course-grade weight.

## Learning objectives

Learn to:

- represent an adversarial game with states, players, actions, and utilities;
- implement depth-limited minimax and distinguish terminal utility from a
  cutoff evaluation;
- implement alpha-beta pruning and explain its bounds, cutoffs, and dependence
  on move ordering;
- implement MCTS selection, expansion, simulation, and backpropagation;
- use fixed-MAX returns consistently at both players' decision nodes;
- reproduce randomized runs through a precise random-call protocol; and
- design independent tests and compare search effort with gameplay outcomes.

## Start here

1. Read this file completely and review the course material.
2. Complete the pre-run traces before implementing a TODO.
3. Run `python -m unittest tests.test_public -v` to check the supplied game
   model and search scaffolding.
4. Generate and open the random-player browser replay.
5. Add a numerical test in `tests/test_student.py` that reaches a TODO;
   record its initial `NotImplementedError`.
6. Implement minimax, then alpha-beta pruning, then MCTS.
7. Finish independent tests, inspect replays, run experiments, review
   submission files, and complete the report.

All three TODOs initially raise `NotImplementedError`, yet the public suite
passes. Neither those tests nor an empty student suite establish correctness.

## Supplied and student work

The starter supplies:

- `pacman.py`: immutable game state, legal actions, transitions, terminal
  utilities, cutoff evaluation, a deterministic ghost policy, and level loading;
- `adversarial_search.py`: shared interfaces, deterministic random helpers,
  search accounting, MCTS nodes, results and traces, and a random baseline;
- `demo.py` and `viewer/template.html`: a self-contained offline replay;
- `run_experiments.py` and `viewer/experiments.html`: individual replays,
  a CSV summary, and an HTML comparison;
- five levels: immediate danger, a dead-end pellet trap, alternative routes,
  cycles, and a larger maze;
- public tests, report template, AI-use declaration, and third-party notices.

Implement these `adversarial_search.py` functions without changing names or
parameters:

```python
minimax_search(problem, *, depth=4, order="canonical")
alpha_beta_search(problem, *, depth=4, order="canonical")
monte_carlo_tree_search(problem, *, iterations=200, seed=0,
                       exploration=math.sqrt(2))
```

You may add private helpers to `adversarial_search.py`; keep supplied functions,
types, constants, and public interfaces unchanged. Do not modify `pacman.py`,
the random baseline, search or random helpers, demo, experiment runner,
viewer, levels, or public tests. Add independent tests only to
`tests/test_student.py`.

Use Python 3.10 or newer and only the standard library, with no game-search
package or other implementation of the required algorithms.

## Alternating Pac-Man and ghost turns

Pac-Man is MAX; one ghost is MIN. MAX tries to collect every pellet before
capture or the game limit. MIN tries to prevent completion. Every action and
its result are visible to both players. There are no simultaneous moves,
unknown states, random transitions, power pellets, or additional ghosts.

Each level is a JSON object with `name`, `board`, and `max_plies`, plus an
optional `description`. The rectangular `board` contains these symbols:

| Symbol | Meaning |
| --- | --- |
| `#` | Wall |
| `P` | Pac-Man's initial position |
| `G` | The ghost's initial position |
| `.` | Pellet |
| Space | Empty floor |

There is exactly one `P`, one `G`, and at least one pellet. All traversable
cells are connected. The engine separates the fixed walls from the changing
player positions and pellets. `max_plies` is the episode's total move limit;
it is separate from a search's depth or MCTS iteration limit.

Positions use zero-based `(row, column)` coordinates, with rows increasing
downward and columns increasing to the right. A state contains Pac-Man's
position, the ghost's position, remaining pellet positions, the player to move,
and remaining plies. A **ply** is one action by one player; two plies normally
give each player one turn. The supplied levels start with MAX to move.

A level JSON file supplies `name`, `board`, and `max_plies`, with an optional
`description`. Board rows use `#` for walls, a space for empty floor, `.` for
a pellet, `P` for Pac-Man's initial position, and `G` for the ghost's. The
player markers do not also contain pellets. Traversable cells are connected;
the engine removes initial player markers from the fixed board and stores
player positions and remaining pellets in the state.

The canonical action order is `UP`, `RIGHT`, `DOWN`, `LEFT`, `WAIT`, omitting
directions blocked by a wall or the maze boundary. `WAIT` is always legal in
a nonterminal state. It leaves the position unchanged and consumes one ply.
Only the player to move changes position. Pac-Man collects a pellet on its
destination; the ghost never collects pellets. After a move, switch the player
and decrement remaining plies.

Determine terminal outcomes in this order:

1. Matching player positions mean capture, with utility `-1` for MAX.
2. No remaining pellets mean completion, with utility `+1` for MAX.
3. Zero remaining plies mean timeout, with utility `-1` for MAX.

Capture takes priority even if Pac-Man reaches the final pellet at the ghost's
position. Collecting the last pellet on the final allowed ply succeeds if
there is no capture. Terminal states have no legal actions. The finite ply
limit makes waiting and cycles terminate; a repeated pair of positions need
not represent the same state because pellets, player, or remaining plies differ.

Search must work from either player's turn. In gameplay experiments, however,
the selected algorithm controls Pac-Man and a supplied deterministic policy
controls the ghost. That policy moves to minimize maze distance to Pac-Man,
breaking ties in canonical order. It supplies the same opponent for all
methods; it is not an optimal minimax opponent. The search algorithms still
model MIN as an adversary within their trees.

## Supplied utility and cutoff evaluation

All values are from MAX's perspective. MAX selects larger values; MIN selects
smaller values. Terminal utility is exactly `+1` or `-1` in Pac-Man. Tiny
abstract test games may use any finite terminal utility in `[-1, 1]`.

For a nonterminal Pac-Man state, let `p` be the fraction of initial pellets
already collected, `d_food` the shortest maze distance from Pac-Man to a
remaining pellet, and `d_ghost` the shortest maze distance between the players.
The supplied cutoff evaluation is:

```text
E = 0.6 * p + 0.2 / (1 + d_food) + 0.2 * d_ghost / (1 + d_ghost) - 0.5
```

Distances respect walls. The levels use connected traversable cells, so
these distances are finite. The evaluator rewards pellet progress, proximity
to another pellet, and distance from the ghost; it stays strictly between
terminal losses and wins. Keep it unchanged. It is an estimate, not a proof
of the eventual outcome.

Check terminal status **before** the depth cutoff. A terminal state reached
at depth zero uses its utility, never the nonterminal evaluator. MCTS simulates
to terminal states and uses terminal returns, not this cutoff evaluation.

## Required pre-run traces

Complete these traces in `report/report.tex` before implementing a TODO.
The abstract game trees isolate decisions from Pac-Man: all leaf numbers are
terminal utilities for MAX, and listed successor order is canonical. Use
only the listed edges; do not infer additional actions.

Trace rules:

- **Order and ties:** Minimax and alpha-beta keep the first action in the
  current order on exact value ties. Reverse every action list when requested.
  MCTS uses canonical order for expansion, UCT ties, and final visit-count ties.
- **Pruning:** Cut off when `alpha >= beta`, including equality. Return the
  best child value encountered (fail-soft), without clipping it to the bounds.
  Count a cutoff only when it skips remaining actions.
- **Successor calls:** Count each generated transition, including rollout
  moves. Following an existing MCTS tree edge during selection adds no call.
- **Leaf evaluations:** Count each visited minimax/alpha-beta leaf and one
  terminal evaluation per MCTS iteration. Internal backups add no evaluation.
- **Stored nodes:** For the MCTS trace, count the root and each node created
  by expansion. Rollout-only states are temporary and are not stored nodes.
- **MCTS returns:** Add the same MAX-perspective return at the selected or
  expanded stored node and every ancestor. Recommend the most-visited root
  child and report that child's mean return.

### Minimax and alpha-beta pruning

The root S is MAX. Its actions A, B, and C lead to MIN nodes, each with two
terminal successors in the listed order:

| Node | Player | Ordered terminal utilities |
| --- | --- | --- |
| A | MIN | `0.4`, `0.6` |
| B | MIN | `-0.2`, `0.9` |
| C | MIN | `0.4`, `-0.7` |

Use depth two. Trace minimax first, showing every leaf evaluation, each
backed-up value, and the root action under the trace tie rule. Then trace
alpha-beta with initial bounds `(-infinity, +infinity)`. Show bounds before
and after each child, every skipped action, and the final root result. Explain
which returned internal values are only bounds after pruning. Repeat the
alpha-beta trace with every action list reversed; count successor calls and
leaf evaluations under both orders.

Also trace a MIN root whose canonical actions X and Y lead to MAX nodes.
X has terminal utilities `0.3`, `0.5`; Y has `0.5`, `0.9`. Use depth two and
canonical order. Identify the equality cutoff, its skipped leaf, and why the
root decision remains valid even when a pruned child does not have an exact
returned minimax value.

### MCTS iterations

S is MAX with canonical actions A and B leading to MIN nodes. Each MIN node
has canonical actions x and y leading to terminal states:

| Node | x utility | y utility |
| --- | ---: | ---: |
| A | -1 | +1 |
| B | +1 | -1 |

Start with one stored root node at S having zero visits (`N=0`), zero total
return (`U=0`), and no children. Its untried actions are `[A, B]`. Run exactly
three iterations with `exploration=sqrt(2)`. Use the scripted rollout indices
`[1, 0]` in order; these are action-list indices, not seeds. Expansion always
takes the first untried action and consumes no random draw.

For every iteration, show the selection path, expanded action, temporary
rollout path, terminal return, and `(N, U)` of every stored node after
backpropagation. Distinguish stored nodes from rollout-only states. Show
the exact successor-call, rollout-transition, leaf-evaluation, and stored-node
counts. After iteration three, select the recommended action by visit count
and report its mean return. Explain why that action need not have the largest
sample mean.

### Opponent-aware UCT

A fully expanded MIN parent has `N=10`. Its two children, in canonical order,
have `(N, U)=(2, -2)` and `(8, 4)`. With `exploration=sqrt(2)`, calculate both
UCT scores and choose the next child. Repeat the calculation if the parent
were MAX. Identify which term changes sign and explain why the sampled return
must not alternate sign during backpropagation.

## Shared search contract

Use the supplied interfaces in `adversarial_search.py`. A problem exposes
`initial_state`, `to_move(state)`, `actions(state)`, `result(state, action)`,
`terminal(state)`, `utility(state)`, and `evaluate(state)`. States are hashable;
players are `MAX` and `MIN`. Actions are tuples of distinct nonempty strings
in canonical order, nonempty at nonterminal states and empty at terminal ones.
Transitions alternate players, and every path in an accepted test game
terminates. Utilities are finite reals in `[-1, 1]`; nonterminal evaluations
are finite reals strictly between `-1` and `1`. Boolean values are not scores.

Instructor tests may use tiny deterministic trees, so search algorithms must
not inspect Pac-Man positions, maze data, or other game internals.

`SearchContext` supplies `initial`, `player`, `terminal`, `actions`, `successor`,
`evaluate`, `record_backup`, `record_prune`, `new_node`, `record_iteration`,
and `finish`. Use one context and its accounting and trace helpers per call;
use its private random source for randomized choices. Read the supplied
docstrings for argument and result fields.

Use supplied validation helpers and raise `ValueError` for invalid parameters
or malformed input. Depth and iteration limits are positive integers; seeds
are nonnegative integers. Booleans are not integers. Exploration is a finite,
strictly positive real, excluding Booleans. `order` is `canonical` or `reverse`;
reverse changes every action list for minimax and alpha-beta, not just the
root. MCTS always uses canonical order.

Choose the first action in the current order on exact value ties. Do not
round values or replace exact comparisons with tolerance comparisons inside
the algorithms. For MCTS, break equal UCT scores and equal final visit counts
by canonical action order.

Do not use a visited set, transposition table, or memoization.
Repeated states reached by different paths remain separate
search-tree occurrences. Terminate by the depth or iteration limit and
terminal rules, never elapsed time.

### Results, frames, and search effort

Return `context.finish(action, value)`, supplying `root=root` for MCTS.
The result includes the chosen root action, its value, counters, and recorded
decision frames. MCTS also exposes root-action visit counts and mean returns.
Unexpanded actions appear with zero visits and an undefined mean (`None`).
At a terminal root, return action `None` and exact utility with zero successor
calls. MCTS additionally completes zero iterations and stores zero nodes.

All transition calls must use `context.successor`. Every call counts once,
including repeated successors and rollout moves. Mark rollout moves with
`rollout=True`; this is a subset of the total successor-call count. Moving
between already stored MCTS nodes during selection causes no new transition
call. A new child requires one transition call. Rollout states are temporary
and do not count as stored nodes.

Use `context.evaluate` once for each visited minimax/alpha-beta leaf and each
MCTS iteration's terminal return, including when selection reaches an already
stored terminal node. Pass `record=False` for each iteration's terminal return;
its iteration frame records the updated statistics. The helper checks terminal
utility before nonterminal evaluation and counts one leaf evaluation per call.
Terminal-root handling
evaluates that root once. No internal backup is a leaf evaluation.

Use these helpers for decision frames:

| Event | Helper | Required record |
| --- | --- | --- |
| Terminal or depth-cutoff leaf | `evaluate(state, depth=remaining)` | Evaluated value and remaining depth for recursive search |
| Completed recursive nonleaf | `record_backup(state, remaining, action, value)` | Selected action and returned value, including after a cutoff |
| Cutoff that actually skips actions | `record_prune(state, remaining, alpha, beta, skipped)` | Updated bounds and remaining ordered actions |
| Completed MCTS iteration | `record_iteration(root)` | Root-child statistics after backpropagation |

Call `record_prune` only if at least one action remains unvisited. Reaching
`alpha >= beta` after the last action does not skip work and is not a counted
cutoff. Never generate the skipped successors just to record them. A prune
frame precedes that node's backup frame. The context retains the first 2000
frames and the latest frame when the trace exceeds that limit; counters still
describe the full search. The browser is a recorded view of Python's decisions.

### Minimax

Start from the problem's initial state with the supplied depth. Check terminal
status, then whether remaining depth is zero. Evaluate and return those leaves.
Otherwise visit every action in the selected order, applying one transition
and subtracting one from depth before recursing.

MAX returns the largest child value; MIN returns the smallest. Keep the first
action on ties. Record one backup for every nonleaf after visiting its children.
Return the chosen root action and value. Depth counts individual moves, not
Pac-Man/ghost pairs. The algorithm must handle a MIN root as well as a MAX root.

### Alpha-beta pruning

Use the same depth, terminal handling, evaluator, action order, and tie rule as
minimax. Initialize the root window to `(-infinity, +infinity)`. MAX updates
its best value and alpha after each child; MIN updates its best value and beta.
Stop visiting children when `alpha >= beta`, including equality.

Use fail-soft returns: return the best child value actually encountered, even
when it lies outside the incoming window. Do not clip the returned value to
alpha or beta. A pruned internal result may be a bound rather than the exact
subtree value. The root action and value must match minimax for the same
problem, depth, and order.

Changing order can change the amount of pruning and select a different action
among equally valued actions. It must not change the minimax root value.
Alpha-beta may share a private recursive helper with minimax, but it must
actually avoid successor calls and evaluations for pruned branches.

### Monte Carlo tree search

For a nonterminal root, create one stored node using `context.new_node`.
A node contains `state`, `parent`, `action`, `children`, `untried`, `visits`,
and `total_return`. Newly created nodes have `N=0` visits and `U=0` total return.
Untried actions initially follow canonical order. Perform exactly `iterations`
iterations; do not stop early when a sampled win occurs or all children are
terminal.

Each iteration has four steps:

1. **Selection.** Start at the root. Stop at a terminal node or a node with an
   untried action. Otherwise choose the child with maximum UCT and descend.
2. **Expansion.** If the selected node is nonterminal, remove its first untried
   action, create exactly one child through the supplied context, and append
   it to the parent's children. Continue from that child. A terminal selected
   node creates no child.
3. **Simulation.** From the selected or newly expanded node, choose a uniformly
   random legal action at each move until terminal. Use the private random
   helper and mark these transition calls as rollout moves. Evaluate terminal
   utility once; call this sampled return `z`.
4. **Backpropagation.** Starting at that stored node, increment visits by one
   and add the **same** `z` to total return at every ancestor, including the
   root. Record the completed iteration after these updates.

Only expansion creates stored nodes. Do not insert simulation states into
the tree. A terminal selected node still consumes one iteration and updates
the node and its ancestors with its terminal return.

For a child `n` of parent `p`, with both visit counts positive, use:

```text
Q(n) = U(n) / N(n)
sign(p) = +1 if p's player is MAX, otherwise -1
UCT(n) = sign(p) * Q(n) + exploration * sqrt(log(N(p)) / N(n))
```

Use the natural logarithm. The parent player controls the exploitation sign;
the exploration bonus remains positive for both players. Try untried actions
before applying UCT, so children selected by this formula have positive visits.
All stored returns remain from MAX's perspective. Do not change the sign of
the exploration term or alternate reward signs during backpropagation.

After the iteration limit, recommend the root child with the largest visit
count, breaking ties in canonical order. Return that child's action and mean
return `Q`, whether the root is MAX or MIN. Do not select the final action by
UCT or the largest mean. This finite-sample recommendation is not a proof of
the minimax value.

## Deterministic random calls

A fixed seed is insufficient if implementations consume draws in different
orders. Use only the context's supplied random source, never Python's global
random state:

- Minimax and alpha-beta consume no random draws.
- MCTS selection and expansion consume no random draws. Equal UCT scores
  use canonical order; expansion takes the first untried action.
- Every rollout move draws exactly one `rng.index(len(actions))`, including
  a forced move with a single legal action.
- A terminal rollout consumes no draw. No draw is used for backpropagation
  or final action selection.
- The supplied random baseline draws one root-action index, then evaluates
  that successor. A terminal root consumes no draw.

`RandomSource(integers=...)` scripts contain literal index results, not seeds;
unexpected extra draws exhaust the script and fail. In student tests,
construct a fresh scripted instance before using `unittest.mock.patch` on
`adversarial_search.RandomSource` to return it for a search call. Check exact
actions, values, and counters on small cases. Use floating-point tolerances
for numerical test assertions, but the specified exact comparisons for search
decisions. Reproduce seeded runs with the same Python version and record it
in the report.

## Your tests

Do not modify `tests/test_public.py`. Independent tests must collectively
cover all three required functions, including:

- MAX and MIN roots, alternating backups, stable ties, and terminal roots;
- depth measured in plies, terminal-before-cutoff handling, and different
  supplied cutoff values;
- minimax/alpha-beta root agreement, both MAX and MIN cutoffs, equality
  cutoffs, reversed ordering, and actual skipped work;
- MCTS first-untried expansion, opponent-aware UCT, and canonical ties;
- fixed-MAX backpropagation, temporary rollout states, repeated visits to
  a terminal node, and exact iteration and transition counts;
- final MCTS selection by visits even when the largest mean differs;
- forced rollout moves that consume a draw, terminal rollouts that do not,
  and reproducibility without reading or changing global random state; and
- representative trace fields and invalid parameters.

Use small, independently checked game trees and controlled random choices;
never derive expectations from the implementation under test. Tests earn
credit for defects distinguished, not quantity: examples include maximizing
at MIN nodes, applying the cutoff evaluator to terminal states, pruning only
strict inequalities, reversing the entire UCT score, alternating reward signs,
storing every rollout state, and choosing the final MCTS action by mean.

Run the suites separately during development:

```bash
python -m unittest tests.test_public -v
python -m unittest tests.test_student -v
```

Instructor evaluation uses clean supplied files; changes to engine rules,
public tests, or helpers do not change the contract. Correctness and analysis
earn points; no method must outperform another on every level or seed.

## Replays and experiments

The random baseline works immediately. From this assignment directory, run:

```bash
python demo.py --algorithm random --level levels/danger.json \
  --seed 7 --output results.html
```

The self-contained HTML replay needs no server or Internet. It shows the maze,
pellets, player positions, move history, and recorded search decisions.
Use the move step/play/speed controls and search-decision controls to connect
game outcomes with backed-up values, pruning events, or MCTS root-child
visits and mean returns. The Python result remains authoritative.

Labels are `random`, `minimax`, `alphabeta`, and `mcts`. The selected method
controls Pac-Man for a complete game; the supplied deterministic chasing policy
controls the ghost. Each Pac-Man turn runs a new search from the current state,
applies its chosen action, and retains its search frames for replay. Play ends
at pellet completion, capture, or timeout. A game's Pac-Man decision at
zero-based index `i` uses random seed `seed + i`, so each decision is repeatable
without restarting the same random stream at every move.
See `python demo.py --help` for settings.

After implementing the TODOs, run the complete experiment matrix:

```bash
python run_experiments.py
```

See `python run_experiments.py --help` for settings. Defaults run 120 complete
games across all five levels:

| Configurations per level | Games over five levels |
| --- | ---: |
| Minimax and alpha-beta, depths 2, 4, 6, both orders | 60 |
| MCTS, 50, 200, 800 iterations, seeds 0, 1, 2 | 45 |
| Random baseline, seeds 0, 1, 2 | 15 |
| **Total** | **120** |

Each run repeatedly chooses Pac-Man's actions against the common ghost policy
until completion, capture, or timeout. The selected depth, order, or iteration
limit applies to every Pac-Man decision in that game. Deterministic methods
run once per level, depth, and order; randomized methods repeat each configuration
for all three seeds. Unimplemented methods receive `todo` labels; those rows
are not successful games. The untouched starter produces 15 completed random
games and 105 `todo` rows.

Record each game's outcome, terminal utility, pellets collected, plies played,
and number of Pac-Man decisions. Record cumulative successor calls, rollout
transitions, leaf evaluations, cutoffs, MCTS iterations, and stored nodes as
applicable, along with mean successor calls and leaf evaluations per decision.
The CSV's `utility` describes the terminal outcome; each move's search value
remains available in its replay and may be a cutoff estimate or sampled mean.

Compare minimax and alpha-beta at identical depths and orders. Their complete
action sequences and per-decision values must agree against the same ghost
policy, while search counts can differ. Compare canonical and reverse order
separately: a tied optimal action may change, producing a different later game.
Use the first Pac-Man decision in each replay to compare pruning under both
orders from the same initial state. Use the hand-traced tiny trees to verify
exact values independently.

For MCTS, compare iteration budgets across seeds. At each level's first
Pac-Man decision, report the frequency of each chosen action and the mean and
sample standard deviation of selected-action sample means. These decisions
share the same initial state. Later decisions may encounter different states
because earlier actions differ. A selected child's sample mean is not
interchangeable with a minimax value. More iterations do not guarantee a
better recommendation on every seed.

Summarize win counts, pellet progress, game length, and search effort across
seeds for each randomized configuration, giving means and sample standard
deviations for numerical metrics. These outcomes measure performance against
the supplied ghost policy, while minimax's tree assumes adversarial responses.
Do not infer a forced win solely from a replay.

One MCTS iteration, one evaluated leaf, and one successor call measure
different work. Include rollout transitions in total successor calls. Compare
cumulative effort alongside mean work per decision, decision counts, and plies:
a longer game can use more total work even with cheaper individual searches.
Different depths, orders, and iteration limits can change the path of play.
Use the first recorded decision for comparisons requiring an identical state.
Depth and iteration limits are different constraints, not equal computational
budgets.

In the report, aggregate by level, method, and settings; explain specific
decisions through selected games without reproducing every run. Keep the
complete CSV for your own verification. The output directory contains individual
replays, `summary.csv`, and `index.html`, with settings and replay links for
inspection.

Rebuild HTML from existing CSV and replays with their saved settings,
without rerunning algorithms:

```bash
python run_experiments.py --refresh --output-dir experiment_results
```

The browser neither executes nor grades the search algorithms. Do not submit
generated replay or experiment output.

## Verification

Run both suites and the complete experiment matrix. Review every failure;
inspect game replays and search decisions for at least the danger, trap,
and cycle levels. Repeat a run with identical inputs to verify identical
results and traces. Check paired minimax/alpha-beta action sequences,
per-decision values, and actual search counts; verify scripted MCTS results
against independent hand traces. Confirm that every completed experiment
reaches a terminal outcome.

After tests pass, read `adversarial_search.py` and `tests/test_student.py`,
tracing at least one path through every TODO against the terminal, depth,
bound, selection, random-call, backpropagation, and trace rules. Review every
assignment-folder file, remove unintended files, and compare the exact planned
upload with the submission list.

In `report/report.tex`, record commands and outcomes, replay observations,
source/file-review outcomes, Python version, dependencies, one input
assumption, and one known limitation. Complete exactly one `AI_USE.md`
declaration and preserve reasonably available AI-use records as directed there.

## Report

Complete `report/report.tex` and compile `report/report.pdf` using the supplied
NeurIPS 2026 style without changing fonts, margins, or spacing. The eight-page
maximum includes traces, figures, tables, and references. Include:

1. the required pre-run traces;
2. the game model, utility, cutoff evaluation, and decisive algorithm choices;
3. minimax/alpha-beta agreement and effort under both move orders;
4. MCTS budgets, seeds, UCT choices, and fixed-perspective returns;
5. gameplay comparisons against the common ghost policy and replay evidence;
6. an independent student test and the plausible defect it detects;
7. commands, observed results, and source/submission review outcomes; and
8. the Python version, dependencies, one assumption, and one limitation.

Compile from `report/` so LaTeX finds the adjacent style:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Submission

Preserve these paths in the Blackboard submission:

```text
adversarial_search.py
tests/test_student.py
report/report.tex
report/report.pdf
AI_USE.md
```

Include `ai-records/` and related verification records when reasonably
available. Exclude generated experiment output, other generated HTML, caches,
virtual environments, credentials, and unchanged supplied files not listed above.

## 100-point rubric

| Component | Points |
| --- | ---: |
| Minimax | 20 |
| Alpha-beta pruning | 20 |
| Monte Carlo tree search | 25 |
| Student-written tests | 20 |
| Report and independent verification | 15 |
| **Total** | **100** |
