"""Compare search methods over complete games and write CSV plus offline replays."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
import re
import statistics
from typing import Any, Sequence

from demo import (
    ALGORITHMS, ASSIGNMENT_DIR, COUNT_FIELDS, PER_DECISION_FIELDS,
    validate_options, write_demo,
)


LEVELS_DIR = ASSIGNMENT_DIR / "levels"
DEFAULT_OUTPUT_DIR = ASSIGNMENT_DIR / "experiment_results"
INDEX_TEMPLATE = ASSIGNMENT_DIR / "viewer" / "experiments.html"
CONFIG_FIELDS = ("algorithm", "depth", "order", "iteration_limit", "exploration")
METRIC_FIELDS = ("utility", "plies", "decisions", "pellets_collected", *COUNT_FIELDS, *PER_DECISION_FIELDS)


@dataclass(frozen=True)
class ExperimentRow:
    """An attempted run; unfinished implementations have no invented metrics."""

    level: str
    algorithm: str
    seed: int
    depth: int | None
    order: str | None
    iteration_limit: int | None
    exploration: float | None
    status: str
    utility: float | None = None
    outcome: str | None = None
    plies: int | None = None
    decisions: int | None = None
    pellets_collected: int | None = None
    successor_count: int | None = None
    evaluation_count: int | None = None
    rollout_steps: int | None = None
    stored_nodes: int | None = None
    iterations: int | None = None
    cutoff_count: int | None = None
    pruned_actions: int | None = None
    frame_count: int | None = None
    successors_per_decision: float | None = None
    evaluations_per_decision: float | None = None
    replay: str | None = None
    error: str | None = None


def _resolve_levels(values: Sequence[Path] | None) -> tuple[Path, ...]:
    if values is None:
        levels = tuple(sorted(path.resolve() for path in LEVELS_DIR.glob("*.json")))
    else:
        found = []
        for value in values:
            candidates = [value] if value.is_absolute() else [
                Path.cwd() / value, ASSIGNMENT_DIR / value, LEVELS_DIR / value,
            ]
            if not value.suffix:
                candidates += [path.with_suffix(".json") for path in tuple(candidates)]
            match = next((path for path in candidates if path.is_file()), None)
            if match is None:
                raise ValueError(f"level does not exist: {value}")
            found.append(match.resolve())
        levels = tuple(found)
    if not levels:
        raise ValueError("at least one level is required")
    if len({path.stem for path in levels}) != len(levels):
        raise ValueError("level stems must be unique because they name replay folders")
    return levels


def _validate_output_dir(output_dir: Path) -> None:
    resolved = output_dir.resolve()
    if resolved == ASSIGNMENT_DIR or any(resolved.is_relative_to(ASSIGNMENT_DIR / name)
            for name in ("viewer", "levels", "tests", "report")):
        raise ValueError("output directory must not replace supplied assignment directories")


def _run_one(level: Path, *, algorithm: str, seed: int,
             depth: int | None, order: str | None, iteration_limit: int | None,
             exploration: float | None, output_dir: Path) -> ExperimentRow:
    common = dict(level=level.stem, algorithm=algorithm, seed=seed,
                  depth=depth, order=order, iteration_limit=iteration_limit,
                  exploration=exploration)
    suffix = f"-depth-{depth}-{order}" if depth is not None else (
        f"-iterations-{iteration_limit}-c-{exploration}" if iteration_limit is not None else "")
    relative = Path("replays") / level.stem / f"{algorithm}{suffix}-seed-{seed}.html"
    try:
        payload = write_demo(level, output_dir / relative, algorithm=algorithm,
                             seed=seed, depth=depth or 4, order=order or "canonical",
                             iterations=iteration_limit or 200,
                             exploration=exploration if exploration is not None else math.sqrt(2))
        summary = payload["summary"]
        return ExperimentRow(**common, status="ok", replay=relative.as_posix(),
                             **{name: summary[name] for name in (
                                 "utility", "outcome", "plies", "decisions",
                                 "pellets_collected", *COUNT_FIELDS, *PER_DECISION_FIELDS,
                             )})
    except NotImplementedError as error:
        return ExperimentRow(**common, status="todo", error=str(error))
    except Exception as error:  # Preserve later runs while recording each failure.
        return ExperimentRow(**common, status="error", error=f"{type(error).__name__}: {error}")


def run_experiments(levels: Sequence[Path], algorithms: Sequence[str] = ALGORITHMS,
                    *, seeds: Sequence[int] = (0, 1, 2),
                    depths: Sequence[int] = (2, 4, 6),
                    iterations: Sequence[int] = (50, 200, 800),
                    orders: Sequence[str] = ("canonical", "reverse"),
                    exploration: float = math.sqrt(2),
                    output_dir: Path = DEFAULT_OUTPUT_DIR) -> tuple[ExperimentRow, ...]:
    """Play each depth/order or MCTS budget configuration until a terminal state.

    Deterministic methods run once per configuration, labelled seed 0. Random
    and MCTS use each requested seed. Every Pac-Man turn starts a fresh search
    with that configuration; results include total effort and effort per turn.
    """

    for name, values in (("algorithms", algorithms), ("seeds", seeds), ("depths", depths),
                         ("iterations", iterations), ("orders", orders)):
        if not values or len(set(values)) != len(values):
            raise ValueError(f"{name} must be nonempty and contain no duplicates")
    if any(algorithm not in ALGORITHMS for algorithm in algorithms):
        raise ValueError("unknown algorithm label")
    for seed in seeds:
        validate_options(depth=4, order="canonical", iterations=200,
                         seed=seed, exploration=exploration)
    for depth in depths:
        validate_options(depth=depth, order="canonical", iterations=200,
                         seed=0, exploration=exploration)
    for budget in iterations:
        validate_options(depth=4, order="canonical", iterations=budget,
                         seed=0, exploration=exploration)
    if any(order not in ("canonical", "reverse") for order in orders):
        raise ValueError("orders must be canonical or reverse")
    levels = _resolve_levels(tuple(Path(level) for level in levels))
    _validate_output_dir(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for level in levels:
        for algorithm in algorithms:
            if algorithm in ("minimax", "alphabeta"):
                configs = [dict(seed=0, depth=depth, order=order,
                                iteration_limit=None, exploration=None)
                           for depth in depths for order in orders]
            elif algorithm == "mcts":
                configs = [dict(seed=seed, depth=None, order=None,
                                iteration_limit=budget, exploration=exploration)
                           for budget in iterations for seed in seeds]
            else:
                configs = [dict(seed=seed, depth=None, order=None,
                                iteration_limit=None, exploration=None) for seed in seeds]
            for config in configs:
                row = _run_one(level, algorithm=algorithm, output_dir=output_dir, **config)
                rows.append(row)
                detail = (f"outcome={row.outcome}, utility={row.utility}, successors={row.successor_count}"
                          if row.status == "ok" else row.error)
                print(f"{row.level} / {_label(row)} / seed {row.seed}: {row.status} ({detail})")
    return tuple(rows)


def write_summary_csv(rows: Sequence[ExperimentRow], output_path: Path) -> None:
    if output_path.is_symlink():
        raise ValueError("CSV output must not be a symbolic link")
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(ExperimentRow.__dataclass_fields__))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: "" if value is None else value for key, value in asdict(row).items()})


def read_summary_csv(input_path: Path) -> tuple[ExperimentRow, ...]:
    integers = {"seed", "depth", "iteration_limit", "plies", "decisions", "pellets_collected", *COUNT_FIELDS}
    rows = []
    with input_path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != list(ExperimentRow.__dataclass_fields__):
            raise ValueError("CSV columns must match the experiment summary format")
        for saved in reader:
            values: dict[str, Any] = {}
            for key, value in saved.items():
                if key is None or value is None:
                    raise ValueError("CSV row has an incorrect number of fields")
                if value == "":
                    values[key] = None
                elif key in integers:
                    values[key] = int(value)
                elif key in ("utility", "exploration", *PER_DECISION_FIELDS):
                    values[key] = float(value)
                else:
                    values[key] = value
            rows.append(ExperimentRow(**values))
    return tuple(rows)


def _label(row: ExperimentRow) -> str:
    name = {"random": "Random action", "minimax": "Minimax", "alphabeta": "Alpha-beta", "mcts": "MCTS"}[row.algorithm]
    if row.depth is not None:
        return f"{name} · depth {row.depth} · {row.order}"
    if row.iteration_limit is not None:
        return f"{name} · {row.iteration_limit} iterations · C={row.exploration:g}"
    return name


def _check_row(row: ExperimentRow) -> None:
    if row.algorithm not in ALGORITHMS or row.status not in ("ok", "todo", "error"):
        raise ValueError("unknown algorithm or status in summary")
    if not isinstance(row.level, str) or not row.level or isinstance(row.seed, bool) or not isinstance(row.seed, int) or row.seed < 0:
        raise ValueError("each row needs a level and a nonnegative integer seed")
    validate_options(depth=row.depth if row.depth is not None else 4,
                     order=row.order if row.order is not None else "canonical",
                     iterations=row.iteration_limit if row.iteration_limit is not None else 200,
                     exploration=row.exploration if row.exploration is not None else math.sqrt(2),
                     seed=row.seed)
    if row.algorithm in ("minimax", "alphabeta"):
        if row.depth is None or row.order is None or row.iteration_limit is not None or row.exploration is not None:
            raise ValueError("minimax and alpha-beta rows require only depth and order settings")
    elif row.algorithm == "mcts":
        if row.iteration_limit is None or row.exploration is None or row.depth is not None or row.order is not None:
            raise ValueError("MCTS rows require only iteration and exploration settings")
    elif any(getattr(row, name) is not None for name in CONFIG_FIELDS[1:]):
        raise ValueError("random-action rows have no search settings")
    if row.status == "ok":
        if isinstance(row.utility, bool) or not isinstance(row.utility, (int, float)) or row.utility not in (-1, 1):
            raise ValueError("completed games require terminal utility -1 or +1")
        for name in ("plies", "decisions", "pellets_collected", *COUNT_FIELDS):
            value = getattr(row, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"successful rows require nonnegative integer {name}")
        if row.outcome not in ("win", "capture", "timeout"):
            raise ValueError("completed games require a terminal outcome")
        if row.utility != (1 if row.outcome == "win" else -1):
            raise ValueError("terminal utility must match the game's outcome")
        for average, total in ((row.successors_per_decision, row.successor_count),
                               (row.evaluations_per_decision, row.evaluation_count)):
            if row.decisions == 0:
                if average is not None:
                    raise ValueError("effort per decision is undefined when no decision was made")
            elif (isinstance(average, bool) or not isinstance(average, (int, float))
                  or not math.isfinite(average)
                  or not math.isclose(average, total / row.decisions, rel_tol=1e-12, abs_tol=1e-12)):
                raise ValueError("effort per decision must equal total effort divided by decision count")
    elif any(getattr(row, name) is not None for name in (
        "utility", "outcome", "plies", "decisions", "pellets_collected", *COUNT_FIELDS, *PER_DECISION_FIELDS, "replay",
    )):
        raise ValueError("TODO/error rows must not contain measurements or replays")
    if row.replay is not None:
        path = Path(row.replay)
        if path.is_absolute() or ".." in path.parts or path.suffix.lower() != ".html" or not row.replay.startswith("replays/") or "\\" in row.replay:
            raise ValueError("replay paths must be local HTML files inside replays/")


def build_comparison_data(rows: Sequence[ExperimentRow]) -> dict[str, Any]:
    """Aggregate seeds only within the same level and search configuration.

    Expected coverage uses each configuration's observed seed set and all
    observed levels. A missing row therefore remains visible after
    refreshing a partial CSV; no metric pools unlike horizons or methods.
    """

    identities = set()
    configs: dict[tuple[Any, ...], ExperimentRow] = {}
    seeds: dict[tuple[Any, ...], set[int]] = {}
    levels: set[str] = set()
    grouped: dict[tuple[Any, ...], list[ExperimentRow]] = {}
    for row in rows:
        _check_row(row)
        config = tuple(getattr(row, name) for name in CONFIG_FIELDS)
        identity = (*config, row.level, row.seed)
        if identity in identities:
            raise ValueError("duplicate configuration/level/seed run")
        identities.add(identity)
        configs.setdefault(config, row)
        seeds.setdefault(config, set()).add(row.seed)
        levels.add(row.level)
        grouped.setdefault((*config, row.level), []).append(row)
    groups = []
    for config, example in configs.items():
        for level in sorted(levels):
            attempted = grouped.get((*config, level), [])
            successful = [row for row in attempted if row.status == "ok"]
            metrics = {}
            for name in (*METRIC_FIELDS, "win_rate"):
                values = ([float(row.outcome == "win") for row in successful] if name == "win_rate"
                          else [getattr(row, name) for row in successful])
                values = [value for value in values if value is not None]
                metrics[name] = dict(mean=statistics.mean(values) if values else None,
                                     sd=statistics.stdev(values) if len(values) > 1 else None)
            groups.append(dict(level=level, label=_label(example),
                               **{name: getattr(example, name) for name in CONFIG_FIELDS}, completed=len(successful),
                               attempted=len(attempted), expected=len(seeds[config]),
                               metrics=metrics))
    return dict(groups=groups, rows=[asdict(row) for row in rows],
                counts={status: sum(row.status == status for row in rows) for status in ("ok", "todo", "error")})


def replay_agreements(rows: Sequence[ExperimentRow], directory: Path) -> list[dict[str, Any]]:
    """Compare complete minimax/alpha-beta trajectories and per-move results.

    A matching final outcome alone says nothing about the intermediate choices.
    Missing or unfinished runs remain explicit; search counters and frames are
    deliberately excluded because pruning should change them.
    """

    pairs: dict[tuple[str, int, str], dict[str, ExperimentRow]] = {}
    for row in rows:
        if row.algorithm in ("minimax", "alphabeta"):
            pairs.setdefault((row.level, row.depth, row.order), {})[row.algorithm] = row

    def load(row: ExperimentRow) -> dict[str, Any] | None:
        if row.status != "ok" or row.replay is None:
            return None
        path = directory / row.replay
        if not path.is_file():
            return None
        match = re.search(r'<script id="trace-data"[^>]*>(.*?)</script>',
                          path.read_text(encoding="utf-8"), re.S)
        if match is None:
            raise ValueError(f"replay contains no saved trace: {row.replay}")
        payload = json.loads(match.group(1))
        if (not isinstance(payload, dict) or payload.get("schema_version") != 2
                or not isinstance(payload.get("snapshots"), list)
                or not isinstance(payload.get("decisions"), list)):
            raise ValueError(f"replay does not use the current game trace format: {row.replay}")
        configuration = payload.get("configuration", {})
        if (payload.get("algorithm") != row.algorithm or payload.get("seed") != row.seed
                or configuration.get("depth") != row.depth or configuration.get("order") != row.order):
            raise ValueError(f"replay settings do not match the summary: {row.replay}")
        return payload

    def signature(payload: dict[str, Any]) -> list[tuple[Any, ...]]:
        try:
            return [(decision["move_index"], decision["result"]["action"], decision["result"]["value"])
                    for decision in payload["decisions"]]
        except (KeyError, TypeError) as error:
            raise ValueError("replay has a malformed decision record") from error

    agreements = []
    for (level, depth, order), pair in sorted(pairs.items()):
        left = load(pair["minimax"]) if "minimax" in pair else None
        right = load(pair["alphabeta"]) if "alphabeta" in pair else None
        status, decisions = "missing", None
        if left is not None and right is not None:
            same = left["snapshots"] == right["snapshots"] and signature(left) == signature(right)
            status = "match" if same else "mismatch"
            decisions = min(len(left["decisions"]), len(right["decisions"]))
        agreements.append(dict(level=level, depth=depth, order=order,
                               status=status, decisions=decisions))
    return agreements


def write_index_html(rows: Sequence[ExperimentRow], output_path: Path) -> None:
    if output_path.is_symlink():
        raise ValueError("index output must not be a symbolic link")
    data = build_comparison_data(rows)
    data["agreements"] = replay_agreements(rows, output_path.parent)
    for row in data["rows"]:
        row["replay_available"] = bool(row["replay"] and (output_path.parent / row["replay"]).is_file())
        row["label"] = _label(ExperimentRow(**{key: value for key, value in row.items() if key in ExperimentRow.__dataclass_fields__}))
    encoded = json.dumps(data, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    encoded = encoded.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    template = INDEX_TEMPLATE.read_text(encoding="utf-8")
    placeholder = "__COMPARISON_JSON__"
    if template.count(placeholder) != 1:
        raise ValueError("experiment template must contain one data placeholder")
    output_path.write_text(template.replace(placeholder, encoded), encoding="utf-8")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithms", nargs="+", choices=ALGORITHMS, default=list(ALGORITHMS))
    parser.add_argument("--levels", nargs="+", type=Path)
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--depths", nargs="+", type=int, default=[2, 4, 6])
    parser.add_argument("--orders", nargs="+", choices=("canonical", "reverse"), default=["canonical", "reverse"])
    parser.add_argument("--iterations", nargs="+", type=int, default=[50, 200, 800])
    parser.add_argument("--exploration", type=float, default=math.sqrt(2))
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--refresh", action="store_true", help="rebuild index.html from saved summary.csv without rerunning search")
    args = parser.parse_args(argv)
    try:
        _validate_output_dir(args.output_dir)
        if args.refresh:
            rows = read_summary_csv(args.output_dir / "summary.csv")
        else:
            rows = run_experiments(_resolve_levels(args.levels), args.algorithms, **{
                name: getattr(args, name) for name in (
                    "seeds", "depths", "orders", "iterations", "exploration", "output_dir",
                )
            })
            write_summary_csv(rows, args.output_dir / "summary.csv")
        write_index_html(rows, args.output_dir / "index.html")
    except (OSError, TypeError, ValueError) as error:
        parser.exit(1, f"error: {error}\n")
    counts = {status: sum(row.status == status for row in rows) for status in ("ok", "todo", "error")}
    print(f"{counts['ok']} complete; {counts['todo']} TODO; {counts['error']} errors")
    print(f"wrote: {(args.output_dir / 'index.html').resolve()}")
    return int(counts["error"] > 0)


if __name__ == "__main__":
    raise SystemExit(main())
