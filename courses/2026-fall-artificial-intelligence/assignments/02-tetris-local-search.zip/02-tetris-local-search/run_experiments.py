"""Run a reproducible method/level/seed matrix and write CSV plus offline replays."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
import html
import json
import math
from pathlib import Path
import re
import statistics
from typing import Any, Sequence
from urllib.parse import quote

from demo import ALGORITHMS, ASSIGNMENT_DIR, add_search_arguments, search_options, write_demo
from tetris import TetrisProblem


LEVELS_DIR = ASSIGNMENT_DIR / "levels"
DEFAULT_OUTPUT_DIR = ASSIGNMENT_DIR / "experiment_results"
INDEX_TEMPLATE = ASSIGNMENT_DIR / "viewer" / "experiments.html"
SETTING_NAMES = ("budget", "sideways_limit", "width", "schedule", "population_size", "mutation_rate")


@dataclass(frozen=True)
class ExperimentRow:
    """One attempted run; TODO/error rows have no invented measurements."""

    level: str
    algorithm: str
    seed: int
    budget: int
    sideways_limit: int
    width: int
    schedule: str
    population_size: int
    mutation_rate: float
    status: str
    fitness: float | None = None
    lines_cleared: int | None = None
    pieces_placed: int | None = None
    holes: int | None = None
    aggregate_height: int | None = None
    bumpiness: int | None = None
    topped_out: bool | None = None
    evaluations: int | None = None
    stop_reason: str | None = None
    replay: str | None = None
    error: str | None = None


def _resolve_levels(values: Sequence[Path] | None) -> tuple[Path, ...]:
    if values is None:
        levels = tuple(sorted(path.resolve() for path in LEVELS_DIR.glob("*.json")))
        if not levels:
            raise ValueError(f"no supplied levels in {LEVELS_DIR}")
    else:
        found = []
        for value in values:
            candidates = [value] if value.is_absolute() else [
                Path.cwd() / value, ASSIGNMENT_DIR / value, LEVELS_DIR / value,
            ]
            if not value.suffix:
                candidates += [path.with_suffix(".json") for path in tuple(candidates)]
            match = next((path for path in candidates if path.is_file()), None)
            if match is None:
                raise ValueError(f"level does not exist: {value}")
            found.append(match.resolve())
        levels = tuple(found)
    stems = [path.stem for path in levels]
    if len(set(stems)) != len(stems):
        raise ValueError("level file stems must be unique because they name replay folders")
    return levels


def _run_one(
    level: Path,
    algorithm: str,
    seed: int,
    output_dir: Path,
    options: dict[str, Any],
) -> ExperimentRow:
    common = dict(level=level.stem, algorithm=algorithm, seed=seed, **options)
    # Store the actual hill-climbing setting even when --sideways-limit is set.
    if algorithm == "hill":
        common["sideways_limit"] = 0
    replay_name = f"{algorithm}-{options['schedule']}" if algorithm == "annealing" else algorithm
    relative = Path("replays") / level.stem / f"{replay_name}-seed-{seed}.html"
    try:
        result = write_demo(level, output_dir / relative, algorithm=algorithm, seed=seed, **options)
        rollout = TetrisProblem.from_file(level).rollout(result.best.state)
    except NotImplementedError as error:
        return ExperimentRow(**common, status="todo", error=str(error))
    except Exception as error:  # Keep failures visible without hiding later runs.
        return ExperimentRow(**common, status="error", error=f"{type(error).__name__}: {error}")
    return ExperimentRow(
        **common, status="ok", fitness=result.best.value,
        lines_cleared=rollout.lines_cleared, pieces_placed=rollout.pieces_placed,
        holes=rollout.holes, aggregate_height=rollout.aggregate_height,
        bumpiness=rollout.bumpiness, topped_out=rollout.topped_out,
        evaluations=result.evaluation_count, stop_reason=result.stop_reason,
        replay=relative.as_posix(),
    )


def run_experiments(
    levels: Sequence[Path],
    algorithms: Sequence[str],
    *,
    seeds: Sequence[int] = (0, 1, 2),
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    budget: int = 10000,
    sideways_limit: int = 3,
    width: int = 4,
    schedule: str | None = None,
    population_size: int = 8,
    mutation_rate: float = 0.2,
) -> tuple[ExperimentRow, ...]:
    """Run the matrix in input order under equal evaluation limits."""

    if len(set(algorithms)) != len(algorithms) or len(set(seeds)) != len(seeds):
        raise ValueError("algorithm labels and seeds must not contain duplicates")
    if schedule is not None and schedule not in ("fast", "gradual"):
        raise ValueError(f"unknown cooling schedule: {schedule!r}")
    annealing_schedules = ("fast", "gradual") if schedule is None else (schedule,)
    options = dict(budget=budget, sideways_limit=sideways_limit, width=width,
                   schedule="gradual" if schedule is None else schedule,
                   population_size=population_size,
                   mutation_rate=mutation_rate)
    search_options(argparse.Namespace(**options))
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for level in levels:
        for algorithm in algorithms:
            schedules = annealing_schedules if algorithm == "annealing" else (options["schedule"],)
            for run_schedule in schedules:
                run_options = dict(options, schedule=run_schedule)
                label = f"{algorithm} ({run_schedule})" if algorithm == "annealing" else algorithm
                for seed in seeds:
                    row = _run_one(level, algorithm, seed, output_dir, run_options)
                    rows.append(row)
                    detail = f"fitness={row.fitness:g}, evaluations={row.evaluations}" if row.status == "ok" else row.error
                    print(f"{row.level} / {label} / seed {seed}: {row.status} ({detail})")
    return tuple(rows)


def write_summary_csv(rows: Sequence[ExperimentRow], output_path: Path) -> None:
    """Write deterministic measurements and exact settings for every run."""

    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(ExperimentRow.__dataclass_fields__))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: "" if value is None else value for key, value in asdict(row).items()})


def read_summary_csv(input_path: Path) -> tuple[ExperimentRow, ...]:
    """Reload saved measurements so the index can be rebuilt without search."""

    integer_fields = {
        "seed", "budget", "sideways_limit", "width", "population_size", "lines_cleared",
        "pieces_placed", "holes", "aggregate_height", "bumpiness", "evaluations",
    }
    float_fields = {"mutation_rate", "fitness"}
    rows = []
    with input_path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != list(ExperimentRow.__dataclass_fields__):
            raise ValueError("CSV columns must match the experiment summary format")
        for saved in reader:
            values: dict[str, Any] = {}
            for key, value in saved.items():
                if key is None or value is None:
                    raise ValueError("CSV row has an incorrect number of fields")
                if value == "":
                    values[key] = None
                elif key in integer_fields:
                    values[key] = int(value)
                elif key in float_fields:
                    values[key] = float(value)
                elif key == "topped_out":
                    if value not in ("True", "False"):
                        raise ValueError("topped_out must be True, False, or empty")
                    values[key] = value == "True"
                else:
                    values[key] = value
            rows.append(ExperimentRow(**values))
    return tuple(rows)


def _settings(row: ExperimentRow) -> dict[str, Any]:
    return {name: getattr(row, name) for name in SETTING_NAMES}


def _method_label(row: ExperimentRow) -> str:
    if row.algorithm == "annealing" or row.algorithm.startswith("annealing ("):
        return f"Annealing ({row.schedule})"
    return {
        "random": "Random search", "hill": "Hill climbing",
        "sideways": "Sideways hill climbing", "restart": "Random-restart hill climbing",
        "beam": "Local beam search", "genetic": "Genetic algorithm",
    }.get(row.algorithm, row.algorithm)


def _read_progress(row: ExperimentRow, replay_dir: Path) -> list[tuple[int, float]]:
    """Read exact improvement events from a replay and check its CSV identity."""

    if not row.replay:
        raise ValueError("no replay recorded")
    replay_path = (replay_dir / row.replay).resolve()
    if not replay_path.is_relative_to(replay_dir.resolve()):
        raise ValueError("replay path is outside the results directory")
    source = replay_path.read_text(encoding="utf-8")
    match = re.search(
        r'<script\b[^>]*\bid=[\"\']trace-data[\"\'][^>]*>(.*?)</script\s*>',
        source, flags=re.DOTALL | re.IGNORECASE,
    )
    if match is None:
        raise ValueError("replay has no recorded trace")
    payload = json.loads(match.group(1))
    if payload["seed"] != row.seed or Path(payload["level"]).stem != row.level:
        raise ValueError("replay level or seed does not match the CSV")
    # Saved instructor comparisons may label the two schedules explicitly.
    if payload["algorithm"] != row.algorithm.split(" (")[0]:
        raise ValueError("replay algorithm does not match the CSV")
    configuration = payload["configuration"]
    if not isinstance(configuration, dict) or any(
        configuration.get(name) != value for name, value in _settings(row).items()
    ):
        raise ValueError("replay settings do not match the CSV")
    result = payload["result"]
    history = result["history"]
    count = row.evaluations
    if not isinstance(count, int) or not 1 <= count <= row.budget:
        raise ValueError("invalid evaluation count")
    if result["evaluation_count"] != count or len(history) != count:
        raise ValueError("replay evaluation count does not match the CSV")
    points = []
    best = -math.inf
    for evaluation, record in enumerate(history, 1):
        value, recorded_best = record["value"], record["best_value"]
        if record["evaluation"] != evaluation or not all(
            isinstance(number, (int, float)) and not isinstance(number, bool)
            and math.isfinite(number) for number in (value, recorded_best)
        ):
            raise ValueError("invalid evaluation history")
        new_best = max(best, value)
        if recorded_best != new_best:
            raise ValueError("history does not record running best fitness")
        if new_best > best:
            points.append((evaluation, new_best))
        best = new_best
    if best != row.fitness or result["best"]["value"] != row.fitness:
        raise ValueError("replay final fitness does not match the CSV")
    return points


def _mean_progress(traces: Sequence[list[tuple[int, float]]], budget: int) -> list[list[float]]:
    """Average step functions, retaining each stopped run's final incumbent.

    Only improvement events are needed: this preserves the mean at every
    evaluation without embedding full candidate histories in the index.
    """

    events: dict[int, list[tuple[int, float]]] = {}
    for index, trace in enumerate(traces):
        for evaluation, value in trace:
            events.setdefault(evaluation, []).append((index, value))
    current = [0.0] * len(traces)
    points = []
    for evaluation in sorted(events):
        for index, value in events[evaluation]:
            current[index] = value
        points.append([evaluation, statistics.mean(current)])
    if points[-1][0] != budget:
        points.append([budget, points[-1][1]])
    return points


def build_comparison_data(rows: Sequence[ExperimentRow], replay_dir: Path) -> dict[str, Any]:
    """Summarize seeds within levels, then give each observed level equal weight.

    A method includes its exact configuration. Coverage uses all levels and
    each level's union of seeds, so omitted runs remain visible. Partial
    summaries are descriptive; they must not be mistaken for a complete matrix.
    """

    levels = sorted({row.level for row in rows})
    expected_seeds = {level: {row.seed for row in rows if row.level == level} for level in levels}
    grouped: dict[tuple[Any, ...], list[ExperimentRow]] = {}
    identities = set()
    for row in rows:
        key = (row.algorithm, *(getattr(row, name) for name in SETTING_NAMES))
        identity = (key, row.level, row.seed)
        if identity in identities:
            raise ValueError("duplicate method/configuration/level/seed run")
        identities.add(identity)
        if row.status not in ("ok", "todo", "error"):
            raise ValueError(f"unknown run status: {row.status}")
        if row.status == "ok" and not all(
            isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
            for value in (row.fitness, row.lines_cleared, row.evaluations)
        ):
            raise ValueError("successful runs require finite fitness, lines, and evaluations")
        grouped.setdefault(key, []).append(row)

    groups = list(grouped.values())
    labels = [_method_label(group[0]) for group in groups]
    for index, group in enumerate(groups):
        base = _method_label(group[0])
        peers = [other[0] for other in groups if _method_label(other[0]) == base]
        if len(peers) > 1:
            different = [name for name in SETTING_NAMES if len({getattr(row, name) for row in peers}) > 1]
            suffix = ", ".join(f"{name}={getattr(group[0], name)}" for name in different)
            labels[index] = f"{base} · {suffix or group[0].algorithm}"

    level_data: dict[str, dict[str, Any]] = {
        level: {"name": level, "series": []} for level in levels
    }
    methods = []
    for index, group in enumerate(groups):
        method_id, label = f"method-{index}", labels[index]
        settings = _settings(group[0])
        successful_levels = []
        completed = 0
        for level in levels:
            successful = sorted(
                (row for row in group if row.level == level and row.status == "ok"),
                key=lambda row: row.seed,
            )
            completed += len(successful)
            values = [row.fitness for row in successful]
            mean_fitness = statistics.mean(values) if values else None
            mean_lines = statistics.mean(row.lines_cleared for row in successful) if values else None
            mean_evaluations = statistics.mean(row.evaluations for row in successful) if values else None
            if successful:
                successful_levels.append((mean_fitness, mean_lines, mean_evaluations))
            traces, trace_errors = [], []
            for row in successful:
                try:
                    traces.append(_read_progress(row, replay_dir))
                except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
                    trace_errors.append(f"seed {row.seed}: {error}")
            points = _mean_progress(traces, settings["budget"]) if traces and not trace_errors else []
            level_data[level]["series"].append({
                "id": method_id, "label": label, "budget": settings["budget"],
                "completed": len(successful), "expected": len(expected_seeds[level]),
                "traced": len(traces), "seeds": [row.seed for row in successful],
                "points": points, "mean_evaluations": mean_evaluations,
                "mean_fitness": mean_fitness,
                "fitness_sd": statistics.stdev(values) if len(values) > 1 else None,
                "trace_errors": trace_errors,
            })
        means = [statistics.mean(values) for values in zip(*successful_levels)] if successful_levels else [None] * 3
        methods.append({
            "id": method_id, "label": label, "settings": settings,
            "mean_fitness": means[0], "mean_lines": means[1], "mean_evaluations": means[2],
            "levels_completed": len(successful_levels), "levels_expected": len(levels),
            "completed": completed, "expected": sum(map(len, expected_seeds.values())),
        })
    return {"methods": methods, "levels": list(level_data.values())}


def write_index_html(rows: Sequence[ExperimentRow], output_path: Path) -> None:
    """Write one progress chart, equal-level summary, and expandable run details."""

    data = build_comparison_data(rows, output_path.parent)

    def cell(value: object | None) -> str:
        if value is None:
            return "—"
        if isinstance(value, float):
            return html.escape(f"{value:.6f}")
        return html.escape(str(value))

    overall_rows = []
    for method in data["methods"]:
        overall_rows.append("<tr>" + "".join(f"<td>{cell(value)}</td>" for value in (
            method["label"], method["mean_fitness"],
            f'{method["mean_lines"]:.2f}' if method["mean_lines"] is not None else None,
            f'{method["mean_evaluations"]:,.0f}' if method["mean_evaluations"] is not None else None,
            f'{method["levels_completed"]}/{method["levels_expected"]}',
            f'{method["completed"]}/{method["expected"]}',
        )) + "</tr>")
    detail_rows = []
    for row in rows:
        replay = (
            f'<a href="{html.escape(quote(row.replay), quote=True)}">Open replay</a>'
            if row.status == "ok" and row.replay else "—"
        )
        details = (row.error + " · " if row.error else "") + ", ".join(
            f"{name}={value}" for name, value in _settings(row).items()
        )
        detail_rows.append("<tr>" + "".join(f"<td>{cell(value)}</td>" for value in (
            row.level, row.algorithm, row.seed, row.status, row.fitness,
            row.lines_cleared, row.pieces_placed, row.evaluations, row.budget,
            row.stop_reason,
        )) + f"<td>{replay}</td><td>{cell(details)}</td></tr>")
    counts = {status: sum(row.status == status for row in rows) for status in ("ok", "todo", "error")}
    encoded = json.dumps(data, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    encoded = encoded.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    limits = ", ".join(f"{limit:,}" for limit in sorted({row.budget for row in rows})) or "none"
    seeds = ", ".join(str(seed) for seed in sorted({row.seed for row in rows})) or "none"
    replacements = {
        "__COUNTS__": f"{counts['ok']} complete · {counts['todo']} TODO · {counts['error']} errors",
        "__COVERAGE__": cell(f"{len(data['levels'])} levels · seeds {seeds} · evaluation limits {limits}"),
        "__OVERALL__": "".join(overall_rows), "__RUNS__": "".join(detail_rows),
        "__PROGRESS_JSON__": encoded,
    }
    template = INDEX_TEMPLATE.read_text(encoding="utf-8")
    if any(template.count(placeholder) != 1 for placeholder in replacements):
        raise ValueError("experiment template must contain each placeholder exactly once")
    # One substitution pass prevents labels containing placeholder text from
    # accidentally becoming markup or changing the embedded measurements.
    rendered = re.sub("|".join(map(re.escape, replacements)), lambda match: replacements[match[0]], template)
    output_path.write_text(rendered, encoding="utf-8")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, conflict_handler="resolve")
    parser.add_argument("--levels", nargs="+", type=Path, help="JSON paths or supplied names (default: all supplied levels)")
    parser.add_argument("--algorithms", nargs="+", choices=ALGORITHMS, default=list(ALGORITHMS))
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--refresh", action="store_true",
                        help="rebuild index.html from the output directory's CSV and replays; uses saved settings, runs no search")
    add_search_arguments(parser)
    parser.add_argument("--schedule", choices=("fast", "gradual"), default=None,
                        help="restrict annealing to one schedule (default: run fast and gradual); other methods run once")
    args = parser.parse_args(argv)
    try:
        if args.refresh:
            rows = read_summary_csv(args.output_dir / "summary.csv")
        else:
            levels = _resolve_levels(args.levels)
            options = search_options(args)
            rows = run_experiments(levels, args.algorithms, seeds=args.seeds, output_dir=args.output_dir, **options)
            write_summary_csv(rows, args.output_dir / "summary.csv")
        write_index_html(rows, args.output_dir / "index.html")
    except (OSError, TypeError, ValueError) as error:
        parser.exit(1, f"error: {error}\n")
    print(f"wrote: {(args.output_dir / 'index.html').resolve()}")
    # Untouched student TODOs are expected. Unexpected failures are actionable.
    return int(any(row.status == "error" for row in rows))


if __name__ == "__main__":
    raise SystemExit(main())
