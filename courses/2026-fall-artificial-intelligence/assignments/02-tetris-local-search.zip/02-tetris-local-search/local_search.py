"""Supplied local-search infrastructure and six student TODO functions.

The random baseline and genetic generation loop are complete. Search methods
operate on immutable tuples through the public finite-domain problem interface;
instructor tests may use small nongame landscapes.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from numbers import Real
import random
from typing import Callable, Hashable, Iterable, Protocol


Candidate = tuple[Hashable, ...]


class Problem(Protocol):
    domains: tuple[tuple[Hashable, ...], ...]

    def neighbors(self, state: Candidate) -> Iterable[Candidate]:
        """Return distinct one-gene neighbors in canonical order."""

    def evaluate(self, state: Candidate) -> float:
        """Return a finite fitness; larger values are better."""


def require_int(value: int, name: str, minimum: int = 0) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")


def require_finite(value: float, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except OverflowError as error:
        raise ValueError(f"{name} must be a finite real number") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite real number")
    return result


class RandomSource:
    """Private seeded randomness, optionally replaced by exact test draws.

    ``integers`` supplies literal results for index(n), not random seeds or
    values reduced modulo n. An exhausted or out-of-range script raises, so a
    test detects extra draws. The two scripted streams are independent.
    """

    def __init__(
        self,
        seed: int = 0,
        *,
        integers: Iterable[int] | None = None,
        uniforms: Iterable[float] | None = None,
    ) -> None:
        require_int(seed, "seed")
        self._random = random.Random(seed)
        self._integers = None if integers is None else iter(integers)
        self._uniforms = None if uniforms is None else iter(uniforms)

    def index(self, size: int) -> int:
        require_int(size, "choice size", 1)
        value = (self._random.randrange(size) if self._integers is None
                 else next(self._integers))
        require_int(value, "scripted index")
        if value >= size:
            raise ValueError("scripted index is outside the choice range")
        return value

    def uniform(self) -> float:
        value = (self._random.random() if self._uniforms is None
                 else next(self._uniforms))
        value = require_finite(value, "uniform draw")
        if not 0 <= value < 1:
            raise ValueError("uniform draw must be in [0, 1)")
        return value


@dataclass(frozen=True)
class ScoredCandidate:
    state: Candidate
    value: float
    order: int


@dataclass(frozen=True)
class EvaluationRecord:
    evaluation: int
    state: Candidate
    value: float
    best_value: float


@dataclass(frozen=True)
class SearchFrame:
    evaluation_count: int
    phase: str
    current: tuple[ScoredCandidate, ...]
    proposal: ScoredCandidate | None = None
    accepted: bool | None = None
    temperature: float | None = None


@dataclass(frozen=True)
class SearchResult:
    best: ScoredCandidate
    evaluation_count: int
    history: tuple[EvaluationRecord, ...]
    frames: tuple[SearchFrame, ...]
    stop_reason: str


class BudgetExhausted(RuntimeError):
    """An objective call would exceed the published evaluation budget."""


def unique_states(states: Iterable[Candidate]) -> tuple[Candidate, ...]:
    """Deduplicate while preserving first occurrence; never iterate a set."""
    return tuple(dict.fromkeys(states))


def rank_unique(candidates: Iterable[ScoredCandidate]) -> tuple[ScoredCandidate, ...]:
    """Descending fitness, then earliest evaluation, with one entry per state."""
    ordered = sorted(candidates, key=lambda item: (-item.value, item.order))
    result: dict[Candidate, ScoredCandidate] = {}
    for item in ordered:
        result.setdefault(item.state, item)
    return tuple(result.values())


class SearchContext:
    """Supplied accounting, sampling, incumbent tracking, and trace helpers.

    Every evaluate call invokes the problem and consumes one budget unit, even
    for a previously evaluated state. Pure comparisons and retained elites do
    not consume evaluations. Algorithms must use this context for scoring.
    """

    def __init__(
        self, problem: Problem, *, budget: int = 10000, seed: int = 0,
        rng: RandomSource | None = None,
    ) -> None:
        require_int(budget, "budget", 1)
        require_int(seed, "seed")
        domains = problem.domains
        if not isinstance(domains, tuple) or not domains:
            raise ValueError("domains must be a nonempty tuple")
        for domain in domains:
            if not isinstance(domain, tuple) or not domain:
                raise ValueError("each domain must be a nonempty tuple")
            try:
                if len(set(domain)) != len(domain):
                    raise ValueError("domain entries must be distinct")
            except TypeError as error:
                raise ValueError("domain entries must be hashable") from error
        self.problem = problem
        self.domains = domains
        self.budget = budget
        self.rng = RandomSource(seed) if rng is None else rng
        self.total_states = math.prod(len(domain) for domain in domains)
        self.best: ScoredCandidate | None = None
        self.history: list[EvaluationRecord] = []
        self.frames: list[SearchFrame] = []

    @property
    def evaluation_count(self) -> int:
        return len(self.history)

    @property
    def remaining(self) -> int:
        return self.budget - self.evaluation_count

    def validate_state(self, state: Candidate) -> None:
        if not isinstance(state, tuple) or len(state) != len(self.domains):
            raise ValueError("candidate must be a tuple with one gene per domain")
        try:
            hash(state)
        except TypeError as error:
            raise ValueError("candidate genes must be hashable") from error
        if any(gene not in domain for gene, domain in zip(state, self.domains)):
            raise ValueError("candidate gene is outside its domain")

    def evaluate(self, state: Candidate) -> ScoredCandidate:
        self.validate_state(state)
        if self.remaining == 0:
            raise BudgetExhausted("objective-evaluation budget exhausted")
        value = require_finite(self.problem.evaluate(state), "fitness")
        item = ScoredCandidate(state, value, self.evaluation_count + 1)
        if self.best is None or value > self.best.value:
            self.best = item
        self.history.append(EvaluationRecord(item.order, state, value, self.best.value))
        return item

    def neighbors(self, state: Candidate) -> tuple[Candidate, ...]:
        self.validate_state(state)
        result = tuple(self.problem.neighbors(state))
        for neighbor in result:
            self.validate_state(neighbor)
            if sum(a != b for a, b in zip(state, neighbor)) != 1:
                raise ValueError("each neighbor must change exactly one gene")
        if len(set(result)) != len(result):
            raise ValueError("neighbors must be distinct")
        return result

    def random_state(self) -> Candidate:
        """One index draw per gene, including singleton domains."""
        return tuple(domain[self.rng.index(len(domain))] for domain in self.domains)

    def initial(self, start: Candidate | None = None) -> ScoredCandidate:
        """A supplied start uses no randomness; otherwise sample one state."""
        return self.evaluate(self.random_state() if start is None else start)

    def sample_distinct(self, count: int) -> tuple[Candidate, ...]:
        """Sample ordered distinct states with one index draw per state.

        A sparse partial Fisher-Yates shuffle handles arbitrarily large finite
        products without allocating the full state space or rejection loops.
        The last gene is the fastest-changing digit in the mixed-radix index.
        """
        require_int(count, "sample count")
        count = min(count, self.total_states)
        replacements: dict[int, int] = {}
        states = []
        for offset in range(count):
            remaining = self.total_states - offset
            slot = self.rng.index(remaining)
            encoded = replacements.get(slot, slot)
            replacements[slot] = replacements.get(remaining - 1, remaining - 1)
            genes = []
            for domain in reversed(self.domains):
                encoded, digit = divmod(encoded, len(domain))
                genes.append(domain[digit])
            states.append(tuple(reversed(genes)))
        return tuple(states)

    def random_neighbor(self, state: Candidate) -> Candidate | None:
        """One index draw when neighbors exist, otherwise no draw."""
        neighbors = self.neighbors(state)
        return neighbors[self.rng.index(len(neighbors))] if neighbors else None

    def record(
        self, phase: str, current: Iterable[ScoredCandidate], *,
        proposal: ScoredCandidate | None = None, accepted: bool | None = None,
        temperature: float | None = None,
    ) -> None:
        self.frames.append(SearchFrame(
            self.evaluation_count, phase, tuple(current), proposal, accepted, temperature,
        ))

    def finish(self, reason: str) -> SearchResult:
        if self.best is None:
            raise ValueError("a result needs at least one evaluated candidate")
        return SearchResult(self.best, self.evaluation_count, tuple(self.history),
                            tuple(self.frames), reason)


def fast_cooling(step: int) -> float:
    """T(t) = 0.04 * 0.95**t; t=0 precedes the first proposal."""
    require_int(step, "cooling step")
    return 0.04 * 0.95 ** step


def gradual_cooling(step: int) -> float:
    """T(t) = 0.04 * 0.995**t; shares the fast schedule's initial T."""
    require_int(step, "cooling step")
    return 0.04 * 0.995 ** step


def random_search(problem: Problem, *, budget: int = 10000, seed: int = 0) -> SearchResult:
    """Independent uniform candidate sampling, with replacement."""
    context = SearchContext(problem, budget=budget, seed=seed)
    while context.remaining:
        candidate = context.evaluate(context.random_state())
        context.record("sample", (candidate,))
    return context.finish("budget")


def _tournament(context: SearchContext, population: tuple[ScoredCandidate, ...]) -> ScoredCandidate:
    draws = tuple(population[context.rng.index(len(population))] for _ in range(3))
    return rank_unique(draws)[0]


def genetic_algorithm(
    problem: Problem, *, budget: int = 10000, seed: int = 0,
    population_size: int = 8, mutation_rate: float = 0.2,
) -> SearchResult:
    """Supplied one-elite generational GA; only its two operators are TODOs.

    Initial states are distinct. Later populations may contain duplicates.
    Each child uses two three-draw tournaments, one cut draw when length > 1,
    and one mutation coin. A successful coin additionally draws a mutable gene
    and a different value, if any gene is mutable. A partial final generation
    is recorded and contributes to the global incumbent before budget exit.
    """
    require_int(population_size, "population_size", 2)
    mutation_rate = require_finite(mutation_rate, "mutation_rate")
    if not 0 <= mutation_rate <= 1:
        raise ValueError("mutation_rate must be in [0, 1]")
    context = SearchContext(problem, budget=budget, seed=seed)
    size = min(population_size, context.total_states, context.remaining)
    population = rank_unique(context.evaluate(state)
                             for state in context.sample_distinct(size))
    context.record("initial", population)
    if context.remaining == 0:
        return context.finish("budget")
    if context.total_states == 1:
        return context.finish("no_neighbors")
    # With a budget of one, the early budget return above prevents a size-one
    # population from creating a zero-offspring generation.
    mutable_indices = tuple(i for i, domain in enumerate(context.domains) if len(domain) > 1)
    while context.remaining:
        elite = min(population, key=lambda item: (-item.value, item.order))
        next_population = [elite]
        while len(next_population) < size and context.remaining:
            parent_a = _tournament(context, population)
            parent_b = _tournament(context, population)
            if len(context.domains) > 1:
                cut = 1 + context.rng.index(len(context.domains) - 1)
                child = crossover(parent_a.state, parent_b.state, cut)
            else:
                child = parent_a.state
            mutation_coin = context.rng.uniform()
            if mutation_coin < mutation_rate and mutable_indices:
                index = mutable_indices[context.rng.index(len(mutable_indices))]
                alternatives = tuple(gene for gene in context.domains[index] if gene != child[index])
                replacement = alternatives[context.rng.index(len(alternatives))]
                child = mutate(child, index, replacement)
            next_population.append(context.evaluate(child))
        population = tuple(sorted(next_population, key=lambda item: (-item.value, item.order)))
        context.record("generation", population)
    return context.finish("budget")


def hill_climbing(
    problem: Problem, *, budget: int = 10000, seed: int = 0,
    sideways_limit: int = 0, start: Candidate | None = None,
) -> SearchResult:
    """TODO: strict steepest ascent with a bounded consecutive-sideways policy.

    Use a complete neighborhood scan, supplied ranking, and SearchContext.
    Do not begin a scan that cannot fit in the remaining evaluation budget.
    See ASSIGNMENT.md for acceptance, termination, and frame requirements.
    """
    raise NotImplementedError("implement hill_climbing")


def random_restart_hill_climbing(
    problem: Problem, *, budget: int = 10000, seed: int = 0,
    sideways_limit: int = 0,
) -> SearchResult:
    """TODO: hill-climbing episodes sharing one context, RNG, and total budget."""
    raise NotImplementedError("implement random_restart_hill_climbing")


def simulated_annealing(
    problem: Problem, *, budget: int = 10000, seed: int = 0,
    schedule: Callable[[int], float] = gradual_cooling,
    start: Candidate | None = None,
) -> SearchResult:
    """TODO: accept improvements/ties; accept losses with exp(delta / T).

    For a loss only, consume one uniform draw and accept iff u < exp(delta/T).
    Return the best evaluated candidate even if the final current state is worse.
    """
    raise NotImplementedError("implement simulated_annealing")


def local_beam_search(
    problem: Problem, *, budget: int = 10000, seed: int = 0, width: int = 4,
) -> SearchResult:
    """TODO: pool distinct successors and retain the best width candidates.

    Initialize with context.sample_distinct(min(width, total_states, budget)).
    Parents do not join the successor pool. A generation requires a complete
    pool evaluation; stop on budget if the full pool does not fit.
    """
    raise NotImplementedError("implement local_beam_search")


def crossover(parent_a: Candidate, parent_b: Candidate, cut: int) -> Candidate:
    """TODO: return parent_a[:cut] + parent_b[cut:] without changing either.

    Parents must be nonempty hashable tuples of equal length >= 2; cut is an
    integer in [1, len(parent_a)-1]. Raise ValueError for invalid inputs.
    The supplied driver chooses the cut and compatible per-gene domains.
    """
    raise NotImplementedError("implement crossover")


def mutate(state: Candidate, index: int, replacement: Hashable) -> Candidate:
    """TODO: return a tuple replacing exactly the selected gene.

    Require a nonempty hashable tuple, an integer index in range, and a
    hashable replacement different from the current gene; otherwise ValueError.
    The supplied driver guarantees replacement belongs to that gene's domain.
    """
    raise NotImplementedError("implement mutate")
