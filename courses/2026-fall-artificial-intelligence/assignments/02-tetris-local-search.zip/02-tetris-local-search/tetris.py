"""Supplied, deterministic Tetris planning problem; no student TODOs.

A placement is (rotation_index, left_column), independent of the board. A plan
specifies one placement for every piece, including pieces after a possible
top-out. Coordinates start at the top left: x increases right, y increases down.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Iterator, Mapping

WIDTH = 10
HEIGHT = 20
FULL_ROW = (1 << WIDTH) - 1
QUALITY_MAX = 5 * WIDTH * HEIGHT + WIDTH * HEIGHT + (WIDTH - 1) * HEIGHT

Placement = tuple[int, int]
Plan = tuple[Placement, ...]
Board = tuple[str, ...]
Cells = tuple[tuple[int, int], ...]


def _rotations(rows: tuple[str, ...]) -> tuple[Cells, ...]:
    """Normalize each clockwise rotation; preserve the first unique occurrence."""
    cells = tuple((x, y) for y, row in enumerate(rows)
                  for x, cell in enumerate(row) if cell == "#")
    variants: list[Cells] = []
    for _ in range(4):
        left = min(x for x, _ in cells)
        top = min(y for _, y in cells)
        cells = tuple(sorted(((x - left, y - top) for x, y in cells),
                             key=lambda cell: (cell[1], cell[0])))
        if cells not in variants:
            variants.append(cells)
        cells = tuple((-y, x) for x, y in cells)
    return tuple(variants)


ROTATIONS: Mapping[str, tuple[Cells, ...]] = MappingProxyType({
    "I": _rotations(("####",)),
    "O": _rotations(("##", "##")),
    "T": _rotations((".#.", "###")),
    "S": _rotations((".##", "##.")),
    "Z": _rotations(("##.", ".##")),
    "J": _rotations(("#..", "###")),
    "L": _rotations(("..#", "###")),
})


def _domain(piece: str) -> tuple[Placement, ...]:
    return tuple((rotation, column)
                 for rotation, cells in enumerate(ROTATIONS[piece])
                 for column in range(WIDTH - max(x for x, _ in cells)))


DOMAINS: Mapping[str, tuple[Placement, ...]] = MappingProxyType({
    piece: _domain(piece) for piece in ROTATIONS
})


def _shape_rows(cells: Cells, column: int) -> tuple[int, ...]:
    rows = [0] * (max(y for _, y in cells) + 1)
    for x, y in cells:
        rows[y] |= 1 << (x + column)
    return tuple(rows)


_PLACEMENT_ROWS = {
    piece: {placement: _shape_rows(ROTATIONS[piece][placement[0]], placement[1])
            for placement in DOMAINS[piece]}
    for piece in ROTATIONS
}


def _board_strings(rows: list[int] | tuple[int, ...]) -> Board:
    return tuple("".join("#" if row & (1 << x) else "." for x in range(WIDTH))
                 for row in rows)


def _board_metrics(rows: list[int]) -> tuple[int, int, int]:
    heights: list[int] = []
    holes = 0
    for x in range(WIDTH):
        height = 0
        seen_block = False
        for y, row in enumerate(rows):
            if row & (1 << x):
                if not seen_block:
                    height = HEIGHT - y
                    seen_block = True
            elif seen_block:
                holes += 1
        heights.append(height)
    return holes, sum(heights), sum(abs(a - b) for a, b in zip(heights, heights[1:]))


@dataclass(frozen=True)
class Frame:
    """A board after a lock and clear, or the unchanged board after top-out.

    The initial frame has piece_index=-1, piece="", and placement=None.
    lines_cleared and pieces_placed are cumulative.
    """

    piece_index: int
    piece: str
    placement: Placement | None
    board: Board
    lines_cleared: int
    pieces_placed: int
    topped_out: bool


@dataclass(frozen=True)
class Rollout:
    fitness: float
    lines_cleared: int
    pieces_placed: int
    holes: int
    aggregate_height: int
    bumpiness: int
    topped_out: bool
    final_board: Board
    snapshots: tuple[Frame, ...] = ()


@dataclass(frozen=True)
class TetrisProblem:
    """A fixed 10-by-20 board and finite, known tetromino sequence.

    Distinct rotations are numbered from the pictured spawn orientation in
    ROTATIONS, proceeding clockwise and omitting duplicates. Domains are ordered
    first by rotation, then by left column. No lateral movement, wall kicks,
    hold, or player timing is modeled.
    """

    name: str
    board: Board
    pieces: tuple[str, ...]
    description: str = ""
    initial_plan: Plan | None = None
    domains: tuple[tuple[Placement, ...], ...] = field(init=False, repr=False)
    initial_state: Plan = field(init=False)
    _initial_rows: tuple[int, ...] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("name must be a nonempty string")
        if not isinstance(self.description, str):
            raise ValueError("description must be a string")
        if not isinstance(self.board, (list, tuple)) or len(self.board) != HEIGHT:
            raise ValueError(f"board must contain exactly {HEIGHT} rows")
        for row in self.board:
            if not isinstance(row, str) or len(row) != WIDTH or set(row) - {".", "#"}:
                raise ValueError(f"each board row must contain exactly {WIDTH} '.' or '#' cells")
            if row == "#" * WIDTH:
                raise ValueError("initial board must not contain completed rows")
        if not isinstance(self.pieces, (list, tuple)) or not self.pieces:
            raise ValueError("pieces must be a nonempty sequence")
        if any(not isinstance(piece, str) or piece not in ROTATIONS for piece in self.pieces):
            raise ValueError("pieces must use uppercase I, O, T, S, Z, J, or L")
        board = tuple(self.board)
        pieces = tuple(self.pieces)
        object.__setattr__(self, "board", board)
        object.__setattr__(self, "pieces", pieces)
        object.__setattr__(self, "domains", tuple(DOMAINS[piece] for piece in pieces))
        object.__setattr__(self, "_initial_rows", tuple(
            sum(1 << x for x, cell in enumerate(row) if cell == "#") for row in board
        ))
        if self.initial_plan is None:
            plan = tuple((0, (WIDTH - (max(x for x, _ in ROTATIONS[piece][0]) + 1)) // 2)
                         for piece in pieces)
        else:
            plan = self.validate_plan(self.initial_plan)
        object.__setattr__(self, "initial_plan", plan)
        object.__setattr__(self, "initial_state", plan)

    @classmethod
    def from_dict(cls, data: object) -> TetrisProblem:
        """Load the documented JSON schema; reject unknown fields and bad plans."""
        if not isinstance(data, dict):
            raise ValueError("level must be a JSON object")
        required = {"name", "board", "pieces"}
        allowed = required | {"description", "initial_plan"}
        if not required <= data.keys():
            raise ValueError(f"level is missing required fields: {sorted(required - data.keys())}")
        if data.keys() - allowed:
            raise ValueError(f"unknown level fields: {sorted(map(str, data.keys() - allowed))}")
        return cls(**data)

    @classmethod
    def from_file(cls, path: str | Path) -> TetrisProblem:
        with Path(path).open(encoding="utf-8") as handle:
            return cls.from_dict(json.load(handle))

    def validate_plan(self, plan: object) -> Plan:
        """Return an immutable plan, rejecting bools and out-of-domain genes."""
        if not isinstance(plan, (list, tuple)) or len(plan) != len(self.pieces):
            raise ValueError("plan must have exactly one placement per piece")
        placements: list[Placement] = []
        for index, (gene, domain) in enumerate(zip(plan, self.domains)):
            if not isinstance(gene, (list, tuple)) or len(gene) != 2:
                raise ValueError(f"placement {index} must be (rotation, column)")
            if any(type(value) is not int for value in gene):
                raise ValueError(f"placement {index} coordinates must be integers, not bools")
            placement = (gene[0], gene[1])
            if placement not in domain:
                raise ValueError(f"placement {index} is outside the domain for {self.pieces[index]}")
            placements.append(placement)
        return tuple(placements)

    def neighbors(self, plan: Plan) -> Iterator[Plan]:
        """Yield every one-gene change in gene-index, then domain order.

        Different plans can produce the same physical outcome. They remain
        distinct candidates, including changes to genes after an early top-out.
        """
        plan = self.validate_plan(plan)
        for index, domain in enumerate(self.domains):
            for placement in domain:
                if placement != plan[index]:
                    yield plan[:index] + (placement,) + plan[index + 1:]

    def evaluate(self, plan: Plan) -> float:
        """Return fitness; higher is better. The search wrapper counts calls."""
        return self.rollout(plan).fitness

    def rollout(self, plan: Plan, record: bool = False) -> Rollout:
        """Hard-drop each piece from wholly above the board until blocked.

        Occupied cells above the board do not collide. The piece descends until
        another downward step would hit a locked cell or the floor. If its lock
        position still has any cell above row zero, stop without adding it.
        Otherwise lock all four cells and remove completed rows simultaneously.

        With N pieces, Lmax=4N and Q=5*holes+aggregate_height+bumpiness:
            fitness = P + L/(Lmax+1) - Q/((Lmax+1)*(QUALITY_MAX+1)).
        Since Q <= 1380 and L <= 4N, this ranks plans lexicographically by pieces
        placed, then cleared lines, then lower board penalty. There is no random
        state, memoization, elapsed-time limit, or hidden early termination.
        """
        plan = self.validate_plan(plan)
        rows = list(self._initial_rows)
        lines = 0
        placed = 0
        topped_out = False
        frames: list[Frame] = []
        if record:
            frames.append(Frame(-1, "", None, self.board, 0, 0, False))
        for index, (piece, placement) in enumerate(zip(self.pieces, plan)):
            shape = _PLACEMENT_ROWS[piece][placement]
            y = -len(shape)
            while y + len(shape) < HEIGHT:
                next_y = y + 1
                if any(next_y + offset >= 0 and rows[next_y + offset] & mask
                       for offset, mask in enumerate(shape)):
                    break
                y = next_y
            if y < 0:
                topped_out = True
            else:
                for offset, mask in enumerate(shape):
                    rows[y + offset] |= mask
                remaining = [row for row in rows if row != FULL_ROW]
                cleared = HEIGHT - len(remaining)
                rows = [0] * cleared + remaining
                lines += cleared
                placed += 1
            if record:
                frames.append(Frame(index, piece, placement, _board_strings(rows),
                                    lines, placed, topped_out))
            if topped_out:
                break
        holes, aggregate_height, bumpiness = _board_metrics(rows)
        quality = 5 * holes + aggregate_height + bumpiness
        line_denominator = 4 * len(self.pieces) + 1
        fitness = placed + lines / line_denominator - quality / (line_denominator * (QUALITY_MAX + 1))
        return Rollout(fitness, lines, placed, holes, aggregate_height, bumpiness,
                       topped_out, _board_strings(rows), tuple(frames))
