"""Tests for the game model and supplied search components.

All pass before implementing student TODOs.
The genetic-driver tests replace unfinished operators with fixed mock outputs.
They verify the supplied loop, not crossover or mutation implementations.
"""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from pathlib import Path
import random
import unittest
from unittest.mock import patch

import local_search as search
from tetris import DOMAINS, HEIGHT, QUALITY_MAX, ROTATIONS, TetrisProblem, WIDTH


ASSIGNMENT_DIR = Path(__file__).resolve().parents[1]
LEVELS_DIR = ASSIGNMENT_DIR / "levels"
EMPTY_BOARD = ("." * WIDTH,) * HEIGHT


class TableProblem:
    """A finite supplied-helper fixture, with visible objective invocations."""

    def __init__(self, domains=((0, 1), (0, 1)), values=None):
        self.domains = domains
        self.values = values
        self.calls = []

    def evaluate(self, state):
        self.calls.append(state)
        return sum(state) if self.values is None else self.values[state]

    def neighbors(self, state):
        return tuple(state[:i] + (value,) + state[i + 1:]
                     for i, domain in enumerate(self.domains)
                     for value in domain if value != state[i])


class TestTetrisProblem(unittest.TestCase):
    def test_rotations_are_unique_normalized_and_have_four_cells(self):
        self.assertEqual({piece: len(domain) for piece, domain in DOMAINS.items()},
                         {"I": 17, "O": 9, "T": 34, "S": 17, "Z": 17, "J": 34, "L": 34})
        for piece, rotations in ROTATIONS.items():
            with self.subTest(piece=piece):
                self.assertEqual(len(rotations), len(set(rotations)))
                self.assertEqual(DOMAINS[piece], tuple(sorted(DOMAINS[piece])))
                for cells in rotations:
                    self.assertEqual(len(set(cells)), 4)
                    self.assertEqual(min(x for x, _ in cells), 0)
                    self.assertEqual(min(y for _, y in cells), 0)

    def test_every_single_piece_placement_drops_to_the_floor(self):
        for piece in ROTATIONS:
            problem = TetrisProblem("empty", EMPTY_BOARD, (piece,))
            for placement in problem.domains[0]:
                with self.subTest(piece=piece, placement=placement):
                    result = problem.rollout((placement,), record=True)
                    self.assertEqual(result.pieces_placed, 1)
                    self.assertFalse(result.topped_out)
                    self.assertEqual(sum(row.count("#") for row in result.final_board), 4)
                    self.assertIn("#", result.final_board[-1])
                    self.assertEqual(len(result.snapshots), 2)
                    self.assertEqual(result.snapshots[0].board, EMPTY_BOARD)
                    self.assertEqual(result.snapshots[-1].board, result.final_board)

    def test_simultaneous_two_and_four_line_clears(self):
        for name, piece, placement, expected in (
            ("clear", "O", (0, 4), 2), ("well", "I", (1, 5), 4),
        ):
            with self.subTest(level=name):
                level = TetrisProblem.from_file(LEVELS_DIR / f"{name}.json")
                problem = TetrisProblem(name, level.board, (piece,))
                result = problem.rollout((placement,), record=True)
                self.assertEqual(result.lines_cleared, expected)
                self.assertEqual(result.final_board, EMPTY_BOARD)
                self.assertEqual((result.holes, result.aggregate_height, result.bumpiness), (0, 0, 0))
                self.assertAlmostEqual(result.fitness, 1 + expected / 5)
                self.assertEqual(result.snapshots[-1].lines_cleared, expected)

    def test_holes_height_bumpiness_and_exact_fitness(self):
        board = EMPTY_BOARD[:-1] + ("#.........",)
        problem = TetrisProblem("overhang", board, ("I",))
        result = problem.rollout(((0, 0),))
        self.assertEqual(result.final_board[-2:], ("####......", "#........."))
        self.assertEqual((result.holes, result.aggregate_height, result.bumpiness), (3, 8, 2))
        self.assertEqual(result.lines_cleared, 0)
        self.assertAlmostEqual(result.fitness, 1 - 25 / (5 * (QUALITY_MAX + 1)))

    def test_topout_preserves_board_and_ignores_later_placements(self):
        board = ("##........",) + EMPTY_BOARD[1:]
        problem = TetrisProblem("blocked", board, ("O", "I"))
        first = problem.rollout(((0, 0), (0, 0)), record=True)
        second = problem.rollout(((0, 0), (1, 9)), record=True)
        self.assertEqual(first, second)
        self.assertTrue(first.topped_out)
        self.assertEqual(first.pieces_placed, 0)
        self.assertEqual(first.final_board, board)
        self.assertEqual(len(first.snapshots), 2)
        self.assertTrue(first.snapshots[-1].topped_out)

    def test_neighbor_order_and_exactly_one_gene_changes(self):
        problem = TetrisProblem("two pieces", EMPTY_BOARD, ("O", "I"))
        start = ((0, 4), (0, 3))
        neighbors = tuple(problem.neighbors(start))
        self.assertEqual(len(neighbors), 24)
        self.assertEqual(len(set(neighbors)), 24)
        self.assertEqual(neighbors[:2], (((0, 0), (0, 3)), ((0, 1), (0, 3))))
        self.assertEqual(neighbors[8], ((0, 4), (0, 0)))
        self.assertEqual(neighbors[-1], ((0, 4), (1, 9)))
        self.assertTrue(all(sum(a != b for a, b in zip(start, neighbor)) == 1
                            for neighbor in neighbors))

    def test_invalid_levels_and_plans_are_rejected_and_inputs_are_copied(self):
        data = {"name": "fixture", "board": list(EMPTY_BOARD), "pieces": ["O"],
                "initial_plan": [[0, 4]]}
        problem = TetrisProblem.from_dict(data)
        data["board"][0] = "#........."
        data["pieces"][0] = "I"
        data["initial_plan"][0][1] = 0
        self.assertEqual(problem.board, EMPTY_BOARD)
        self.assertEqual(problem.pieces, ("O",))
        self.assertEqual(problem.initial_state, ((0, 4),))
        with self.assertRaises(FrozenInstanceError):
            problem.name = "changed"
        for bad in ((), ((False, 0),), ((0, True),), ((0, -1),), ((1, 0),), ((0, 9),)):
            with self.subTest(plan=bad), self.assertRaises(ValueError):
                problem.evaluate(bad)
        for update in ({"board": ["#" * WIDTH] * HEIGHT}, {"board": ["."] * HEIGHT},
                       {"pieces": []}, {"pieces": ["o"]}, {"typo": 1}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                TetrisProblem.from_dict({"name": "bad", "board": EMPTY_BOARD,
                                         "pieces": ["O"], **update})

    def test_supplied_levels_load_and_reproduce_with_and_without_recording(self):
        for name in ("open", "clear", "well", "holes", "crowded"):
            with self.subTest(level=name):
                problem = TetrisProblem.from_file(LEVELS_DIR / f"{name}.json")
                self.assertEqual(len(problem.pieces), 12)
                first = problem.rollout(problem.initial_state)
                self.assertEqual(first, problem.rollout(problem.initial_state))
                recorded = problem.rollout(problem.initial_state, record=True)
                self.assertEqual(recorded.final_board, first.final_board)
                self.assertEqual(recorded.fitness, problem.evaluate(problem.initial_state))
                self.assertEqual(len(recorded.snapshots), 1 + first.pieces_placed + first.topped_out)
                self.assertEqual(first.snapshots, ())


class TestSuppliedSearchHelpers(unittest.TestCase):
    def test_random_scripts_are_independent_literal_and_exhaustible(self):
        rng = search.RandomSource(7, integers=[2, 0], uniforms=[0.25, 0.0])
        self.assertEqual(rng.index(3), 2)
        self.assertEqual(rng.uniform(), 0.25)
        self.assertEqual(rng.uniform(), 0.0)
        self.assertEqual(rng.index(1), 0)
        with self.assertRaises(StopIteration):
            rng.index(3)
        with self.assertRaises(StopIteration):
            rng.uniform()

    def test_random_scripts_reject_invalid_values_and_ranges(self):
        for value in (-1, True, 1.5, 3):
            with self.subTest(index=value), self.assertRaises(ValueError):
                search.RandomSource(integers=[value]).index(3)
        for value in (-0.1, 1.0, float("nan"), float("inf"), True):
            with self.subTest(uniform=value), self.assertRaises(ValueError):
                search.RandomSource(uniforms=[value]).uniform()
        for size in (0, -1, True):
            with self.subTest(size=size), self.assertRaises(ValueError):
                search.RandomSource().index(size)

    def test_repeated_evaluations_consume_budget_and_extra_calls_are_blocked(self):
        problem = TableProblem()
        context = search.SearchContext(problem, budget=2)
        first = context.evaluate((0, 1))
        second = context.evaluate((0, 1))
        self.assertEqual((first.order, second.order), (1, 2))
        self.assertEqual(context.remaining, 0)
        with self.assertRaises(search.BudgetExhausted):
            context.evaluate((1, 1))
        self.assertEqual(problem.calls, [(0, 1), (0, 1)])

    def test_first_best_tie_survives_and_results_copy_history_and_frames(self):
        context = search.SearchContext(TableProblem(), budget=5)
        first = context.evaluate((0, 1))
        tied = context.evaluate((1, 0))
        worse = context.evaluate((0, 0))
        context.record("fixture", (tied,), proposal=worse, accepted=False)
        result = context.finish("fixture")
        self.assertEqual(result.best, first)
        self.assertEqual([record.best_value for record in result.history], [1, 1, 1])
        self.assertEqual(result.frames[0].evaluation_count, 3)
        self.assertFalse(result.frames[0].accepted)
        context.evaluate((1, 1))
        context.record("later", (context.best,))
        self.assertEqual(len(result.history), 3)
        self.assertEqual(len(result.frames), 1)

    def test_context_rejects_invalid_domains_states_fitness_and_empty_results(self):
        for domains in ((), ((0, 0),), ((),), ([0, 1],), (([],),)):
            with self.subTest(domains=domains), self.assertRaises(ValueError):
                search.SearchContext(TableProblem(domains))
        context = search.SearchContext(TableProblem())
        for state in ([0, 1], (0,), (0, 2), ([], 0)):
            with self.subTest(state=state), self.assertRaises(ValueError):
                context.evaluate(state)
        with self.assertRaises(ValueError):
            context.finish("empty")
        for value in (float("nan"), float("inf"), True, 10 ** 1000):
            with self.subTest(fitness=value), self.assertRaises(ValueError):
                search.SearchContext(TableProblem(values={(0, 0): value})).evaluate((0, 0))

    def test_context_checks_neighbor_domain_uniqueness_and_one_gene_rule(self):
        problem = TableProblem()
        context = search.SearchContext(problem)
        self.assertEqual(context.neighbors((0, 0)), ((1, 0), (0, 1)))
        for neighbors in (((1, 0), (1, 0)), ((0, 0),), ((1, 1),), ((2, 0),)):
            with self.subTest(neighbors=neighbors), patch.object(problem, "neighbors", return_value=neighbors):
                with self.assertRaises(ValueError):
                    context.neighbors((0, 0))

    def test_rank_unique_uses_fitness_then_evaluation_order(self):
        a = search.ScoredCandidate((0,), 1, 1)
        b = search.ScoredCandidate((1,), 3, 2)
        c = search.ScoredCandidate((2,), 3, 3)
        later_b = search.ScoredCandidate((1,), 3, 4)
        self.assertEqual(search.rank_unique((c, later_b, a, b)), (b, c, a))
        self.assertEqual(search.unique_states(((1,), (0,), (1,), (2,))), ((1,), (0,), (2,)))

    def test_random_state_consumes_singleton_draws_but_supplied_start_does_not(self):
        problem = TableProblem(((7,), (0, 1)))
        rng = search.RandomSource(integers=[0, 1])
        context = search.SearchContext(problem, budget=2, rng=rng)
        self.assertEqual(context.initial((7, 0)).state, (7, 0))
        self.assertEqual(context.initial().state, (7, 1))
        with self.assertRaises(StopIteration):
            rng.index(1)

    def test_distinct_sampling_uses_mixed_radix_and_clamps_to_product_size(self):
        problem = TableProblem(((0, 1), (4, 5, 6)))
        rng = search.RandomSource(integers=[0] * 6)
        context = search.SearchContext(problem, rng=rng)
        result = context.sample_distinct(20)
        self.assertEqual(result, ((0, 4), (1, 6), (1, 5), (1, 4), (0, 6), (0, 5)))
        self.assertEqual(len(set(result)), 6)
        self.assertEqual(context.evaluation_count, 0)
        with self.assertRaises(StopIteration):
            rng.index(1)

    def test_distinct_sampling_handles_huge_products_empty_requests_and_singletons(self):
        problem = TableProblem(((0, 1),) * 100)
        rng = search.RandomSource(integers=[0, 0, 0])
        context = search.SearchContext(problem, rng=rng)
        self.assertEqual(context.total_states, 2 ** 100)
        self.assertEqual(context.sample_distinct(0), ())
        states = context.sample_distinct(3)
        self.assertEqual(states, ((0,) * 100, (1,) * 100, (1,) * 99 + (0,)))
        singleton_rng = search.RandomSource(integers=[0])
        singleton = search.SearchContext(TableProblem(((8,),)), rng=singleton_rng)
        self.assertEqual(singleton.sample_distinct(5), ((8,),))
        with self.assertRaises(StopIteration):
            singleton_rng.index(1)

    def test_random_neighbor_draws_only_when_a_neighbor_exists(self):
        rng = search.RandomSource(integers=[1])
        empty = search.SearchContext(TableProblem(((0,),)), rng=rng)
        self.assertIsNone(empty.random_neighbor((0,)))
        context = search.SearchContext(TableProblem(), rng=rng)
        self.assertEqual(context.random_neighbor((0, 0)), (0, 1))
        with self.assertRaises(StopIteration):
            rng.index(1)

    def test_cooling_formulas_and_domain(self):
        self.assertEqual(search.fast_cooling(0), 0.04)
        self.assertEqual(search.gradual_cooling(0), 0.04)
        self.assertAlmostEqual(search.fast_cooling(10), 0.04 * 0.95 ** 10)
        self.assertAlmostEqual(search.gradual_cooling(10), 0.04 * 0.995 ** 10)
        self.assertLess(search.fast_cooling(10), search.gradual_cooling(10))
        for step in (-1, True, 0.5):
            for schedule in (search.fast_cooling, search.gradual_cooling):
                with self.subTest(step=step, schedule=schedule), self.assertRaises(ValueError):
                    schedule(step)


class TestSuppliedAlgorithms(unittest.TestCase):
    def test_random_baseline_reproduces_without_touching_global_randomness(self):
        problem = TetrisProblem.from_file(LEVELS_DIR / "clear.json")
        before = random.getstate()
        first = search.random_search(problem, budget=9, seed=37)
        second = search.random_search(problem, budget=9, seed=37)
        self.assertEqual(first, second)
        self.assertEqual(random.getstate(), before)
        self.assertEqual(first.evaluation_count, 9)
        self.assertEqual(first.stop_reason, "budget")

    def test_random_baseline_records_every_sample_and_retains_first_best_tie(self):
        rng = search.RandomSource(integers=[0, 1, 1, 0, 0, 0])
        with patch.object(search, "RandomSource", return_value=rng):
            result = search.random_search(TableProblem(), budget=3, seed=1)
        self.assertEqual([record.state for record in result.history], [(0, 1), (1, 0), (0, 0)])
        self.assertEqual(result.best.state, (0, 1))
        self.assertEqual([frame.phase for frame in result.frames], ["sample"] * 3)
        self.assertEqual([frame.evaluation_count for frame in result.frames], [1, 2, 3])

    def test_genetic_driver_passes_scripted_choices_to_mock_operators(self):
        rng = search.RandomSource(
            integers=[0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0], uniforms=[0.1],
        )
        with patch.object(search, "RandomSource", return_value=rng), \
             patch.object(search, "crossover", return_value=(1, 0)) as cross, \
             patch.object(search, "mutate", return_value=(1, 1)) as mutate:
            result = search.genetic_algorithm(TableProblem(), budget=3,
                                               population_size=2, mutation_rate=1)
        cross.assert_called_once_with((1, 1), (0, 0), 1)
        mutate.assert_called_once_with((1, 0), 1, 1)
        self.assertEqual(result.best.order, 2)
        self.assertEqual(result.evaluation_count, 3)
        self.assertEqual([item.order for item in result.frames[-1].current], [2, 3])
        with self.assertRaises(StopIteration):
            rng.index(1)
        with self.assertRaises(StopIteration):
            rng.uniform()

    def test_genetic_driver_records_partial_generation_without_reevaluating_elite(self):
        rng = search.RandomSource(integers=[0, 0, 0, 1, 1, 1, 2, 2, 2, 0], uniforms=[0.9])
        problem = TableProblem(((0, 1),) * 3)
        with patch.object(search, "RandomSource", return_value=rng), \
             patch.object(search, "crossover", return_value=(1, 0, 0)) as cross, \
             patch.object(search, "mutate") as mutate:
            result = search.genetic_algorithm(problem, budget=4,
                                               population_size=3, mutation_rate=0)
        cross.assert_called_once_with((1, 1, 0), (0, 0, 0), 1)
        mutate.assert_not_called()
        self.assertEqual(problem.calls, [(0, 0, 0), (1, 1, 1), (1, 1, 0), (1, 0, 0)])
        self.assertEqual(result.best.state, (1, 1, 1))
        self.assertEqual(result.frames[-1].phase, "generation")
        self.assertEqual(len(result.frames[-1].current), 2)
        self.assertEqual(result.evaluation_count, 4)

    def test_genetic_driver_handles_one_state_and_skips_crossover_for_one_gene(self):
        with patch.object(search, "crossover") as cross, patch.object(search, "mutate") as mutate:
            singleton = search.genetic_algorithm(TableProblem(((7,),)), budget=8)
            one_gene = search.genetic_algorithm(TableProblem(((0, 1),)), budget=4,
                                                  population_size=2, mutation_rate=0)
        cross.assert_not_called()
        mutate.assert_not_called()
        self.assertEqual(singleton.evaluation_count, 1)
        self.assertEqual(singleton.stop_reason, "no_neighbors")
        self.assertEqual(one_gene.evaluation_count, 4)
        self.assertEqual(one_gene.stop_reason, "budget")

    def test_genetic_driver_rejects_invalid_settings(self):
        for options in ({"population_size": 1}, {"population_size": True}, {"budget": 0},
                        {"mutation_rate": -0.1}, {"mutation_rate": 1.1},
                        {"mutation_rate": float("nan")}, {"seed": -1}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                search.genetic_algorithm(TableProblem(), **options)


if __name__ == "__main__":
    unittest.main()
