"""Assignment 2 public infrastructure tests and independent student tests."""
