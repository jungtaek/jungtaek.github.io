"""Write independent tests for your six TODO functions here.

Add meaningful unittest methods to TestStudentLocalSearch. Use small finite
landscapes whose expected decisions, evaluation counts, and termination you
have checked by hand. Import implementations through the local_search module
so the evaluation tools can replace them when assessing your tests.

Do not copy the exact public cases. Public tests check supplied infrastructure;
your tests must exercise your search methods and genetic operators directly.
All tests must pass for a correct implementation. An empty test or unconditional
failure is not meaningful. This starter has no placeholder test method, so it
passes discovery before you write your first test that fails at a TODO.
"""

import unittest

import local_search


class TestStudentLocalSearch(unittest.TestCase):
    """Add your independently designed test_* methods to this class."""

    # TODO: Add meaningful tests for the student implementations.


if __name__ == "__main__":
    unittest.main()
