# Third-Party Notices

## Game selection and course adaptation

This assignment selects **Tetris**, listed as game 29 in the
[GameWorld game suite](https://gameworld-project.github.io/) and as
`29_tetris` in the
[GameWorld Games collection](https://github.com/gameworld-project/GameWorld-Games).

The supplied Python engine, level instances, optimization scaffolding, and
offline viewer are original course materials. They model a finite sequence of
tetrominoes on a 10-column, 20-row board using vertical hard drops, simultaneous
line clearing, and a course-specific fitness function. The assignment does
not use GameWorld's browser API or reproduce its benchmark tasks.

No source code, renderer, artwork, sound, dependency, or other asset from a
Tetris implementation or the GameWorld collection is included. The game name
identifies the selected game; it does not imply endorsement or affiliation.
