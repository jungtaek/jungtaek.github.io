"""Run one optimizer and embed its recorded results in an offline HTML replay."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
from typing import Any, Sequence

from tetris import TetrisProblem
from local_search import (
    SearchResult,
    fast_cooling,
    genetic_algorithm,
    gradual_cooling,
    hill_climbing,
    local_beam_search,
    random_restart_hill_climbing,
    random_search,
    simulated_annealing,
)


ASSIGNMENT_DIR = Path(__file__).resolve().parent
DEFAULT_LEVEL = ASSIGNMENT_DIR / "levels" / "clear.json"
DEFAULT_TEMPLATE = ASSIGNMENT_DIR / "viewer" / "template.html"
TRACE_PLACEHOLDER = "__TRACE_JSON__"
ALGORITHMS = ("random", "hill", "sideways", "restart", "annealing", "beam", "genetic")
MAX_REPLAY_PLANS = 64


def run_algorithm(
    problem: TetrisProblem,
    *,
    algorithm: str = "random",
    budget: int = 10000,
    seed: int = 7,
    sideways_limit: int = 3,
    width: int = 4,
    schedule: str = "gradual",
    population_size: int = 8,
    mutation_rate: float = 0.2,
) -> SearchResult:
    """Dispatch public CLI labels to the corresponding algorithm interface."""

    common = {"budget": budget, "seed": seed}
    if algorithm == "random":
        return random_search(problem, **common)
    if algorithm in ("hill", "sideways"):
        return hill_climbing(
            problem, **common,
            sideways_limit=sideways_limit if algorithm == "sideways" else 0,
        )
    if algorithm == "restart":
        return random_restart_hill_climbing(
            problem, **common, sideways_limit=sideways_limit,
        )
    if algorithm == "annealing":
        schedules = {"fast": fast_cooling, "gradual": gradual_cooling}
        if schedule not in schedules:
            raise ValueError(f"unknown cooling schedule: {schedule!r}")
        return simulated_annealing(problem, **common, schedule=schedules[schedule])
    if algorithm == "beam":
        return local_beam_search(problem, **common, width=width)
    if algorithm == "genetic":
        return genetic_algorithm(
            problem, **common, population_size=population_size,
            mutation_rate=mutation_rate,
        )
    raise ValueError(f"unknown algorithm: {algorithm!r}")


def trace_payload(
    problem: TetrisProblem,
    result: SearchResult,
    *,
    algorithm: str,
    seed: int,
    level: str,
    configuration: dict[str, Any],
) -> dict[str, Any]:
    """Serialize search records and selected plan rollouts, without rerunning search.

    The browser receives every objective evaluation and decision frame. Board
    replays are limited to at most 64 record-best candidates, including the final
    best, to bound output size. Replaying plans here does not consume the search
    budget or append search evaluations.
    """

    improvements = []
    best_value = float("-inf")
    for record in result.history:
        if record.value > best_value:
            improvements.append(record)
            best_value = record.value
    total_improvements = len(improvements)
    if len(improvements) > MAX_REPLAY_PLANS:
        indices = [
            i * (len(improvements) - 1) // (MAX_REPLAY_PLANS - 1)
            for i in range(MAX_REPLAY_PLANS)
        ]
        improvements = [improvements[i] for i in indices]

    plans = [
        {
            "evaluation": record.evaluation,
            "state": record.state,
            "value": record.value,
            "rollout": asdict(problem.rollout(record.state, record=True)),
        }
        for record in improvements
    ]
    # A valid result retains the first evaluated candidate on a fitness tie.
    # Still retain the algorithm's returned candidate for diagnosing a defect.
    if not plans or plans[-1]["state"] != result.best.state:
        if len(plans) == MAX_REPLAY_PLANS:
            plans.pop()
        plans.append({
            "evaluation": result.evaluation_count,
            "state": result.best.state,
            "value": result.best.value,
            "rollout": asdict(problem.rollout(result.best.state, record=True)),
        })
    return {
        "schema_version": 1,
        "algorithm": algorithm,
        "seed": seed,
        "level": level,
        "name": problem.name,
        "description": problem.description,
        "pieces": problem.pieces,
        "configuration": configuration,
        "result": asdict(result),
        "plans": plans,
        "total_improvements": total_improvements,
    }


def build_demo_html(payload: dict[str, Any], template: str) -> str:
    """Safely embed one JSON payload in the supplied self-contained template."""

    count = template.count(TRACE_PLACEHOLDER)
    if count != 1:
        raise ValueError(f"viewer template must contain one payload placeholder; found {count}")
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    encoded = encoded.replace("<", "\\u003c")
    encoded = encoded.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return template.replace(TRACE_PLACEHOLDER, encoded)


def write_demo(
    level_path: Path,
    output_path: Path,
    *,
    algorithm: str = "random",
    budget: int = 10000,
    seed: int = 7,
    sideways_limit: int = 3,
    width: int = 4,
    schedule: str = "gradual",
    population_size: int = 8,
    mutation_rate: float = 0.2,
    template_path: Path = DEFAULT_TEMPLATE,
) -> SearchResult:
    """Run a method, write its HTML replay, and return the recorded result."""

    if output_path.resolve() in (level_path.resolve(), template_path.resolve()):
        raise ValueError("output must not overwrite the level or viewer template")
    if output_path.suffix.lower() != ".html":
        raise ValueError("replay output must have the .html suffix")
    configuration = {
        "budget": budget,
        "sideways_limit": sideways_limit if algorithm != "hill" else 0,
        "width": width,
        "schedule": schedule,
        "population_size": population_size,
        "mutation_rate": mutation_rate,
    }
    problem = TetrisProblem.from_file(level_path)
    result = run_algorithm(problem, algorithm=algorithm, seed=seed, **configuration)
    payload = trace_payload(
        problem, result, algorithm=algorithm, seed=seed, level=level_path.name,
        configuration=configuration,
    )
    rendered = build_demo_html(payload, template_path.read_text(encoding="utf-8"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered, encoding="utf-8")
    return result


def add_search_arguments(parser: argparse.ArgumentParser) -> None:
    """Use the same search settings in the demo and experiment commands."""

    parser.add_argument("--budget", type=int, default=10000, help="objective-evaluation limit (default: 10000)")
    parser.add_argument("--sideways-limit", type=int, default=3, help="consecutive sideways limit for sideways/restart (default: 3)")
    parser.add_argument("--width", type=int, default=4, help="beam width (default: 4)")
    parser.add_argument("--schedule", choices=("fast", "gradual"), default="gradual", help="supplied annealing schedule (default: gradual)")
    parser.add_argument("--population-size", type=int, default=8, help="genetic population size (default: 8)")
    parser.add_argument("--mutation-rate", type=float, default=0.2, help="genetic mutation probability (default: 0.2)")


def search_options(args: argparse.Namespace) -> dict[str, Any]:
    """Extract and validate CLI search parameters before running a matrix."""

    if args.budget < 1:
        raise ValueError("budget must be positive")
    if args.sideways_limit < 0:
        raise ValueError("sideways limit must be nonnegative")
    if args.width < 1 or args.population_size < 2:
        raise ValueError("beam width must be positive and population size must be at least 2")
    if not 0 <= args.mutation_rate <= 1:
        raise ValueError("mutation rate must be in [0, 1]")
    return {name: getattr(args, name) for name in (
        "budget", "sideways_limit", "width", "schedule", "population_size", "mutation_rate",
    )}


def main(argv: Sequence[str] | None = None) -> int:
    """Command-line entry point; random search works in the untouched starter."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithm", choices=ALGORITHMS, default="random")
    parser.add_argument("--level", type=Path, default=DEFAULT_LEVEL, help="JSON Tetris instance")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", type=Path, default=Path("results.html"))
    add_search_arguments(parser)
    args = parser.parse_args(argv)
    try:
        options = search_options(args)
        result = write_demo(args.level, args.output, algorithm=args.algorithm, seed=args.seed, **options)
    except (NotImplementedError, OSError, TypeError, ValueError) as error:
        parser.exit(1, f"error: {error}\n")
    print(f"best fitness: {result.best.value:g}")
    print(f"evaluations: {result.evaluation_count}/{args.budget}")
    print(f"stop reason: {result.stop_reason}")
    print(f"wrote: {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
