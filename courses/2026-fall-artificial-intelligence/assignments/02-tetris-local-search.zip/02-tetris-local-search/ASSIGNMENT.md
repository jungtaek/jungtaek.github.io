# Assignment 2: Tetris Local Search

Implement and compare five local-search methods for a Tetris-inspired
placement problem, adapted from the
[GameWorld game suite](https://gameworld-project.github.io/). A fixed board
and known piece sequence let you optimize complete placement plans and
reproduce every decision. Implement four search algorithms and two genetic
operators using the supplied scaffolding; the browser replays Python's decisions.

This individual assignment is graded out of 100 points. See the course website
and Blackboard for its deadline and course-grade weight.

## Learning objectives

Learn to:

- represent optimization with complete candidates, a neighborhood, and a
  scalar objective;
- implement hill climbing, random-restart hill climbing, simulated annealing,
  and local beam search;
- implement crossover and mutation within a supplied genetic algorithm;
- explain plateaus, local optima, cooling, and population diversity;
- distinguish shared beam selection from independent hill-climbing runs;
- reproduce randomized runs through a precise random-call protocol; and
- design independent tests and compare methods under equal evaluation limits.

## Start here

1. Read this file completely.
2. Complete the pre-run traces before implementing a TODO.
3. Run `python -m unittest tests.test_public -v` to check the supplied game
   model and search scaffolding.
4. Generate and open the random-sampling browser replay.
5. Add a numerical test in `tests/test_student.py` that reaches a TODO;
   record its initial `NotImplementedError`.
6. Implement hill climbing and random restarts, then simulated annealing,
   local beam search, crossover, and mutation.
7. Finish independent tests, inspect replays, run experiments, review
   submission files, and complete the report.

All six TODOs initially raise `NotImplementedError`, yet the public suite
passes. Neither those tests nor an empty student suite establish correctness.
Implementing both operators makes the supplied genetic loop usable.

## Supplied and student work

The starter supplies:

- `tetris.py`: immutable plans and game state, piece domains, neighbors,
  simulation, fitness, and level loading;
- `local_search.py`: shared interfaces, deterministic random helpers,
  evaluation accounting, ranking, results and traces, random sampling,
  cooling schedules, and the complete genetic loop;
- `demo.py` and `viewer/template.html`: a self-contained offline replay;
- `run_experiments.py` and `viewer/experiments.html`: individual replays,
  a CSV summary, and an HTML comparison;
- five levels: open board, line-clear opportunity, narrow well, holes,
  and crowded board;
- public tests, report template, AI-use declaration, and third-party notices.

Implement these `local_search.py` functions without changing names or parameters:

```python
hill_climbing(problem, *, budget=10000, seed=0, sideways_limit=0, start=None)
random_restart_hill_climbing(problem, *, budget=10000, seed=0, sideways_limit=0)
simulated_annealing(problem, *, budget=10000, seed=0,
                    schedule=gradual_cooling, start=None)
local_beam_search(problem, *, budget=10000, seed=0, width=4)
crossover(parent_a, parent_b, cut)
mutate(state, index, replacement)
```

You may add private helpers to `local_search.py`; keep supplied functions,
types, constants, and public interfaces unchanged. Do not modify `tetris.py`,
the random baseline, genetic loop, cooling or random helpers, demo, experiment
runner, viewer, levels, or public tests. Add independent tests only to
`tests/test_student.py`.

Use Python 3.10 or newer and only the standard library, with no packaged
optimizer or other implementation of the required algorithms. Genetic points
assess your operators, not the supplied initialization, selection, or loop.

## Complete placement plans

Each supplied level has a 10-column, 20-row board and a fixed sequence of
12 tetrominoes. Rows run top to bottom, using `.` for empty and `#` for occupied
cells; columns are 0–9. Initial boards contain no full row.

A candidate is an immutable tuple of genes: gene `i` is
`(rotation_index, column)` for piece `i`, where column is the normalized
shape's left edge. Each piece's domain lists every fitting horizontal
position for each unique orientation, ordered by increasing rotation index,
then increasing column.
Starting from the supplied orientations, the engine rotates clockwise,
normalizes to the upper-left corner, and removes duplicates. Use these
domains; pieces need not have four distinct rotations. Domains are independent
of the board, so a valid gene can still cause top-out.

Neighbors replace exactly one whole gene with each alternative in its domain,
visiting gene indices in increasing order, then canonical domain order, and
skipping the current value. For a square first piece:

```text
Current: ((0, 4), (1, 2), (0, 6), ...)
Neighbor:((0, 0), (1, 2), (0, 6), ...)
Neighbor:((0, 1), (1, 2), (0, 6), ...)
Neighbor:((0, 2), (1, 2), (0, 6), ...)
```

Continue through the remaining columns, then the second gene, and so on.
Each neighbor is a complete alternative plan, not a successive game move;
changing an early gene can affect every later landing. Plans remain distinct
even if their final boards match or top-out precedes their differing genes.

Evaluate each plan from the initial board, executing genes in sequence. Each
piece starts wholly above the board, drops vertically until blocked, locks,
and clears all full rows simultaneously. If any cell would lock above the
board, top-out ends the rollout without adding that piece; the plan retains
its remaining genes. There is no timed control, sideways sliding after the
drop, wall kicks, hold queue, or unknown future pieces.

## Supplied fitness

Maximize the supplied fitness. For `N` pieces, let `P` be pieces placed,
`L` rows cleared, and `Q` the board penalty:

```text
Q = 5 * holes + aggregate_height + bumpiness
F = P + L / (4 * N + 1) - Q / ((4 * N + 1) * 1381)
```

Measure metrics after the last successful placement and line clear. A hole
is an empty cell below an occupied cell in its column. Column height is the
distance from the bottom to the highest occupied cell, or zero for an empty
column. Aggregate height sums all ten heights; bumpiness sums absolute
differences between adjacent heights.

Since `0 <= Q <= 1380` and at most `4 * N` rows can clear, fitness prioritizes
pieces placed, then rows cleared, then lower penalty. Stopping one piece
earlier for a tidier board cannot improve fitness. Keep this fitness unchanged
and report its components to interpret small differences.

## Required pre-run traces

Complete these traces in `report/report.tex` before implementing a TODO.
The abstract landscapes isolate decisions from Tetris: higher fitness is
better, and listed successor order is canonical. Use only listed successors;
do not infer reverse edges or additional neighbors.

### Hill climbing and restarts

| State | Fitness | Ordered neighbors |
| --- | ---: | --- |
| S | 5 | A, B |
| A | 5 | C, D |
| B | 4 | none |
| C | 6 | E, F |
| D | 5 | none |
| E | 6 | none |
| F | 5 | none |
| R | 7 | none |

Start at S with ample budget; trace hill climbing with `sideways_limit=0`
and `sideways_limit=1`. For each complete scan, show evaluated neighbors,
the move or stopping reason, consecutive sideways count, current state,
and best state encountered. Explain the reset after strict improvement.
Then trace the first two completed restart episodes, starting at S and R
in that order, with `sideways_limit=1`. Show the best retained across episodes;
the algorithm continues restarting afterward while the shared budget permits.

### Simulated annealing

Start at fitness 5 with these four prescribed proposals and temperatures.
Uniform draws are supplied only for worsening proposals; nonworsening
proposals consume none.

| Step | Proposed fitness | Temperature | Uniform draw if needed |
| ---: | ---: | ---: | ---: |
| 0 | 4 | 2 | 0.80 |
| 1 | 6 | 1 | none |
| 2 | 5 | 0.5 | 0.10 |
| 3 | 4 | 0.25 | 0.50 |

For each step, show the fitness difference, acceptance probability when
needed, decision, current fitness, and best fitness so far. Apply the
maximization rule below; do not replace current with best before the next
proposal.

### Beam selection and genetic operators

A width-two beam has parents A with fitness 8 and B with fitness 7.
A's successors have fitness 12 and 11; B's have fitness 10 and 9. All four
are distinct. Identify the next beam and compare it with taking each parent's
best neighbor independently. Explain whether beam search must call
`hill_climbing` and what additional rules must match for width one to behave
like hill climbing.

For four square pieces, trace `crossover(parent_a, parent_b, 2)`, then mutate
the child's gene at index 1 to `(0, 8)`:

```text
parent_a = ((0, 0), (0, 2), (0, 4), (0, 6))
parent_b = ((0, 1), (0, 3), (0, 5), (0, 7))
```

Give the child after each operation, identify unchanged genes, and explain
why exchanging whole genes at matching positions preserves domain validity.

## Shared search contract

Use the supplied interfaces in `local_search.py`. A problem exposes `domains`,
`neighbors(state)`, and `evaluate(state)`. Domains form a nonempty tuple of
nonempty tuples of distinct hashable genes. Candidates are tuples with one
allowed gene per domain; neighbors are distinct valid candidates changing
exactly one gene. Instructor tests may use tiny deterministic landscapes,
so search algorithms must not inspect Tetris board internals.

`SearchContext` supplies `initial`, `evaluate`, `neighbors`, `random_state`,
`random_neighbor`, `sample_distinct`, `record`, and `finish`. It validates
states and finite real fitness, rejecting Boolean objective values. Use its
`remaining`, `total_states`, and `rng` rather than separate accounting or
random helpers.

Each optimizer uses one context, private random source, and positive integer
evaluation budget. Every objective call costs one unit, including starts,
restarts, rejected proposals, repeated candidates, and genetic offspring;
memoization must not discount calls. Reusing evaluated parent scores or
ranking evaluated records costs nothing.

Use supplied validation helpers and raise `ValueError` for invalid parameters
or malformed input. Seeds and sideways limits are nonnegative integers;
beam width is a positive integer. Booleans are not integers. Schedules must
be callable and return finite, nonnegative real temperatures, excluding
Booleans. Explicit starts must satisfy the domains. Genetic operators enforce
their docstrings' tuple, integer, and hashability requirements; the supplied
loop enforces per-gene domain compatibility.

Return the best of **all evaluated candidates**, including rejected proposals
and discarded candidates. Keep the earliest evaluated best on equal fitness.
Supplied ranking orders by descending fitness, then evaluation order;
`rank_unique` also deduplicates by state. Equal fitness does not imply equal
states.

Hill climbing and beam search reserve budget for a complete neighborhood or
successor pool before evaluating any of it. If it cannot fit, stop with
`budget`, leaving unused allowance unspent so canonical order cannot favor
an evaluated prefix. Report actual evaluations and the common limit.
Annealing and random sampling evaluate individually; the supplied genetic
loop permits partial generations.

Terminate by these rules and evaluation limits, never elapsed time. Use the
supplied result type and trace helpers; history, current candidates, population
membership, counts, and stopping reasons must match Python's decisions.

### Results, frames, and stopping reasons

Return `context.finish(reason)`, containing the best scored candidate, actual
evaluation count, complete evaluation history, decision frames, and stopping
reason. `SearchContext.evaluate` automatically records objective history;
never add entries manually. `ScoredCandidate.order` is its one-based evaluation
number.

Call `context.record` for these events. After each decision, a frame's `current`
contains one scored candidate for individual methods or ranked population
survivors.

| Event | Phase | Additional fields |
| --- | --- | --- |
| First evaluated start or initial beam | `initial` | none |
| Each later evaluated restart | `restart` | none |
| Each completed hill-climbing scan | `hill_step` | best scanned neighbor as `proposal`; Boolean `accepted` |
| Each annealing proposal | `annealing_step` | evaluated `proposal`, Boolean `accepted`, and `temperature` |
| Each completed beam selection | `generation` | none |

Rejected hill or annealing proposals leave `current` unchanged; record hill
rejections before ending the episode. Add no frame for an empty neighborhood,
zero temperature, or unaffordable scan. The baseline uses `sample`; the
genetic loop uses `initial` and `generation`; operators record no frames.

Use these exact stopping reasons:

- `budget`: allowance exhausted or insufficient for the next complete scan/pool;
- `no_neighbors`: empty neighborhood/pool;
- `local_optimum`: best hill neighbor strictly worse;
- `sideways_limit`: equal hill move blocked by the limit;
- `temperature`: annealing schedule returns zero.

Check exhausted budget before preparing another iteration, but first classify
and record any completed scan. A rejected scan retains `local_optimum` or
`sideways_limit` even if its last evaluation exhausted the budget. Restarts
resume after local episode stops when budget remains and return `budget`
when the shared allowance prevents further work.

### Hill climbing

Use the explicit `start` when given; otherwise sample with the context's
random-state helper. Evaluate it once. Each iteration generates the complete ordered
neighborhood; an empty one ends the episode. If the scan fits, evaluate every
neighbor once and use supplied ranking to select the best.

- Accept strict improvements; reset the consecutive sideways count to zero.
- Accept equal fitness only when the count is below `sideways_limit`, then
  increment it.
- Stop for a worse best neighbor or an equal move blocked by the limit.

Ranking ties never permit worsening moves. Do not maintain a global visited
set: bounded sideways moves and the budget control plateau cycling.

### Random-restart hill climbing

Run hill-climbing episodes from newly sampled candidates. After an empty
neighborhood, local optimum, or sideways limit, sample and evaluate another
start if budget remains. Repeated starts are allowed and cost evaluations.

Share the context, random source, budget, and best record across episodes;
reset only episode state and its sideways count. An unaffordable complete
scan stops the whole algorithm. Do not call public `hill_climbing` with a
fresh full budget or reinitialized seed per restart; a private episode helper
may be shared. On a singleton space, resample and evaluate the sole state
until budget exhaustion, unlike the supplied genetic loop's early
`no_neighbors` return.

### Simulated annealing

Initialize as for hill climbing, starting at step zero. Before each proposal,
obtain that step's supplied schedule temperature; stop at zero. The
random-neighbor helper chooses uniformly from the complete canonical
neighborhood; stop if empty.

Evaluate the proposal with `delta = proposed_fitness - current_fitness`.
Accept `delta >= 0` without a uniform draw. Otherwise draw exactly one uniform
`u` and accept only when:

```text
u < exp(delta / temperature)
```

Advance the step after every proposal, including rejections. Keep the best
evaluated candidate separate from current. Supplied schedules use
`T(step) = 0.04 * rate ** step`, with rates `0.95` (fast) and `0.995`
(gradual). Compare these schedules without implementing or tuning them for
the required comparison.

### Local beam search

Use the supplied distinct-state sampler to initialize
`min(width, number_of_possible_candidates, budget)` distinct candidates;
evaluate and rank them. Limited space or budget can shrink the beam.

Each generation visits parents in ranked order and neighbors in canonical order.
Pool successors, deduplicating by state in first-occurrence order. Evaluate
the complete pool if budget permits, rank it, and retain the best `width`
distinct candidates, or all if fewer exist. Stop for an empty pool or
insufficient budget.

Select successors only: do not automatically insert parents or stop for lack
of improvement. A parent generated as another parent's successor remains
eligible. Distinct plans producing the same board remain distinct candidates.

Hill climbing and beam search share neighborhood, evaluation, and ranking
utilities. **Beam search does not need to call hill climbing.** Width-one
behavior agrees only with matching acceptance, stopping, and tie-breaking.
Here, successor-only beam selection permits worsening moves; hill climbing
does not.

### Crossover and mutation

`crossover(parent_a, parent_b, cut)` returns one immutable child containing
`parent_a` before the cut and `parent_b` onward. Cut between whole genes with
`1 <= cut < len(parent_a)`; parents must have equal lengths of at least two.
Never split `(rotation, column)` pairs or modify parents.

`mutate(state, index, replacement)` returns a new immutable plan replacing
exactly one specified gene, leaving others unchanged. The supplied caller
chooses from that piece's domain, excluding its current gene. Neither operator
draws randomness, simulates, or evaluates fitness; follow their TODO
docstrings' validation contract.

The supplied genetic loop initializes a population, selects each parent through
a size-three tournament with replacement, chooses the cut, applies crossover,
and mutates with probability 0.2. It preserves one elite and evaluates offspring
until the generation or budget ends. Analyze the complete algorithm through
experiments; implement only its two deterministic operators.

## Deterministic random calls

A fixed seed is insufficient if implementations consume draws in different
orders. Use only the context's supplied random source, never Python's global
random state:

- Random starts draw one integer per gene in increasing index order,
  including singleton domains.
- Hill climbing makes no random choices after initialization; restarts draw
  only new starting candidates.
- Annealing draws one integer index into the complete ordered neighbor list,
  then one uniform draw only for a strictly worsening proposal.
- Beam initialization uses the supplied mixed-radix sampling helper without
  replacement; generations consume no randomness.
- Supplied genetic randomness comprises two parent tournaments, one cut for
  plans with at least two genes, and one mutation coin per child. A successful
  coin triggers a mutable-gene choice and replacement choice if a mutable gene
  exists. The loop bypasses crossover on one-gene test problems and stops on
  a singleton candidate space.

`RandomSource(integers=..., uniforms=...)` scripts contain literal index
results and uniform draws, not seeds; unexpected extra draws exhaust the
script and fail. In student tests, construct a fresh scripted instance before
using `unittest.mock.patch` on `local_search.RandomSource` to return it for a
search call. Check exact decisions, candidates, and evaluation counts on
small cases. Use floating-point tolerances for probabilities and reported
fitness, but the supplied comparison rules for search decisions. Reproduce
seeded runs with the same Python version and record it in the report.

## Your tests

Do not modify `tests/test_public.py`. Independent tests must collectively
cover all six required functions, including:

- strict improvement, rejection of worsening moves, tie-breaking, bounded
  sideways moves, and counter reset after improvement;
- shared restart budgets, best retention across episodes, and repeated starts;
- acceptance and rejection of worsening annealing proposals, no uniform draw
  for equal or better proposals, and best retention after a worse move;
- pooled beam selection with multiple survivors from one parent,
  deduplication, and successor-only behavior;
- both valid crossover boundary extremes, whole-gene preservation, mutation
  at a specified index, and unchanged parents;
- budget-one behavior, insufficient allowance for a full neighborhood or
  pool, empty neighborhoods, and representative trace/count fields; and
- reproducibility without reading or changing global random state.

Use small, independently checked landscapes and controlled random choices;
never derive expectations from the implementation under test. Tests earn
credit for defects distinguished, not quantity: examples include a reversed
annealing exponent, one neighbor per beam parent, lost best candidates,
exceeded shared budgets, missing sideways resets, modified parents, and
unexpected random draws.

Run the suites separately during development:

```bash
python -m unittest tests.test_public -v
python -m unittest tests.test_student -v
```

Instructor evaluation uses clean supplied files; changes to engine rules,
supplied loops, public tests, or helpers do not change the contract.
Correctness and analysis earn points; no method must outperform another on
every level or seed.

## Replays and experiments

The random baseline works immediately. From this assignment directory, run:

```bash
python demo.py --algorithm random --level levels/clear.json \
  --seed 7 --budget 10000 --output results.html
```

The self-contained HTML replay needs no server or Internet. It shows recorded
optimization history and plays a selected complete candidate's placements.
Connect placement outcomes with optimizer decisions using the best-plan
selector, piece step/play/speed controls, search-decision slider, and fitness
history chart. The viewer retains at most 64 representative best-plan replays
and all objective-history records; the Python result remains authoritative.

Labels are `random`, `hill`, `sideways`, `restart`, `annealing`, `beam`, and
`genetic`: five required methods, plus the baseline and sideways hill-climbing
variant. `hill` is always strict; `sideways` uses `--sideways-limit`.
`demo.py` runs one annealing schedule, defaulting to gradual cooling.
See `python demo.py --help` for settings.

After implementing the TODOs, run the complete experiment matrix:

```bash
python run_experiments.py
```

See `python run_experiments.py --help` for settings. Defaults cover all seven
labels and five supplied levels, seeds 0, 1, and 2, and an evaluation limit of
10000. `sideways` and `restart` use a sideways limit of three, covering the
required strict-versus-sideways comparison. Omitting `--schedule` runs
fast and gradual annealing, with each other label run once per level
and seed: eight configurations yield 120 runs, including 30 annealing runs.
Use `--schedule fast` or `--schedule gradual` to select one annealing schedule.

Compare all five methods and random sampling across all five levels with
these identical limits and seeds. Hold other settings fixed when comparing
the two cooling schedules. Unimplemented methods receive `todo` labels;
those rows are not successful runs.

Record best fitness, pieces placed, lines cleared, actual evaluations, and
stopping reason. Summarize means and sample standard deviations across seeds;
inspect best-fitness histories and population frames. Limits are upper
bounds: early stopping can use fewer evaluations, so equal limits do not
imply equal work.

In the report, aggregate across seeds by level and method, separating the
annealing schedules; explain specific decisions through selected runs without
reproducing every run. Keep the complete CSV for your own verification.

The output directory contains individual replays, `summary.csv`, and
`index.html`. Annealing replay filenames include the schedule, such as
`replays/clear/annealing-gradual-seed-0.html` and
`replays/clear/annealing-fast-seed-0.html`.

The index provides a progress chart with a level selector, an overall
comparison table, and an always-visible table of runs and replay links.
Curves average best fitness across completed seeds, carrying early-stopping
runs' final best through their evaluation limit. The legend reports final
mean fitness and sample standard deviation for the selected level. The
overall table averages seeds within each level, then equally weights
available level means. Check coverage counts when comparing incomplete runs;
actual evaluations measure work performed.

Rebuild HTML from existing CSV and replays with their saved settings,
without rerunning algorithms:

```bash
python run_experiments.py --refresh --output-dir experiment_results
```

The browser neither executes nor grades the optimizer. Do not submit
generated replay or experiment output.

## Verification

Run both suites and the complete experiment matrix. Review every failure;
inspect search history and placement replays for at least the well, holes,
and crowded levels. Repeat a run with identical inputs to verify identical
results and traces.

After tests pass, read `local_search.py` and `tests/test_student.py`, tracing
at least one path through every TODO against the selection, acceptance,
stopping, random-call, budget, and trace rules. Review every assignment-folder
file, remove unintended files, and compare the exact planned upload with the
submission list.

In `report/report.tex`, record commands and outcomes, replay observations,
source/file-review outcomes, Python version, dependencies, one input
assumption, and one known limitation. Complete exactly one `AI_USE.md`
declaration and preserve reasonably available AI-use records as directed there.

## Report

Complete `report/report.tex` and compile `report/report.pdf` using the supplied
NeurIPS 2026 style without changing fonts, margins, or spacing. The eight-page
maximum includes traces, figures, tables, and references. Include:

1. the required pre-run traces;
2. the candidate model, fitness priorities, and decisive algorithm choices;
3. comparisons across methods, levels, and seeds, with actual evaluation use;
4. strict versus sideways/restart behavior and fast versus gradual cooling;
5. pooled beam selection, population diversity, and crossover limitations;
6. an independent student test and the plausible defect it detects;
7. commands, observed results, and source/submission review outcomes; and
8. the Python version, dependencies, one assumption, and one limitation.

Compile from `report/` so LaTeX finds the adjacent style:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Submission

Preserve these paths in the Blackboard submission:

```text
local_search.py
tests/test_student.py
report/report.tex
report/report.pdf
AI_USE.md
```

Include `ai-records/` and related verification records when reasonably
available. Exclude generated experiment output, other generated HTML, caches,
virtual environments, credentials, and unchanged supplied files not listed above.

## 100-point rubric

| Component | Points |
| --- | ---: |
| Hill climbing, including bounded sideways moves | 15 |
| Random-restart hill climbing | 10 |
| Simulated annealing | 15 |
| Local beam search | 10 |
| Crossover and mutation | 15 |
| Student-written tests | 20 |
| Report and independent verification | 15 |
| **Total** | **100** |
