"""Manual vector and matrix products for Assignment 0.

Implement the four product functions below using ordinary Python loops or
comprehensions.  Do not import a numerical library or use a built-in matrix
multiplication operation.
"""

Number = int | float
Vector = list[Number]
Matrix = list[list[Number]]


def _validate_vector(vector: Vector, name: str) -> int:
    """Validate the list representation of a vector and return its length.

    This helper checks structure only.  The public contract assumes that each
    element is an ``int`` or ``float`` as described by ``Number``.
    """

    if not isinstance(vector, list) or not vector:
        raise ValueError(f"{name} must be a nonempty list")
    return len(vector)


def _matrix_shape(matrix: Matrix, name: str) -> tuple[int, int]:
    """Validate a nonempty rectangular list-of-lists and return its shape."""

    if not isinstance(matrix, list) or not matrix:
        raise ValueError(f"{name} must be a nonempty list of rows")

    first_row = matrix[0]
    if not isinstance(first_row, list) or not first_row:
        raise ValueError(f"{name} must contain nonempty rows")

    column_count = len(first_row)
    for row in matrix:
        if not isinstance(row, list) or len(row) != column_count:
            raise ValueError(f"{name} must be rectangular with nonempty rows")

    return len(matrix), column_count


def inner_product(left: Vector, right: Vector) -> Number:
    """Return the inner product of two equal-length vectors.

    For vectors of length ``n``, compute
    ``sum(left[k] * right[k] for k in range(n))``.  Both vectors must be
    nonempty and have the same length; otherwise, raise ``ValueError``.  Do
    not mutate either input.
    """

    left_length = _validate_vector(left, "left")
    right_length = _validate_vector(right, "right")
    if left_length != right_length:
        raise ValueError("inner-product vectors must have the same length")

    # TODO: Compute and return the inner product manually.
    raise NotImplementedError("TODO: implement inner_product")


def outer_product(left: Vector, right: Vector) -> Matrix:
    """Return the outer product of two vectors.

    If ``left`` has length ``m`` and ``right`` has length ``n``, return the
    ``m``-by-``n`` matrix whose entry ``[i][j]`` is
    ``left[i] * right[j]``.  Both vectors must be nonempty.  Do not mutate the
    inputs.  Return a new matrix with independently allocated row lists.
    """

    _validate_vector(left, "left")
    _validate_vector(right, "right")

    # TODO: Compute and return the outer product manually.
    raise NotImplementedError("TODO: implement outer_product")


def hadamard_product(left: Matrix, right: Matrix) -> Matrix:
    """Return the elementwise product of two matrices with equal shapes.

    For matching ``m``-by-``n`` inputs, output entry ``[i][j]`` is
    ``left[i][j] * right[i][j]``.  Inputs must be nonempty rectangular
    matrices with exactly the same shape; otherwise, raise ``ValueError``.
    Do not mutate the inputs.  Return a new matrix with independently
    allocated row lists.
    """

    left_shape = _matrix_shape(left, "left")
    right_shape = _matrix_shape(right, "right")
    if left_shape != right_shape:
        raise ValueError("Hadamard-product matrices must have the same shape")

    # TODO: Compute and return the Hadamard product manually.
    raise NotImplementedError("TODO: implement hadamard_product")


def matrix_product(left: Matrix, right: Matrix) -> Matrix:
    """Return the conventional matrix product of two compatible matrices.

    If ``left`` has shape ``m``-by-``n`` and ``right`` has shape
    ``n``-by-``p``, return the ``m``-by-``p`` matrix whose entry ``[i][j]``
    is ``sum(left[i][k] * right[k][j] for k in range(n))``.  Inputs must be
    nonempty rectangular matrices, and their shared dimensions must agree;
    otherwise, raise ``ValueError``.  Do not mutate the inputs.  Return a new
    matrix with independently allocated row lists.
    """

    _, left_columns = _matrix_shape(left, "left")
    right_rows, _ = _matrix_shape(right, "right")
    if left_columns != right_rows:
        raise ValueError("matrix-product inner dimensions must agree")

    # TODO: Compute and return the matrix product manually.
    raise NotImplementedError("TODO: implement matrix_product")
