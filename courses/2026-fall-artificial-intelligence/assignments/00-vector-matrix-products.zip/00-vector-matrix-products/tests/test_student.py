"""Write independent tests for your product implementations here.

Add meaningful ``unittest`` methods to ``TestStudentProducts``.  Your tests
must not copy the numerical cases in ``test_public.py``.  Include at least one
independent test for each product and tests that would expose plausible bugs,
such as an incorrect output shape, a wrong index, input mutation, shared output
rows, or missing ``ValueError`` validation.

All tests must pass for a correct implementation.  A method that contains only
``pass`` or an unconditional failing assertion is not a meaningful test.  The
starter intentionally contains no placeholder test method so that this file
does not add an artificial failure before you begin.
"""

import unittest

import products


class TestStudentProducts(unittest.TestCase):
    """Add your independently designed ``test_*`` methods to this class."""

    # TODO: Add meaningful independent tests here.  Use functions through the
    # imported ``products`` module so the evaluation tools can assess your tests.


if __name__ == "__main__":
    unittest.main()
