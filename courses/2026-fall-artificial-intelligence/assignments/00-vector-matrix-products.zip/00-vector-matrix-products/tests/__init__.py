"""Tests for Assignment 0."""
