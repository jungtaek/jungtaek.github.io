"""Transparent public tests for the four required products."""

import unittest

import products


class TestPublicProducts(unittest.TestCase):
    def test_inner_product(self) -> None:
        left = [2, -1, 3]
        right = [4, 0, -2]

        self.assertEqual(products.inner_product(left, right), 2)
        self.assertEqual(left, [2, -1, 3])
        self.assertEqual(right, [4, 0, -2])

    def test_outer_product(self) -> None:
        left = [2, -1, 3]
        right = [4, 0]

        result = products.outer_product(left, right)

        self.assertEqual(result, [[8, 0], [-4, 0], [12, 0]])
        self.assertEqual(left, [2, -1, 3])
        self.assertEqual(right, [4, 0])
        self.assertIsNot(result[0], result[1])

    def test_hadamard_product(self) -> None:
        left = [[1, 2, -1], [0, 3, 4]]
        right = [[2, -3, 5], [7, 1, -2]]

        result = products.hadamard_product(left, right)

        self.assertEqual(result, [[2, -6, -5], [0, 3, -8]])
        self.assertEqual(left, [[1, 2, -1], [0, 3, 4]])
        self.assertEqual(right, [[2, -3, 5], [7, 1, -2]])
        self.assertIsNot(result[0], result[1])

    def test_matrix_product(self) -> None:
        left = [[1, 2, -1], [0, 3, 4]]
        right = [[2, 1], [-1, 0], [3, -2]]

        result = products.matrix_product(left, right)

        self.assertEqual(result, [[-3, 3], [9, -8]])
        self.assertEqual(left, [[1, 2, -1], [0, 3, 4]])
        self.assertEqual(right, [[2, 1], [-1, 0], [3, -2]])
        self.assertIsNot(result[0], result[1])

    def test_invalid_or_incompatible_shapes_raise_value_error(self) -> None:
        with self.subTest(operation="inner product"):
            with self.assertRaises(ValueError):
                products.inner_product([1, 2], [3])

        with self.subTest(operation="outer product"):
            with self.assertRaises(ValueError):
                products.outer_product([], [1])

        with self.subTest(operation="Hadamard product"):
            with self.assertRaises(ValueError):
                products.hadamard_product([[1, 2]], [[1], [2]])

        with self.subTest(operation="matrix product"):
            with self.assertRaises(ValueError):
                products.matrix_product([[1, 2]], [[1, 2]])


if __name__ == "__main__":
    unittest.main()
