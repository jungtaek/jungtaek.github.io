# AI Coding Tool Use

Complete exactly one of the two declarations below and delete the declaration
that does not apply. Replace every bracketed prompt before submission.

## Declaration A: No AI Coding Tool Used

I did not use an AI coding tool for this assignment.

## Declaration B: AI Coding Tool Used

### Tool and Model

- Tool: [tool name]
- Model: [model name as displayed by the tool, or explain why unavailable]
- Date or dates used: [date or date range]

### Purpose and Material Influence

- Purpose of each use: [what you asked the tool to help with]
- Materially influenced files: [paths, or `None` with a brief explanation]

### Available Records

List the paths to all reasonably available, user-visible records related to
this assignment. Include exportable unsuccessful or discarded sessions.

- Chats, prompts, follow-ups, and responses: [paths, or `None available`]
- Supplied context, attachments, and accepted suggestions: [paths, or `None`]
- Approvals, errors, retries, and discarded sessions: [paths, or `None`]

If an otherwise expected record is unavailable, identify it and explain why.
Do not reconstruct hidden events or keystroke-level activity.

- Unavailable record and reason: [record and reason, or `None`]

### Coding Harness or Agent Evidence, If Applicable

- Available action or command logs: [paths, or `Not applicable`]
- Relevant configuration and permissions: [details or paths, or `Not applicable`]
- Verification results: [paths, or `Not applicable`]

### Change and Verification Summary

- Available tool change summary or patch review: [paths or description, or
  `None available`]
- Source and submission-file review: [what you reviewed and any unintended file
  you removed]
- Checks run and results: [commands and outcomes]
- Dependencies and known limitations: [details, or `None identified`]

## Submission Reminder

Tool change summaries do not replace your own review of the source, tests,
assignment folder, and planned Blackboard submission files. Preserve
reasonably available AI-use records, but do not submit credentials or protected
data. If a required record contains a sensitive value, replace only that value
with `[REDACTED: category]` and leave the rest of the record unchanged.
