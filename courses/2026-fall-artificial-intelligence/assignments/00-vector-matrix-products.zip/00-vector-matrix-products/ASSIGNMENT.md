# Assignment 0: Vector and Matrix Products

***You do not need to submit this assignment. The description below shows how
future assignments and their submissions will be structured.***

In this assignment, you will implement four basic linear-algebra operations
from their definitions and design tests that check their mathematical and
programming requirements.

Assignment 0 is a practice assignment evaluated on a 100-point feedback rubric.
Its feedback score contributes 0% to your course grade. It is not one of the
five assignments included in the 50% Assignments component. Complete it
individually and submit it through Blackboard by the date shown there.

## Learning objectives

After completing this assignment, you should be able to:

- distinguish inner, outer, Hadamard, and matrix products by their dimensions
  and definitions;
- trace the indices in rectangular matrix multiplication;
- translate a mathematical definition into a small Python implementation;
- design tests that expose plausible implementation defects;
- verify that inputs are not mutated and that outputs do not contain aliased
  rows;
  and
- explain and verify the behavior of your implementation.

## Start here

1. Read this file completely.
2. Before implementing the functions, complete the hand calculations requested
   in the report template.
3. Run `python -m unittest tests.test_public -v` to establish the starter
   state.
4. Add at least one numerical test to `tests/test_student.py` that reaches a
   TODO operation. Run `python -m unittest tests.test_student -v` and record
   its initial `NotImplementedError`.
5. Implement the four functions in `products.py`.
6. Add the rest of your independent tests, run both test suites, review your
   implementation and assignment files, and complete the report.

The starter functions raise `NotImplementedError`, so public tests are expected
to fail at the beginning.

## Mathematical definitions

All indices below are zero-based in the Python implementation.

### Inner product

For vectors `x` and `y` of the same length `n`, the inner product is the scalar

```text
inner_product(x, y) = sum(x[k] * y[k] for k = 0, ..., n - 1).
```

For example, the inner product of `[2, -1, 3]` and `[4, 5, -2]` is `-3`.

### Outer product

For a vector `x` of length `m` and a vector `y` of length `n`, the outer product
is an `m`-by-`n` matrix with entries

```text
outer_product(x, y)[i][j] = x[i] * y[j].
```

For example:

```text
outer_product([2, -1], [3, 0, 4])
    = [[ 6, 0,  8],
       [-3, 0, -4]]
```

### Hadamard product

For matrices `A` and `B` with the same shape `m`-by-`n`, the Hadamard product
is the elementwise product

```text
hadamard_product(A, B)[i][j] = A[i][j] * B[i][j].
```

Hadamard multiplication does not broadcast rows, columns, or scalar values.

### Matrix product

If `A` has shape `m`-by-`n` and `B` has shape `n`-by-`p`, their matrix product
has shape `m`-by-`p`. Its entries are

```text
matrix_product(A, B)[i][j]
    = sum(A[i][k] * B[k][j] for k = 0, ..., n - 1).
```

Thus, each output entry is the inner product of one row of `A` and one column
of `B`. A second useful interpretation is the outer-product decomposition

```text
A * B = sum(outer_product(column(A, k), row(B, k)) for k = 0, ..., n - 1).
```

The sum in this expression is an elementwise sum of matrices.

## Required pre-run calculations

Before implementing the functions, calculate all four results below and record
your work in `report/report.tex`:

1. `inner_product([1, -2, 4], [-3, 5, 2])`;
2. `outer_product([1, -2], [3, 4, -1])`;
3. `hadamard_product([[1, -2], [3, 0]], [[4, 5], [-1, 2]])`; and
4. the matrix product

   ```text
   [[2, -1, 0],       [[ 1,  2],
    [3,  1, 4]]   *    [-2,  3],
                       [ 0, -1]].
   ```

For the matrix product, state both output dimensions and expand the scalar sum
for output entry `[1][1]`. Your report is evaluated on a specific,
mathematically coherent trace, not merely on whether the final values are
correct.

## Programming contract

Implement these four public functions without changing their names or
parameters:

```python
inner_product(left, right)
outer_product(left, right)
hadamard_product(left, right)
matrix_product(left, right)
```

The following requirements are part of the contract:

- Use Python 3.10 or newer.
- A vector is a nonempty Python `list` whose entries are ordinary `int` or
  `float` values.
- A matrix is a nonempty Python `list` of nonempty, equal-length row lists.
- Element-type validation is not required, but the supplied structural helpers
  must still be used or respected.
- Invalid empty or ragged structures raise `ValueError`.
- Incompatible vector lengths or matrix dimensions raise `ValueError`.
- None of the functions may mutate either input.
- Every matrix result must be newly allocated, with independently allocated
  rows.
- Do not use NumPy, SciPy, another linear-algebra package, the matrix `@`
  operator, or a library `dot`, `matmul`, or `einsum` operation.
- Do not add imports or dependencies to `products.py`.

You may use ordinary loops, comprehensions, indexing, `len`, `range`, `sum`,
and small helper functions. Your implementation should work for rectangular
matrices; testing only square matrices is insufficient.

## Your tests

Do not modify `tests/test_public.py`. Add your work to
`tests/test_student.py`. Your tests must collectively check:

- one nontrivial numerical result for each of the four operations;
- at least one genuinely rectangular matrix product;
- negative and zero entries;
- required `ValueError` behavior for incompatible inputs;
- preservation of the original inputs;
- independence of returned matrix rows; and
- at least one relationship between two operations or one mathematical
  identity.

These are collective suite requirements. You need one independent numerical
case for every operation, while the negative/zero, validation, immutability,
row-independence, rectangular, and cross-operation requirements must each
appear at least once where applicable.

Run the two suites separately while developing:

```bash
python -m unittest tests.test_public -v
python -m unittest tests.test_student -v
```

Tests are evaluated for the defects they can distinguish, not merely their
number. The instructor's evaluation system will run your tests against more
than one correct implementation and against several small, intentionally
defective implementations. A useful test must accept the correct
implementations and reject at least one plausible defect for the right reason.

Examples of relevant defect categories include a reversed outer-product
orientation, a loop bound that works only for square matrices, an accumulator
that is not reset, silent length truncation, input mutation, and shared output
rows. Do not write tests that depend on private helper names or a particular
correct loop structure.

The 20 feedback points for student-written tests are divided as follows:

- 4 points: deterministic tests that run and pass against correct
  implementations;
- 6 points: complete coverage of the published test categories above; and
- 10 points: mutation effectiveness, calculated proportionally from the
  published defect categories represented by the instructor mutants.

Passing both local suites does not establish complete category coverage or the
hidden mutation score.

## Verification

From this assignment directory, run both test suites:

```bash
python -m unittest tests.test_public -v
python -m unittest tests.test_student -v
```

Review every failure and confirm that both suites pass before submission.

After the tests pass, read the completed `products.py` and
`tests/test_student.py`. Trace representative inputs through the code and
compare the resulting outputs with your hand calculations, the mathematical
definitions, and the programming contract. In particular, check the dimension
tests, loop bounds, input preservation, and allocation of independent result
rows.

Review every file in the assignment folder. Remove files you did not intend to
create, then compare the exact files you plan to upload with the required
submission list below. Confirm that every required file is present and that no
cache, build artifact, or unrelated file is selected. Record the commands and
results, the source and file-review outcomes, one input assumption, and one
known limitation in `report/report.tex`.

Instructor evaluation uses a clean copy of `tests/test_public.py`. Hidden tests
vary only the values and cases described in this specification; they do not
introduce new requirements. Modifying the supplied public tests does not change
the instructor evaluation.

## Report

Complete `report/report.tex` and compile `report/report.pdf` with the supplied
NeurIPS 2026 style. Do not change its fonts, margins, or spacing. The
report may use at most four pages and must include:

1. dimensions and the requested hand calculations;
2. an explanation of the `i`, `j`, and `k` indices in matrix multiplication;
3. the multiplication count for each operation in terms of its input sizes;
4. one student-written test and the plausible defect it detects;
5. the required test and demonstration commands and their observed results;
6. the implementation, student-test, assignment-folder, and planned-submission
   review outcomes;
7. the Python version, added dependencies, and prohibited-operation check; and
8. one input assumption and one known limitation.

Run the compilation command from `report/` so LaTeX can locate the adjacent
style file:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Submission

Preserve the following paths in your Blackboard submission:

```text
products.py
tests/test_student.py
report/report.tex
report/report.pdf
AI_USE.md
```

When reasonably available, also include `ai-records/` and other relevant
verification records. Do not submit caches, virtual environments, credentials,
or unrelated files.

## 100-point feedback rubric (0% course-grade weight)

The 100-point rubric below demonstrates how this assignment is evaluated
and provides structured feedback.

| Component | Points |
| --- | ---: |
| `inner_product` | 10 |
| `outer_product` | 15 |
| `hadamard_product` | 15 |
| `matrix_product` | 25 |
| Student-written tests | 20 |
| Report and independent verification | 15 |
| **Total** | **100** |
