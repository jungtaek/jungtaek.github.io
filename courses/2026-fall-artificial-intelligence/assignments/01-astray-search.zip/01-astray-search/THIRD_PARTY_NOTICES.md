# Third-Party Notices

## Astray maze-generation approach

The recursive-backtracking maze-generation approach in `maze.py` is adapted
from the small maze generator in **Astray** by Rye Terrell (`wwwtyro`):

- Source: <https://github.com/wwwtyro/Astray/blob/master/maze.js>
- Project: <https://github.com/wwwtyro/Astray>
- Upstream license: The Unlicense (public domain dedication), reproduced at
  <https://github.com/wwwtyro/Astray/blob/master/License.md>

The course version is a new Python implementation with a private seeded random
number generator, an ASCII weighted-grid representation, optional extra
passages, and weighted terrain. It supplies a discrete search problem rather
than Astray's continuous physics game.

No Astray renderer, Box2D or Three.js integration, bundled dependency, texture,
sound, or other game asset is included. No code or asset from the GameWorld
benchmark collection is included.
