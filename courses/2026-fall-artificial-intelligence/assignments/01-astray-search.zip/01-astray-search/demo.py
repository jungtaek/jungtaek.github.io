"""Run a supplied search and write a self-contained HTML visualization.

The browser does not run the search algorithm.  This script records the Python
result as JSON and embeds it in ``viewer/template.html`` so the output can be
opened locally without a server or third-party dependency.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from maze import MazeProblem
from search import (
    SearchResult,
    a_star_search,
    breadth_first_search,
    depth_first_search,
    greedy_best_first_search,
    random_search,
    uniform_cost_search,
)


ASSIGNMENT_DIR = Path(__file__).resolve().parent
DEFAULT_LEVEL = ASSIGNMENT_DIR / "levels" / "weighted.txt"
DEFAULT_TEMPLATE = ASSIGNMENT_DIR / "viewer" / "template.html"
TRACE_PLACEHOLDER = "__TRACE_JSON__"
ALGORITHMS = ("random", "dfs", "bfs", "ucs", "greedy", "astar")


def manhattan_heuristic(
    problem: MazeProblem,
    state: tuple[int, int],
) -> float:
    """Return a weighted Manhattan-distance lower bound to the maze goal."""

    row, column = state
    goal_row, goal_column = problem.goal
    distance = abs(row - goal_row) + abs(column - goal_column)
    return float(distance * problem.minimum_step_cost)


def trace_payload(
    problem: MazeProblem,
    result: SearchResult[tuple[int, int], str],
    *,
    algorithm: str,
    seed: int | None,
    level: str,
) -> dict[str, Any]:
    """Convert a maze and search result to the viewer's stable JSON schema."""

    costs = [
        [
            None if tile == "#" else problem.cell_cost((row, column))
            for column, tile in enumerate(line)
        ]
        for row, line in enumerate(problem.rows)
    ]
    path = None
    if result.path is not None:
        path = {
            "states": result.path.states,
            "actions": result.path.actions,
            "cost": result.path.cost,
        }

    return {
        "schema_version": 1,
        "algorithm": algorithm,
        "seed": seed,
        "level": level,
        "maze": {
            "rows": problem.rows,
            "start": problem.start,
            "goal": problem.goal,
            "costs": costs,
        },
        "result": {
            "status": result.status,
            "expanded_count": result.expanded_count,
            "generated_count": result.generated_count,
            "peak_frontier": result.peak_frontier,
            "path": path,
            "frames": [
                {
                    "selected": frame.selected,
                    "frontier": frame.frontier,
                    "expanded": frame.expanded,
                }
                for frame in result.frames
            ],
        },
    }


def build_demo_html(payload: dict[str, Any], template: str) -> str:
    """Embed ``payload`` into one viewer template and return complete HTML."""

    placeholder_count = template.count(TRACE_PLACEHOLDER)
    if placeholder_count != 1:
        raise ValueError(
            "viewer template must contain exactly one "
            f"{TRACE_PLACEHOLDER!r} placeholder; found {placeholder_count}"
        )

    # Escaping '<' prevents payload strings from forming a closing script tag.
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    encoded = encoded.replace("<", "\\u003c")
    encoded = encoded.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return template.replace(TRACE_PLACEHOLDER, encoded)


def write_demo(
    level_path: Path,
    output_path: Path,
    *,
    algorithm: str = "random",
    seed: int | None = None,
    template_path: Path = DEFAULT_TEMPLATE,
) -> SearchResult[tuple[int, int], str]:
    """Run one search, write its visualization, and return the search result."""

    resolved_output = output_path.resolve()
    protected_inputs = {level_path.resolve(), template_path.resolve()}
    if resolved_output in protected_inputs:
        raise ValueError("HTML output must not overwrite the level or viewer template")

    problem = MazeProblem.from_file(level_path)
    heuristic = lambda state: manhattan_heuristic(problem, state)
    if algorithm == "random":
        result = random_search(problem, seed=seed)
    elif algorithm == "dfs":
        result = depth_first_search(problem)
    elif algorithm == "bfs":
        result = breadth_first_search(problem)
    elif algorithm == "ucs":
        result = uniform_cost_search(problem)
    elif algorithm == "greedy":
        result = greedy_best_first_search(problem, heuristic)
    elif algorithm == "astar":
        result = a_star_search(problem, heuristic)
    else:
        raise ValueError(f"unsupported demo algorithm: {algorithm!r}")
    payload = trace_payload(
        problem,
        result,
        algorithm=algorithm,
        seed=seed if algorithm == "random" else None,
        level=level_path.name,
    )
    template = template_path.read_text(encoding="utf-8")
    html = build_demo_html(payload, template)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a search and write a self-contained HTML replay."
    )
    parser.add_argument(
        "--algorithm",
        choices=ALGORITHMS,
        default="random",
        help="search policy to run (random is supplied; the others are TODOs)",
    )
    parser.add_argument(
        "--level",
        type=Path,
        default=DEFAULT_LEVEL,
        help="path to an ASCII maze level",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=7,
        help="private random-search seed",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results.html"),
        help="HTML output path",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Command-line entry point."""

    args = _parser().parse_args(argv)
    try:
        result = write_demo(
            args.level,
            args.output,
            algorithm=args.algorithm,
            seed=args.seed,
        )
    except (NotImplementedError, OSError, TypeError, ValueError) as error:
        raise SystemExit(f"error: {error}") from error

    path_cost = "--" if result.path is None else f"{result.path.cost:g}"
    print(f"status: {result.status}")
    print(f"path cost: {path_cost}")
    print(f"expanded: {result.expanded_count}")
    print(f"generated: {result.generated_count}")
    print(f"peak frontier: {result.peak_frontier}")
    print(f"wrote: {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
