"""Immutable weighted-grid search problems for Assignment 1.

A maze is written as a rectangular ASCII grid:

``#``
    A wall.
``S`` and ``G``
    The unique start and goal cells.  Entering either costs 1.
``.``
    Open terrain with cost 1.
``1`` through ``9``
    Open terrain whose digit is the cost of entering the cell.

Rows and columns are zero-indexed.  Moving has the cost of the destination
cell, so each successor has the form ``(action, next_state, step_cost)``.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import os
import random
from typing import Iterable


State = tuple[int, int]
Successor = tuple[str, State, int]

_OPEN_TILES = frozenset("SG.123456789")
_VALID_TILES = _OPEN_TILES | {"#"}
_DIRECTIONS: tuple[tuple[str, int, int], ...] = (
    ("UP", -1, 0),
    ("RIGHT", 0, 1),
    ("DOWN", 1, 0),
    ("LEFT", 0, -1),
)


@dataclass(frozen=True, slots=True)
class MazeProblem:
    """A validated, immutable weighted-grid search problem."""

    rows: tuple[str, ...]
    start: State = field(init=False)
    goal: State = field(init=False)
    _minimum_step_cost: int = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Normalize and validate rows supplied directly to the constructor."""

        if isinstance(self.rows, str):
            raise ValueError("rows must be a sequence of row strings, not one string")

        try:
            rows = tuple(self.rows)
        except TypeError as error:
            raise ValueError("rows must be a sequence of row strings") from error

        if not rows:
            raise ValueError("a maze must contain at least one row")
        if any(not isinstance(row, str) for row in rows):
            raise ValueError("every maze row must be a string")
        if not rows[0]:
            raise ValueError("maze rows must be nonempty")

        width = len(rows[0])
        if any(len(row) != width for row in rows):
            raise ValueError("a maze must be rectangular")

        invalid = sorted({tile for row in rows for tile in row} - _VALID_TILES)
        if invalid:
            shown = ", ".join(repr(tile) for tile in invalid)
            raise ValueError(f"invalid maze tile(s): {shown}")

        starts = [
            (row, column)
            for row, line in enumerate(rows)
            for column, tile in enumerate(line)
            if tile == "S"
        ]
        goals = [
            (row, column)
            for row, line in enumerate(rows)
            for column, tile in enumerate(line)
            if tile == "G"
        ]
        if len(starts) != 1:
            raise ValueError(f"a maze must contain exactly one S; found {len(starts)}")
        if len(goals) != 1:
            raise ValueError(f"a maze must contain exactly one G; found {len(goals)}")

        minimum_step_cost = min(
            self._tile_cost(tile)
            for row in rows
            for tile in row
            if tile in _OPEN_TILES
        )
        object.__setattr__(self, "rows", rows)
        object.__setattr__(self, "start", starts[0])
        object.__setattr__(self, "goal", goals[0])
        object.__setattr__(self, "_minimum_step_cost", minimum_step_cost)

    @classmethod
    def from_text(cls, text: str) -> MazeProblem:
        """Parse and validate a maze from ASCII text.

        A final line ending is accepted.  Leading, trailing, and internal
        blank rows are not discarded, so malformed or accidentally indented
        level files fail visibly instead of changing shape silently.
        """

        if not isinstance(text, str):
            raise ValueError("maze text must be a string")
        return cls(tuple(text.splitlines()))

    @classmethod
    def from_file(
        cls, path: str | os.PathLike[str], *, encoding: str = "utf-8"
    ) -> MazeProblem:
        """Read and parse a maze from ``path``."""

        with open(path, encoding=encoding) as level_file:
            return cls.from_text(level_file.read())

    @classmethod
    def generate(
        cls,
        height: int,
        width: int,
        *,
        seed: int | str | bytes | bytearray | None = None,
        extra_passages: int | None = None,
        weighted_fraction: float = 0.20,
    ) -> MazeProblem:
        """Generate a reproducible odd-sized maze with cycles and weights.

        The initial perfect maze uses randomized recursive backtracking.  A
        deterministic, seed-controlled selection of remaining interior walls
        is then opened to introduce cycles, and a selection of open cells is
        assigned costs from 2 through 9.

        ``extra_passages=None`` opens roughly one passage per ten logical
        cells (and at least one when a passage is available).  A requested
        number larger than the available set simply opens every candidate.
        """

        _validate_generation_options(
            height, width, extra_passages, weighted_fraction
        )
        rng = random.Random(seed)
        grid = [["#" for _ in range(width)] for _ in range(height)]

        # This is a Python adaptation of the randomized recursive-backtracker
        # used by wwwtyro/Astray's maze.js (released under the Unlicense):
        # https://github.com/wwwtyro/Astray/blob/master/maze.js
        # An explicit stack preserves the algorithm while avoiding Python's
        # recursion-depth limit on larger classroom examples.
        first = (1, 1)
        grid[first[0]][first[1]] = "."
        stack = [first]
        while stack:
            row, column = stack[-1]
            candidates: list[tuple[int, int, int, int]] = []
            for _, delta_row, delta_column in _DIRECTIONS:
                next_row = row + 2 * delta_row
                next_column = column + 2 * delta_column
                if (
                    1 <= next_row < height - 1
                    and 1 <= next_column < width - 1
                    and grid[next_row][next_column] == "#"
                ):
                    candidates.append(
                        (next_row, next_column, delta_row, delta_column)
                    )

            if not candidates:
                stack.pop()
                continue

            next_row, next_column, delta_row, delta_column = rng.choice(
                candidates
            )
            grid[row + delta_row][column + delta_column] = "."
            grid[next_row][next_column] = "."
            stack.append((next_row, next_column))

        passage_candidates = _closed_passage_candidates(grid)
        rng.shuffle(passage_candidates)
        logical_cells = ((height - 1) // 2) * ((width - 1) // 2)
        passage_count = (
            max(1, logical_cells // 10)
            if extra_passages is None and passage_candidates
            else extra_passages or 0
        )
        for row, column in passage_candidates[:passage_count]:
            grid[row][column] = "."

        start = first
        goal = _farthest_open_cell(grid, start)
        grid[start[0]][start[1]] = "S"
        grid[goal[0]][goal[1]] = "G"

        weight_candidates = [
            (row, column)
            for row in range(1, height - 1)
            for column in range(1, width - 1)
            if grid[row][column] == "."
        ]
        rng.shuffle(weight_candidates)
        weight_count = round(len(weight_candidates) * weighted_fraction)
        if weighted_fraction > 0.0 and weight_candidates:
            weight_count = max(1, weight_count)
        for row, column in weight_candidates[:weight_count]:
            grid[row][column] = str(rng.randint(2, 9))

        return cls(tuple("".join(row) for row in grid))

    @property
    def height(self) -> int:
        """Return the number of maze rows."""

        return len(self.rows)

    @property
    def width(self) -> int:
        """Return the number of columns in each maze row."""

        return len(self.rows[0])

    @property
    def initial_state(self) -> State:
        """Return the search problem's start state."""

        return self.start

    @property
    def minimum_step_cost(self) -> int:
        """Return the least cost of entering any traversable cell."""

        return self._minimum_step_cost

    def is_goal(self, state: State) -> bool:
        """Return whether ``state`` is the goal state."""

        return state == self.goal

    def successors(self, state: State) -> tuple[Successor, ...]:
        """Return open neighbors in canonical UP, RIGHT, DOWN, LEFT order."""

        row, column = self._validated_open_state(state)
        successors: list[Successor] = []
        for action, delta_row, delta_column in _DIRECTIONS:
            next_state = (row + delta_row, column + delta_column)
            next_row, next_column = next_state
            if (
                0 <= next_row < self.height
                and 0 <= next_column < self.width
                and self.rows[next_row][next_column] != "#"
            ):
                successors.append(
                    (action, next_state, self.cell_cost(next_state))
                )
        return tuple(successors)

    def cell_cost(self, state: State) -> int:
        """Return the cost of entering a traversable ``state``."""

        row, column = self._validated_open_state(state)
        return self._tile_cost(self.rows[row][column])

    def to_text(self) -> str:
        """Serialize the maze to its canonical ASCII representation."""

        return "\n".join(self.rows)

    def render(self, path: Iterable[State] = ()) -> str:
        """Render the maze with non-endpoint cells in ``path`` marked ``*``."""

        rendered = [list(row) for row in self.rows]
        for state in path:
            row, column = self._validated_open_state(state)
            if state not in (self.start, self.goal):
                rendered[row][column] = "*"
        return "\n".join("".join(row) for row in rendered)

    def _validated_open_state(self, state: State) -> State:
        if (
            not isinstance(state, tuple)
            or len(state) != 2
            or any(
                isinstance(value, bool) or not isinstance(value, int)
                for value in state
            )
        ):
            raise ValueError("a state must be a (row, column) pair of integers")

        row, column = state
        if not (0 <= row < self.height and 0 <= column < self.width):
            raise ValueError(f"state is outside the maze: {state!r}")
        if self.rows[row][column] == "#":
            raise ValueError(f"state is a wall: {state!r}")
        return state

    @staticmethod
    def _tile_cost(tile: str) -> int:
        return int(tile) if tile.isdigit() else 1


def generate_maze(
    height: int,
    width: int,
    *,
    seed: int | str | bytes | bytearray | None = None,
    extra_passages: int | None = None,
    weighted_fraction: float = 0.20,
) -> MazeProblem:
    """Convenience wrapper around :meth:`MazeProblem.generate`."""

    return MazeProblem.generate(
        height,
        width,
        seed=seed,
        extra_passages=extra_passages,
        weighted_fraction=weighted_fraction,
    )


def _validate_generation_options(
    height: int,
    width: int,
    extra_passages: int | None,
    weighted_fraction: float,
) -> None:
    if any(
        isinstance(value, bool) or not isinstance(value, int)
        for value in (height, width)
    ):
        raise ValueError("maze height and width must be integers")
    if height < 5 or width < 5 or height % 2 == 0 or width % 2 == 0:
        raise ValueError("generated mazes require odd height and width of at least 5")
    if extra_passages is not None and (
        isinstance(extra_passages, bool)
        or not isinstance(extra_passages, int)
        or extra_passages < 0
    ):
        raise ValueError("extra_passages must be a nonnegative integer or None")
    if (
        isinstance(weighted_fraction, bool)
        or not isinstance(weighted_fraction, (int, float))
        or not 0.0 <= weighted_fraction <= 1.0
    ):
        raise ValueError("weighted_fraction must be between 0 and 1")


def _closed_passage_candidates(grid: list[list[str]]) -> list[State]:
    """Return closed walls between pairs of already carved logical cells."""

    height = len(grid)
    width = len(grid[0])
    candidates: list[State] = []
    for row in range(1, height - 1):
        for column in range(1, width - 1):
            if grid[row][column] != "#":
                continue
            horizontal = (
                grid[row][column - 1] != "#"
                and grid[row][column + 1] != "#"
            )
            vertical = (
                grid[row - 1][column] != "#"
                and grid[row + 1][column] != "#"
            )
            if horizontal != vertical:
                candidates.append((row, column))
    return candidates


def _farthest_open_cell(grid: list[list[str]], start: State) -> State:
    """Return a deterministic farthest cell from ``start`` by move count."""

    queue = deque([start])
    distances = {start: 0}
    while queue:
        row, column = queue.popleft()
        for _, delta_row, delta_column in _DIRECTIONS:
            neighbor = (row + delta_row, column + delta_column)
            next_row, next_column = neighbor
            if grid[next_row][next_column] != "#" and neighbor not in distances:
                distances[neighbor] = distances[(row, column)] + 1
                queue.append(neighbor)

    # Tuple ordering makes equal-distance ties reproducible independently of
    # dictionary insertion order.
    return max(distances, key=lambda state: (distances[state], state))
