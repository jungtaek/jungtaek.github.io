"""Write independent tests for your search implementations here.

Add meaningful ``unittest`` methods to ``TestStudentSearch``. Your tests must
not copy the exact cases in ``test_public.py``. Include small graphs or mazes
whose expected selection order, path, cost, and termination behavior you have
checked independently.

All tests must pass for a correct implementation. A method containing only
``pass`` or an unconditional failing assertion is not a meaningful test. The
starter intentionally contains no placeholder test method, so this file does
not add an artificial failure before you begin.
"""

import unittest

import search


class TestStudentSearch(unittest.TestCase):
    """Add your independently designed ``test_*`` methods to this class."""

    # TODO: Add meaningful tests here. Import functions through the ``search``
    # module so the evaluation tools can assess your tests.


if __name__ == "__main__":
    unittest.main()
