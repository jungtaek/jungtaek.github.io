"""Transparent tests for the supplied Assignment 1 starter components."""

from __future__ import annotations

import json
from pathlib import Path
import random
import tempfile
import unittest

import demo
from maze import MazeProblem
from search import Node, Path as SearchPath, SearchFrame, random_search


ASSIGNMENT_DIR = Path(__file__).resolve().parents[1]
LEVELS_DIR = ASSIGNMENT_DIR / "levels"


class GraphProblem:
    """Small explicit graph used to isolate search-engine behavior."""

    def __init__(
        self,
        initial_state: str,
        goal: str,
        edges: dict[str, tuple[tuple[str, str, float], ...]],
    ) -> None:
        self.initial_state = initial_state
        self.goal = goal
        self.edges = edges

    def is_goal(self, state: str) -> bool:
        return state == self.goal

    def successors(self, state: str) -> tuple[tuple[str, str, float], ...]:
        return self.edges.get(state, ())


class TestMazeProblem(unittest.TestCase):
    def test_parse_successors_and_destination_costs(self) -> None:
        problem = MazeProblem.from_text(
            "#####\n"
            "#S2##\n"
            "#3G##\n"
            "#####\n"
        )

        self.assertEqual(problem.initial_state, (1, 1))
        self.assertEqual(problem.goal, (2, 2))
        self.assertEqual(
            problem.successors(problem.initial_state),
            (("RIGHT", (1, 2), 2), ("DOWN", (2, 1), 3)),
        )
        self.assertEqual(problem.minimum_step_cost, 1)
        self.assertEqual(problem.to_text(), "#####\n#S2##\n#3G##\n#####")

    def test_invalid_maze_text_is_rejected(self) -> None:
        invalid_levels = (
            "",
            "###\n#S#\n###",
            "#####\n#SSG#\n#####",
            "#####\n#S@G#\n#####",
            "#####\n#S.G#\n####",
        )

        for text in invalid_levels:
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    MazeProblem.from_text(text)

    def test_seeded_generation_is_reproducible_connected_and_local(self) -> None:
        random.seed(2026)
        global_state = random.getstate()

        first = MazeProblem.generate(
            11,
            15,
            seed=31,
            extra_passages=5,
            weighted_fraction=0.25,
        )
        second = MazeProblem.generate(
            11,
            15,
            seed=31,
            extra_passages=5,
            weighted_fraction=0.25,
        )

        self.assertEqual(first, second)
        self.assertEqual(random.getstate(), global_state)
        self.assertEqual(first.height, 11)
        self.assertEqual(first.width, 15)
        self.assertTrue(all(tile == "#" for tile in first.rows[0]))
        self.assertTrue(all(tile == "#" for tile in first.rows[-1]))
        self.assertTrue(all(row[0] == row[-1] == "#" for row in first.rows))

        reached = {first.start}
        frontier = [first.start]
        while frontier:
            state = frontier.pop()
            for _, next_state, _ in first.successors(state):
                if next_state not in reached:
                    reached.add(next_state)
                    frontier.append(next_state)
        open_states = {
            (row, column)
            for row, line in enumerate(first.rows)
            for column, tile in enumerate(line)
            if tile != "#"
        }
        self.assertEqual(reached, open_states)
        self.assertTrue(any(tile in "23456789" for row in first.rows for tile in row))
        edge_count = sum(len(first.successors(state)) for state in open_states) // 2
        self.assertGreater(edge_count, len(open_states) - 1)


class TestRandomSearch(unittest.TestCase):
    def test_forced_corridor_has_exact_path_and_metrics(self) -> None:
        problem = MazeProblem.from_file(LEVELS_DIR / "corridor.txt")

        result = random_search(problem, seed=7)

        self.assertEqual(result.status, "success")
        self.assertIsNotNone(result.path)
        assert result.path is not None
        self.assertEqual(
            result.path.states,
            ((1, 1), (1, 2), (1, 3), (1, 4), (1, 5)),
        )
        self.assertEqual(result.path.actions, ("RIGHT",) * 4)
        self.assertEqual(result.path.cost, 4)
        self.assertEqual(result.expanded_count, 4)
        self.assertEqual(result.generated_count, 5)
        self.assertEqual(result.peak_frontier, 1)
        self.assertEqual(len(result.frames), 5)
        self.assertEqual(
            result.frames[0],
            SearchFrame(
                selected=(1, 1),
                frontier=((1, 2),),
                expanded=((1, 1),),
            ),
        )
        self.assertEqual(result.frames[-1].selected, problem.goal)
        self.assertEqual(result.frames[-1].frontier, ())
        self.assertEqual(
            result.frames[-1].expanded,
            ((1, 1), (1, 2), (1, 3), (1, 4)),
        )

    def test_same_seed_reproduces_complete_result_without_global_rng(self) -> None:
        problem = MazeProblem.from_file(LEVELS_DIR / "weighted.txt")
        random.seed(8675309)
        global_state = random.getstate()

        first = random_search(problem, seed=7)
        random.seed(42)
        second = random_search(problem, seed=7)

        self.assertEqual(first, second)
        random.setstate(global_state)
        before = random.getstate()
        random_search(problem, seed=7)
        self.assertEqual(random.getstate(), before)

    def test_random_frontier_is_not_an_optimal_cost_search(self) -> None:
        problem = GraphProblem(
            "S",
            "G",
            {
                "S": (("expensive", "G", 9), ("to-b", "B", 1)),
                "B": (("cheap", "G", 1),),
            },
        )

        result = random_search(problem, seed=7)

        self.assertEqual(result.status, "success")
        assert result.path is not None
        self.assertEqual(result.path.states, ("S", "G"))
        self.assertEqual(result.path.cost, 9)
        self.assertGreater(result.path.cost, 2)

    def test_cycle_without_goal_terminates_as_failure(self) -> None:
        problem = GraphProblem(
            "A",
            "Z",
            {
                "A": (("to-b", "B", 1),),
                "B": (("to-a", "A", 1),),
            },
        )

        result = random_search(problem, seed=0)

        self.assertEqual(result.status, "failure")
        self.assertIsNone(result.path)
        self.assertEqual(result.expanded_count, 2)
        self.assertEqual(result.generated_count, 2)
        self.assertEqual(tuple(frame.selected for frame in result.frames), ("A", "B"))

    def test_initial_goal_succeeds_without_expansion(self) -> None:
        solved = GraphProblem("A", "A", {})

        result = random_search(solved, seed=0)

        self.assertEqual(result.status, "success")
        self.assertEqual(result.expanded_count, 0)
        self.assertEqual(result.generated_count, 1)
        self.assertEqual(result.peak_frontier, 1)
        self.assertIsNotNone(result.path)
        assert result.path is not None
        self.assertEqual(result.path.states, ("A",))
        self.assertEqual(result.path.actions, ())
        self.assertEqual(result.path.cost, 0)
        self.assertEqual(
            result.frames,
            (SearchFrame(selected="A", frontier=(), expanded=()),),
        )

    def test_invalid_costs_are_rejected(self) -> None:
        invalid_costs = (0, -1, float("inf"), float("nan"), True, "2")
        for cost in invalid_costs:
            with self.subTest(cost=cost):
                simple = GraphProblem(
                    "A",
                    "Z",
                    {"A": (("go", "Z", cost),)},  # type: ignore[arg-type]
                )
                with self.assertRaises(ValueError):
                    random_search(simple, seed=0)

        malformed = GraphProblem(
            "A",
            "Z",
            {"A": (("missing-cost", "Z"),)},  # type: ignore[dict-item]
        )
        with self.assertRaises(ValueError):
            random_search(malformed, seed=0)

        with self.assertRaises(ValueError):
            Node(state="A", parent=None, action=None, path_cost="0")  # type: ignore[arg-type]
        with self.assertRaises(ValueError):
            SearchPath(states=("A",), actions=(), cost=True)


class TestHtmlDemo(unittest.TestCase):
    def test_payload_and_embedding_are_self_contained(self) -> None:
        problem = MazeProblem.from_file(LEVELS_DIR / "corridor.txt")
        result = random_search(problem, seed=7)
        payload = demo.trace_payload(
            problem,
            result,
            algorithm="random",
            seed=7,
            level="levels/corridor.txt",
        )

        html = demo.build_demo_html(
            {**payload, "level": "</script><script>bad()</script>"},
            '<script type="application/json">__TRACE_JSON__</script>',
        )

        self.assertNotIn(demo.TRACE_PLACEHOLDER, html)
        self.assertNotIn("<script>bad()", html)
        self.assertIn("\\u003c/script>", html)
        self.assertEqual(payload["maze"]["costs"][1][1:6], [1, 1, 1, 1, 1])
        self.assertEqual(payload["result"]["status"], "success")
        self.assertEqual(demo.manhattan_heuristic(problem, problem.start), 4)
        self.assertEqual(demo.manhattan_heuristic(problem, problem.goal), 0)
        for row, line in enumerate(problem.rows):
            for column, tile in enumerate(line):
                if tile == "#":
                    continue
                state = (row, column)
                estimate = demo.manhattan_heuristic(problem, state)
                for _, next_state, step_cost in problem.successors(state):
                    next_estimate = demo.manhattan_heuristic(problem, next_state)
                    self.assertLessEqual(estimate, step_cost + next_estimate)

    def test_write_demo_embeds_parseable_trace_in_real_template(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            output = Path(temporary_directory) / "nested" / "result.html"
            result = demo.write_demo(
                LEVELS_DIR / "corridor.txt",
                output,
                seed=7,
            )
            html = output.read_text(encoding="utf-8")

        self.assertNotIn('id="schema-badge"', html)
        marker = "<script type='application/json' id='trace-data'>"
        json_start = html.index(marker) + len(marker)
        json_end = html.index("</script>", json_start)
        embedded = json.loads(html[json_start:json_end])
        self.assertEqual(result.status, "success")
        self.assertEqual(embedded["schema_version"], 1)
        self.assertEqual(embedded["result"]["path"]["cost"], 4)
        self.assertNotIn("http://", html)
        self.assertNotIn("https://", html)

    def test_write_demo_refuses_to_overwrite_an_input(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            directory = Path(temporary_directory)
            level = directory / "level.txt"
            level_text = "#####\n#S.G#\n#####\n"
            level.write_text(level_text, encoding="utf-8")

            with self.assertRaises(ValueError):
                demo.write_demo(level, level, seed=7)

            template = directory / "template.html"
            template.write_text("__TRACE_JSON__", encoding="utf-8")
            with self.assertRaises(ValueError):
                demo.write_demo(level, template, seed=7, template_path=template)

            self.assertEqual(level.read_text(encoding="utf-8"), level_text)
            self.assertEqual(template.read_text(encoding="utf-8"), "__TRACE_JSON__")


if __name__ == "__main__":
    unittest.main()
