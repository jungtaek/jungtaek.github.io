"""Tests for Assignment 1: Astray Search."""
