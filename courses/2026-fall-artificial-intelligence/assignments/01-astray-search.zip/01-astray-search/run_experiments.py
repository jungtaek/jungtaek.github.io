"""Run the complete Astray Search experiment matrix.

By default, this script runs every search method on every supplied level.  It
writes one interactive HTML replay per run, a CSV summary, and an HTML index
that links the aggregate metrics to the individual replays.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
import html
from pathlib import Path
import sys
from typing import Sequence
from urllib.parse import quote

from demo import ALGORITHMS, write_demo


ASSIGNMENT_DIR = Path(__file__).resolve().parent
LEVELS_DIR = ASSIGNMENT_DIR / "levels"
DEFAULT_OUTPUT_DIR = ASSIGNMENT_DIR / "experiment_results"


@dataclass(frozen=True)
class ExperimentRow:
    """One completed or failed level-and-algorithm experiment."""

    level: str
    algorithm: str
    seed: int | None
    status: str
    steps: int | None
    path_cost: float | None
    expanded: int | None
    generated: int | None
    peak_frontier: int | None
    replay: str | None
    error: str | None


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run every Astray Search method on every supplied level and "
            "write aggregate results."
        )
    )
    parser.add_argument(
        "--levels",
        nargs="+",
        type=Path,
        default=None,
        metavar="LEVEL",
        help=(
            "levels to run; each value may be a path or a supplied level name "
            "such as 'weighted' (default: every supplied level)"
        ),
    )
    parser.add_argument(
        "--algorithms",
        nargs="+",
        choices=ALGORITHMS,
        default=list(ALGORITHMS),
        metavar="ALGORITHM",
        help="methods to run (default: every method)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=7,
        help="seed for random search (default: 7)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"output directory (default: {DEFAULT_OUTPUT_DIR})",
    )
    return parser


def _resolve_level(value: Path) -> Path:
    candidates: list[Path]
    if value.is_absolute():
        candidates = [value]
    else:
        candidates = [Path.cwd() / value, ASSIGNMENT_DIR / value, LEVELS_DIR / value]
    if value.suffix == "":
        candidates.extend(
            candidate.with_suffix(".txt") for candidate in tuple(candidates)
        )

    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()

    raise ValueError(f"level does not exist: {value}")


def _resolve_levels(values: Sequence[Path] | None) -> tuple[Path, ...]:
    if values is None:
        levels = tuple(sorted(path.resolve() for path in LEVELS_DIR.glob("*.txt")))
        if not levels:
            raise ValueError(f"no supplied levels found in {LEVELS_DIR}")
    else:
        levels = tuple(_resolve_level(value) for value in values)

    seen_stems: dict[str, Path] = {}
    for level in levels:
        previous = seen_stems.get(level.stem)
        if previous is not None:
            raise ValueError(
                "level file stems must be unique because they name output folders: "
                f"{previous} and {level}"
            )
        seen_stems[level.stem] = level
    return levels


def _replay_relative_path(level: Path, algorithm: str, seed: int) -> Path:
    filename = (
        f"random-seed-{seed}.html" if algorithm == "random" else f"{algorithm}.html"
    )
    return Path("replays") / level.stem / filename


def _run_one(
    level: Path,
    algorithm: str,
    *,
    seed: int,
    output_dir: Path,
) -> ExperimentRow:
    replay_relative = _replay_relative_path(level, algorithm, seed)
    replay_path = output_dir / replay_relative
    experiment_seed = seed if algorithm == "random" else None

    try:
        result = write_demo(
            level,
            replay_path,
            algorithm=algorithm,
            seed=seed,
        )
    except Exception as error:  # Continue so one broken method cannot hide others.
        try:
            replay_path.unlink(missing_ok=True)
        except OSError:
            # A stale output is never linked from this run's index or summary.
            pass
        return ExperimentRow(
            level=level.stem,
            algorithm=algorithm,
            seed=experiment_seed,
            status="error",
            steps=None,
            path_cost=None,
            expanded=None,
            generated=None,
            peak_frontier=None,
            replay=None,
            error=f"{type(error).__name__}: {error}",
        )

    path = result.path
    return ExperimentRow(
        level=level.stem,
        algorithm=algorithm,
        seed=experiment_seed,
        status=result.status,
        steps=None if path is None else len(path.actions),
        path_cost=None if path is None else path.cost,
        expanded=result.expanded_count,
        generated=result.generated_count,
        peak_frontier=result.peak_frontier,
        replay=replay_relative.as_posix(),
        error=None,
    )


def run_experiments(
    levels: Sequence[Path],
    algorithms: Sequence[str],
    *,
    seed: int,
    output_dir: Path,
) -> tuple[ExperimentRow, ...]:
    """Run the requested Cartesian product and return one row per experiment."""

    output_dir.mkdir(parents=True, exist_ok=True)
    rows = [
        _run_one(
            level,
            algorithm,
            seed=seed,
            output_dir=output_dir,
        )
        for level in levels
        for algorithm in algorithms
    ]
    return tuple(rows)


def _csv_value(value: object | None) -> object:
    return "" if value is None else value


def write_summary_csv(rows: Sequence[ExperimentRow], output_path: Path) -> None:
    """Write machine-readable metrics for every attempted experiment."""

    fieldnames = (
        "level",
        "algorithm",
        "seed",
        "status",
        "steps",
        "path_cost",
        "expanded",
        "generated",
        "peak_frontier",
        "replay",
        "error",
    )
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "level": row.level,
                    "algorithm": row.algorithm,
                    "seed": _csv_value(row.seed),
                    "status": row.status,
                    "steps": _csv_value(row.steps),
                    "path_cost": _csv_value(row.path_cost),
                    "expanded": _csv_value(row.expanded),
                    "generated": _csv_value(row.generated),
                    "peak_frontier": _csv_value(row.peak_frontier),
                    "replay": _csv_value(row.replay),
                    "error": _csv_value(row.error),
                }
            )


def _display_value(value: object | None) -> str:
    if value is None:
        return "—"
    if isinstance(value, float):
        return f"{value:g}"
    return str(value)


def _html_row(row: ExperimentRow) -> str:
    if row.replay is None:
        details = html.escape(row.error or "No replay was generated.")
    else:
        href = html.escape(quote(row.replay), quote=True)
        details = f'<a href="{href}">Open replay</a>'

    values = (
        row.level,
        row.algorithm,
        _display_value(row.seed),
        row.status,
        _display_value(row.steps),
        _display_value(row.path_cost),
        _display_value(row.expanded),
        _display_value(row.generated),
        _display_value(row.peak_frontier),
    )
    cells = "".join(f"<td>{html.escape(value)}</td>" for value in values)
    return (
        f'<tr class="status-{html.escape(row.status)}">'
        f"{cells}<td>{details}</td></tr>"
    )


def write_index_html(
    rows: Sequence[ExperimentRow],
    output_path: Path,
    *,
    seed: int,
) -> None:
    """Write a self-contained comparison page linked to successful replays."""

    error_count = sum(row.error is not None for row in rows)
    completed_count = len(rows) - error_count
    table_rows = "\n".join(_html_row(row) for row in rows)
    document = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Astray Search Experiment Results</title>
  <style>
    :root {{ color-scheme: light; font-family: system-ui, sans-serif; }}
    body {{ margin: 0 auto; max-width: 1180px; padding: 2rem; color: #172033; }}
    h1 {{ margin-bottom: 0.35rem; }}
    p {{ color: #4b5565; }}
    .table-wrap {{ overflow-x: auto; border: 1px solid #d7dce3; border-radius: 8px; }}
    table {{
      width: 100%; border-collapse: collapse;
      font-variant-numeric: tabular-nums;
    }}
    th, td {{
      padding: 0.65rem 0.75rem; border-bottom: 1px solid #e5e7eb;
      text-align: left;
    }}
    th {{ background: #f3f5f8; white-space: nowrap; }}
    tbody tr:hover {{ background: #f8fafc; }}
    .status-success td:nth-child(4) {{ color: #08783e; font-weight: 650; }}
    .status-failure td:nth-child(4) {{ color: #9a5b00; font-weight: 650; }}
    .status-error {{ background: #fff4f2; }}
    .status-error td:nth-child(4), .status-error td:last-child {{ color: #b42318; }}
    a {{ color: #145bcc; }}
  </style>
</head>
<body>
  <h1>Astray Search Experiment Results</h1>
  <p>{completed_count} of {len(rows)} experiments completed; {error_count} errors.
     Random seed: {seed}.</p>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Level</th><th>Method</th><th>Seed</th><th>Status</th>
          <th>Steps</th><th>Cost</th><th>Expanded</th><th>Generated</th>
          <th>Peak frontier</th><th>Replay or error</th>
        </tr>
      </thead>
      <tbody>
{table_rows}
      </tbody>
    </table>
  </div>
</body>
</html>
"""
    output_path.write_text(document, encoding="utf-8")


def _print_summary(rows: Sequence[ExperimentRow], output_dir: Path) -> None:
    columns = (
        ("LEVEL", [row.level for row in rows]),
        ("METHOD", [row.algorithm for row in rows]),
        ("SEED", [_display_value(row.seed) for row in rows]),
        ("STATUS", [row.status for row in rows]),
        ("STEPS", [_display_value(row.steps) for row in rows]),
        ("COST", [_display_value(row.path_cost) for row in rows]),
        ("EXPANDED", [_display_value(row.expanded) for row in rows]),
        ("GENERATED", [_display_value(row.generated) for row in rows]),
        ("PEAK", [_display_value(row.peak_frontier) for row in rows]),
    )
    widths = [
        max(len(header), *(len(value) for value in values))
        for header, values in columns
    ]
    print("  ".join(header.ljust(width) for (header, _), width in zip(columns, widths)))
    print("  ".join("-" * width for width in widths))
    for index in range(len(rows)):
        print(
            "  ".join(
                values[index].ljust(width)
                for (_, values), width in zip(columns, widths)
            )
        )

    for row in rows:
        if row.error is not None:
            print(
                f"error [{row.level}/{row.algorithm}]: {row.error}",
                file=sys.stderr,
            )

    error_count = sum(row.error is not None for row in rows)
    print(f"\nCompleted {len(rows) - error_count}/{len(rows)} experiments.")
    print(f"HTML index: {(output_dir / 'index.html').resolve()}")
    print(f"CSV summary: {(output_dir / 'summary.csv').resolve()}")


def main(argv: Sequence[str] | None = None) -> int:
    """Command-line entry point."""

    parser = _parser()
    args = parser.parse_args(argv)
    try:
        levels = _resolve_levels(args.levels)
        algorithms = tuple(dict.fromkeys(args.algorithms))
        output_dir = args.output_dir.expanduser().resolve()
        rows = run_experiments(
            levels,
            algorithms,
            seed=args.seed,
            output_dir=output_dir,
        )
        write_summary_csv(rows, output_dir / "summary.csv")
        write_index_html(
            rows,
            output_dir / "index.html",
            seed=args.seed,
        )
    except (OSError, TypeError, ValueError) as error:
        parser.exit(2, f"error: {error}\n")

    _print_summary(rows, output_dir)
    return 1 if any(row.error is not None for row in rows) else 0


if __name__ == "__main__":
    raise SystemExit(main())
