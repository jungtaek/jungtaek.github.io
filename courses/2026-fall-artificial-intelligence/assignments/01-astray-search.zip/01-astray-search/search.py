"""Generic search interfaces and the supplied random-search baseline.

The uninformed and informed search functions at the bottom of this module are
student TODOs.  The random baseline is complete so that students can exercise
the problem interface and viewer before implementing those algorithms.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from numbers import Real
import random
from typing import (
    Callable,
    Generic,
    Hashable,
    Iterable,
    Literal,
    Protocol,
    TypeVar,
    cast,
)


StateT = TypeVar("StateT", bound=Hashable)
ActionT = TypeVar("ActionT")
Action_co = TypeVar("Action_co", covariant=True)
SearchStatus = Literal["success", "failure"]


class SearchProblem(Protocol[StateT, Action_co]):
    """The minimal interface required by the search algorithms."""

    @property
    def initial_state(self) -> StateT:
        """Return the problem's initial state."""

    def is_goal(self, state: StateT) -> bool:
        """Return whether *state* satisfies the goal condition."""

    def successors(
        self, state: StateT
    ) -> Iterable[tuple[Action_co, StateT, float]]:
        """Yield ``(action, next_state, step_cost)`` triples in a stable order."""


@dataclass(frozen=True)
class Node(Generic[StateT, ActionT]):
    """A node in a search tree, including the link used to reconstruct a path."""

    state: StateT
    parent: Node[StateT, ActionT] | None
    action: ActionT | None
    path_cost: float

    def __post_init__(self) -> None:
        _require_hashable(self.state)
        if not _is_finite_number(self.path_cost):
            raise ValueError("node path_cost must be finite and nonnegative")
        normalized_cost = float(self.path_cost)
        if normalized_cost < 0:
            raise ValueError("node path_cost must be finite and nonnegative")
        object.__setattr__(self, "path_cost", normalized_cost)
        if self.parent is None:
            if self.action is not None:
                raise ValueError("a root node cannot have an incoming action")
            if normalized_cost != 0:
                raise ValueError("a root node must have path_cost 0")
        elif normalized_cost <= self.parent.path_cost:
            raise ValueError("a child node must have greater path_cost than its parent")


@dataclass(frozen=True)
class Path(Generic[StateT, ActionT]):
    """A solution path from the initial state through zero or more actions."""

    states: tuple[StateT, ...]
    actions: tuple[ActionT, ...]
    cost: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "states", tuple(self.states))
        object.__setattr__(self, "actions", tuple(self.actions))
        if not self.states:
            raise ValueError("a path must contain at least one state")
        if len(self.actions) != len(self.states) - 1:
            raise ValueError("a path must have exactly one fewer action than states")
        if not _is_finite_number(self.cost):
            raise ValueError("path cost must be finite and nonnegative")
        normalized_cost = float(self.cost)
        if normalized_cost < 0:
            raise ValueError("path cost must be finite and nonnegative")
        object.__setattr__(self, "cost", normalized_cost)


@dataclass(frozen=True)
class SearchFrame(Generic[StateT]):
    """State-only snapshot consumed by the assignment's HTML viewer."""

    selected: StateT
    frontier: tuple[StateT, ...]
    expanded: tuple[StateT, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "frontier", tuple(self.frontier))
        object.__setattr__(self, "expanded", tuple(self.expanded))


@dataclass(frozen=True)
class SearchResult(Generic[StateT, ActionT]):
    """The outcome and observable work performed by a search."""

    status: SearchStatus
    path: Path[StateT, ActionT] | None
    expanded_count: int
    generated_count: int
    peak_frontier: int
    frames: tuple[SearchFrame[StateT], ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "frames", tuple(self.frames))
        if self.status not in ("success", "failure"):
            raise ValueError(f"unknown search status: {self.status!r}")
        if (self.status == "success") != (self.path is not None):
            raise ValueError("exactly successful results must contain a path")
        for name in ("expanded_count", "generated_count", "peak_frontier"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        if self.generated_count < 1:
            raise ValueError("generated_count must include the root node")
        if self.expanded_count > self.generated_count:
            raise ValueError("expanded_count cannot exceed generated_count")
        if self.peak_frontier < 1:
            raise ValueError("peak_frontier must include the initial frontier")
        if self.peak_frontier > self.generated_count:
            raise ValueError("peak_frontier cannot exceed generated_count")


def random_search(
    problem: SearchProblem[StateT, ActionT],
    *,
    seed: int | None = None,
) -> SearchResult[StateT, ActionT]:
    """Run random-frontier graph search.

    Each selection is uniform over the current frontier.  States enter the
    reached set when generated, so every reachable state is generated at most
    once.  A supplied seed makes the complete run, including its frames,
    reproducible without reading or changing Python's global random state.
    """

    rng = random.Random(seed)

    initial_state = problem.initial_state
    _require_hashable(initial_state)
    root: Node[StateT, ActionT] = Node(
        state=initial_state,
        parent=None,
        action=None,
        path_cost=0.0,
    )
    frontier = [root]
    reached = {root.state}
    expanded_states: list[StateT] = []
    frames: list[SearchFrame[StateT]] = []
    expanded_count = 0
    generated_count = 1
    peak_frontier = 1

    while frontier:
        selected_index = rng.randrange(len(frontier))
        selected = frontier.pop(selected_index)

        if problem.is_goal(selected.state):
            frames.append(_make_frame(selected, frontier, expanded_states))
            return SearchResult(
                status="success",
                path=_reconstruct_path(selected),
                expanded_count=expanded_count,
                generated_count=generated_count,
                peak_frontier=peak_frontier,
                frames=tuple(frames),
            )

        expanded_count += 1
        expanded_states.append(selected.state)

        for successor in problem.successors(selected.state):
            try:
                action, next_state, raw_step_cost = successor
            except (TypeError, ValueError) as error:
                raise ValueError(
                    "successors must yield (action, next_state, step_cost) triples"
                ) from error

            _require_hashable(next_state)
            step_cost = _validated_step_cost(raw_step_cost)
            if next_state in reached:
                continue

            reached.add(next_state)
            frontier.append(
                Node(
                    state=next_state,
                    parent=selected,
                    action=action,
                    path_cost=selected.path_cost + step_cost,
                )
            )
            generated_count += 1

        peak_frontier = max(peak_frontier, len(frontier))
        frames.append(_make_frame(selected, frontier, expanded_states))

    return SearchResult(
        status="failure",
        path=None,
        expanded_count=expanded_count,
        generated_count=generated_count,
        peak_frontier=peak_frontier,
        frames=tuple(frames),
    )


def depth_first_search(
    problem: SearchProblem[StateT, ActionT],
) -> SearchResult[StateT, ActionT]:
    """TODO: implement depth-first graph search."""

    raise NotImplementedError("TODO: implement depth-first graph search")


def breadth_first_search(
    problem: SearchProblem[StateT, ActionT],
) -> SearchResult[StateT, ActionT]:
    """TODO: implement breadth-first graph search."""

    raise NotImplementedError("TODO: implement breadth-first graph search")


def uniform_cost_search(
    problem: SearchProblem[StateT, ActionT],
) -> SearchResult[StateT, ActionT]:
    """TODO: implement uniform-cost graph search."""

    raise NotImplementedError("TODO: implement uniform-cost graph search")


def greedy_best_first_search(
    problem: SearchProblem[StateT, ActionT],
    heuristic: Callable[[StateT], float],
) -> SearchResult[StateT, ActionT]:
    """TODO: implement greedy best-first graph search."""

    raise NotImplementedError("TODO: implement greedy best-first graph search")


def a_star_search(
    problem: SearchProblem[StateT, ActionT],
    heuristic: Callable[[StateT], float],
) -> SearchResult[StateT, ActionT]:
    """TODO: implement A* graph search."""

    raise NotImplementedError("TODO: implement A* graph search")


def _make_frame(
    selected: Node[StateT, ActionT],
    frontier: list[Node[StateT, ActionT]],
    expanded: list[StateT],
) -> SearchFrame[StateT]:
    return SearchFrame(
        selected=selected.state,
        frontier=tuple(node.state for node in frontier),
        expanded=tuple(expanded),
    )


def _reconstruct_path(goal: Node[StateT, ActionT]) -> Path[StateT, ActionT]:
    states: list[StateT] = []
    actions: list[ActionT] = []
    current: Node[StateT, ActionT] | None = goal

    while current is not None:
        states.append(current.state)
        if current.parent is not None:
            actions.append(cast(ActionT, current.action))
        current = current.parent

    states.reverse()
    actions.reverse()
    return Path(states=tuple(states), actions=tuple(actions), cost=goal.path_cost)


def _validated_step_cost(value: object) -> float:
    if not _is_finite_number(value):
        raise ValueError("step costs must be positive finite numbers")
    cost = float(cast(Real, value))
    if cost <= 0:
        raise ValueError("step costs must be positive finite numbers")
    return cost


def _is_finite_number(value: object) -> bool:
    if not isinstance(value, Real) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError, OverflowError):
        return False


def _require_hashable(state: object) -> None:
    try:
        hash(state)
    except TypeError as error:
        raise TypeError("search states must be hashable") from error


__all__ = [
    "Node",
    "Path",
    "SearchFrame",
    "SearchProblem",
    "SearchResult",
    "SearchStatus",
    "a_star_search",
    "breadth_first_search",
    "depth_first_search",
    "greedy_best_first_search",
    "random_search",
    "uniform_cost_search",
]
