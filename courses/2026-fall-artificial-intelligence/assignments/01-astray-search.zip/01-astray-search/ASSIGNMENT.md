# Assignment 1: Astray Search

In this assignment, you will implement and compare five graph-search
algorithms in an Astray-inspired weighted maze. The maze engine, random-search
baseline, trace format, and browser viewer are supplied. Your algorithms choose
which state to explore; the browser only replays the decisions made by Python.

Assignment 1 is completed individually and evaluated on a 100-point rubric.
Its deadline and course-grade weight are shown in the course website and Blackboard.

## Learning objectives

After completing this assignment, you should be able to:

- explain how a frontier policy changes graph-search behavior;
- implement depth-first, breadth-first, uniform-cost, greedy best-first, and A*
  search;
- distinguish a path with few steps from a path with low cost;
- use reached-state and best-cost records to terminate correctly on graphs;
- design tests that expose plausible search defects; and
- compare solution cost, expansions, generated nodes, and peak frontier size.

## Start here

1. Read this file completely.
2. Complete the required graph trace below before implementing a TODO.
3. Run `python -m unittest tests.test_public -v` to verify the supplied engine
   and random-search baseline.
4. Generate the supplied random-search replay and open it in a browser.
5. Add at least one numerical test to `tests/test_student.py` that reaches a
   TODO search function. Record its initial `NotImplementedError`.
6. Implement DFS and BFS, then UCS, Greedy, and A*.
7. Complete your independent tests, inspect several HTML replays, review the
   submission files, and finish the report.

The five required search functions initially raise `NotImplementedError`, so a
student test that calls one is expected to fail at the beginning.

## Supplied and student work

The starter supplies:

- `maze.py`, including an immutable weighted-grid problem, parser, renderer,
  and seeded maze generator;
- `search.py`, including the shared types, validation helpers, path
  reconstruction, and a complete random-frontier graph search;
- `demo.py` and `viewer/template.html`, which produce a self-contained offline
  replay;
- `run_experiments.py`, which runs search methods across supplied levels and
  writes individual replays, a CSV summary, and an HTML comparison index;
- corridor, cyclic, unreachable, weighted, and hard example levels;
- transparent public tests, this specification, the report template, the
  AI-use declaration, and third-party notices.

Implement these functions in `search.py` without changing their public names
or parameters:

```python
depth_first_search(problem)
breadth_first_search(problem)
uniform_cost_search(problem)
greedy_best_first_search(problem, heuristic)
a_star_search(problem, heuristic)
```

You may add private helpers to `search.py`. Do not modify `maze.py`,
`random_search`, `demo.py`, `viewer/template.html`, a supplied level, or
`tests/test_public.py`. Add independent tests only to `tests/test_student.py`.

Use Python 3.10 or newer and the standard library only. Do not use a packaged
search algorithm or another implementation of these algorithms.

## Weighted-maze model

A level is a rectangular ASCII grid:

| Symbol | Meaning | Cost to enter |
| --- | --- | ---: |
| `#` | wall | not traversable |
| `S` | unique start | 1 |
| `G` | unique goal | 1 |
| `.` or `1` | ordinary floor | 1 |
| `2` through `9` | weighted terrain | digit value |

A state is a zero-based `(row, column)` tuple. `MazeProblem.successors(state)`
returns `(action, next_state, step_cost)` triples in this canonical order:

```text
UP, RIGHT, DOWN, LEFT
```

The step cost belongs to the destination cell. The path cost is the sum of all
destination-entry costs; it excludes the initial cell. All valid step costs
are positive and finite.

For example, the path `S` → `.` → `5` → `G` costs `1 + 5 + 1 = 7`: the initial
`S` contributes no cost, while entering `.`, `5`, and `G` costs 1, 5, and 1,
respectively.

Your search code must use only the public problem interface
`initial_state`, `is_goal(state)`, and `successors(state)`. Instructor tests may
therefore supply a small non-maze graph with hashable states.

## Required pre-run trace

Before implementing a TODO, trace this directed graph in `report/report.tex`.
Successors appear in canonical order from left to right.

```text
S: (S-A, A, 4), (S-B, B, 5), (S-C, C, 5), (S-F, F, 1)
A: (A-D, D, 1)
B: (B-A, A, 1), (B-G, G, 6)
C: (C-G, G, 4)
D: (D-A, A, 1), (D-G, G, 5)
E: (E-G, G, 4)
F: (F-E, E, 1), (F-C, C, 1)
G: no successors
```

Use these heuristic values:

```text
h(S) = 6, h(A) = 3, h(B) = 2, h(C) = 1
h(D) = 2, h(E) = 4, h(F) = 5, h(G) = 0
```

For DFS, BFS, UCS, Greedy, and A*, record every genuine selection and the
logical frontier after processing it. For a selected goal, show the frontier
after removing the goal; do not expand it. Label frontier nodes with `g` and,
where applicable, `h` and the strategy priority. List the frontier in
next-selection order. Identify reached-state rejections, strictly cheaper
replacements or reopenings, and generation-order tie breaks. Never include an
obsolete entry in the logical frontier. Give the returned states, actions, step
count, and cost.

## Search semantics

All five required algorithms are graph searches and must follow the same
observable contract as `random_search`:

- Create a root node with cost zero and count it as generated.
- Test for a goal when a node is selected from the frontier, not when a
  successor is generated.
- Do not count the selected goal as expanded.
- Continue until a selected node is a goal or the frontier is empty. Return
  failure if the frontier becomes empty before a goal is selected.
- A successful result contains the actual root-to-goal states, actions, and
  accumulated cost. A failure result contains no path.
- Every search over a finite reachable state space must terminate, including
  when the graph contains cycles or the goal is unreachable.
- Reject malformed successor triples and nonpositive or nonfinite step costs
  consistently with the supplied baseline. Costs must be real numeric values;
  Boolean values and numeric strings are invalid.

Use the following selection and duplicate-handling rules:

| Algorithm | Next node | State record |
| --- | --- | --- |
| DFS | last in, first out | reached when generated |
| BFS | first in, first out | reached when generated |
| UCS | smallest `g` | best known `g` |
| Greedy | smallest `h` | reached when generated |
| A* | smallest `g + h` | best known `g` |

DFS must explore the first canonical successor first; with an ordinary stack,
push successors in reverse order. Break equal priorities in UCS, Greedy, and A*
by earlier generation.

UCS and A* must admit a state again only after finding a strictly cheaper
path. They must ignore equal-cost alternatives and reopen an already expanded
state when a cheaper path is later found. If a heap retains obsolete entries,
do not select, expand, frame, or count an obsolete entry as part of the logical
frontier.

Greedy and A* must reject a heuristic value that is negative or nonfinite.
They must call the supplied `heuristic(state)` rather than inspecting maze
internals.

## Metrics and frames

Return a `SearchResult` whose fields have these meanings:

- `status`: `"success"` or `"failure"`;
- `expanded_count`: number of genuine calls to `problem.successors`;
- `generated_count`: the root plus every node admitted to the logical
  frontier, including a strictly cheaper replacement;
- `peak_frontier`: largest logical frontier size, including the initial root;
- `frames`: one state-only snapshot for every genuine node selection.

A frame contains the selected state, the logical frontier after successor
generation, and all states expanded so far. The frontier contains each active
logical node once. Its tuple order is display data and is not graded; in the
written pre-run trace, list nodes in next-selection order so the policy and
tie-breaking remain visible.

The expanded sequence is chronological and repeats a state if it is genuinely
re-expanded after a cheaper reopening. Include a goal-selection frame after
removing the selected node; this frame does not add the selected goal to
expanded or generate its successors. The viewer uses these frames, but the
Python result remains authoritative.

## Maze heuristic

The supplied demo uses weighted Manhattan distance:

```text
h(row, column)
    = (abs(row - goal_row) + abs(column - goal_column))
      * minimum_step_cost
```

The demo passes this heuristic to Greedy and A* through their `heuristic`
parameter.

## Random baseline

`random_search` is a complete but nonoptimal baseline on a finite graph. It
chooses uniformly from the current frontier, uses a private
`random.Random(seed)` instance, and marks a state reached when generated. It is
not a random walk: the frontier preserves alternative paths that remain to be
explored.

The same problem and seed reproduce the complete result and frames without
reading or changing Python's global random state. Use the baseline to learn the
interfaces and to contrast its frontier policy with the required algorithms;
do not modify it.

## Your tests

Do not modify `tests/test_public.py`. Your independent tests must collectively
check:

- all five required algorithms;
- deterministic DFS and BFS ordering;
- termination on a cycle and an unreachable goal;
- BFS fewest-step behavior;
- UCS least-cost behavior on a weighted graph;
- Greedy selection by `h` and A* selection by `g + h`;
- cheaper-path replacement or reopening in UCS and A*;
- initial-goal success without expansion and goal testing on selection;
- returned status, states, actions, cost, and representative metrics; and
- A* with a zero heuristic agreeing with UCS on optimal solution cost.

Tests are evaluated for the defects they can distinguish, not merely their
number. Relevant defects include reversing FIFO or LIFO behavior, testing the
goal on generation, omitting the reached set, treating the first UCS path as
final, failing to reopen a cheaper path, confusing Greedy with A*, unstable
tie-breaking, counting stale heap entries, and reconstructing a mismatched
action or cost.

Run the suites separately while developing:

```bash
python -m unittest tests.test_public -v
python -m unittest tests.test_student -v
```

Instructor evaluation uses clean copies of supplied files. Changing a public
test, engine rule, baseline, or viewer does not change the evaluation contract.

## Replays and experiments

The starter works immediately with the random baseline:

```bash
python demo.py --algorithm random --level levels/weighted.txt \
  --seed 7 --output results.html
```

After implementing a required algorithm, replace `random` with `dfs`, `bfs`,
`ucs`, `greedy`, or `astar`. Open the generated file directly in a modern
browser. It contains the maze, recorded frames, result, styles, and script, so
it needs no server or Internet connection.

Use Previous, Play, Next, Reset, the speed control, and Replay solution to
inspect the trace. The keyboard shortcuts are Space, Left Arrow, and Right
Arrow. The display distinguishes walls, weights, frontier states, expanded
states, the selected state, and the final path.

After implementing the required algorithms, run the complete experiment matrix:

```bash
python run_experiments.py
```

By default, `run_experiments.py` runs every available search method on every
supplied level. It writes individual replays, `summary.csv`, and `index.html`
under `experiment_results/`. Use `python run_experiments.py --help` to select
particular levels or algorithms, change the random seed, or choose another
output directory.

The browser does not execute or grade your algorithm. Do not submit generated
replay or experiment output.

## Verification

From this assignment directory, run both suites and the complete experiment
matrix. Review every failure and inspect replays for at least the cyclic,
unreachable, weighted, and hard cases.

After the tests pass, read `search.py` and `tests/test_student.py`. Trace at
least one path through every algorithm and compare the code with the selection,
duplicate, termination, metric, and path-reconstruction rules above. Review
every file in the assignment folder, remove unintended files, and compare the
exact planned upload with the submission list.

Record commands and outcomes, replay observations, source and file-review
outcomes, the Python version, added dependencies, one input assumption, and one
known limitation in `report/report.tex`.

## Report

Complete `report/report.tex` and compile `report/report.pdf` with the supplied
NeurIPS 2026 style. Do not change its fonts, margins, or spacing. Keep the
report to at most five pages and include:

1. the required pre-run graph trace;
2. a comparison of path length, cost, expansions, and peak frontier;
3. an explanation of why BFS and UCS can disagree on the weighted level;
4. one student test and the plausible defect it detects;
5. required commands and observed results;
6. implementation, test, folder, and planned-submission review outcomes;
7. the Python version, dependencies, one assumption, and one limitation.

Run the compilation command from `report/` so LaTeX can locate the adjacent
style file:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
cd ..
```

## Submission

Preserve these paths in the Blackboard submission:

```text
search.py
tests/test_student.py
report/report.tex
report/report.pdf
AI_USE.md
```

When reasonably available, also include `ai-records/` and related verification
records. Do not submit generated experiment output (including
`experiment_results/`), other generated HTML, caches, virtual environments,
credentials, or any unchanged supplied file not listed above.

## 100-point rubric

| Component | Points |
| --- | ---: |
| Depth-first search | 10 |
| Breadth-first search | 10 |
| Uniform-cost search | 15 |
| Greedy best-first search | 10 |
| A* search | 20 |
| Student-written tests | 20 |
| Report and independent verification | 15 |
| **Total** | **100** |
